// ====== Data & Constants ======
const TOYS = ["Robot","Dinosaur","Car","Doll","Puzzle","Ball"]; // 6 toys
const COLORS = ["Red","Yellow","Green","Blue","Purple","Teal"]; // 6 colors
const COLOR_RGB = {
  Red:   "rgb(220,53,69)",
  Yellow:"rgb(255,193,7)",
  Green: "rgb(40,167,69)",
  Blue:  "rgb(0,123,255)",
  Purple:"rgb(111,66,193)",
  Teal:  "rgb(32,201,151)"
};

const SIZE = 6; // 6x6 board

// ====== Game State ======
const state = {
  board: null,          // 2D array SIZE×SIZE of tiles or null
  supply: [],
  display: [],
  focuses: ["genre","color"], // p1,p2: 'genre' means Toys, 'color' means Colors
  current: 0,           // player index 0/1
  phase: "place",       // start with place so there's something to click
  selected: null,       // {r,c} selected for sliding
  validDests: new Set(),// set of "r,c" strings
  selectedDisplay: null // index in display
};

// ====== Utilities ======
function makeDeck(){
  const deck = [];
  for(const g of TOYS){
    for(const c of COLORS){ deck.push({genre:g, color:c}); }
  }
  return deck;
}
function shuffle(a){
  for(let i=a.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
  return a;
}
function emptyBoard(){ return Array.from({length:SIZE},()=>Array(SIZE).fill(null)); }
function inBounds(r,c){ return r>=0 && r<SIZE && c>=0 && c<SIZE; }
function key(r,c){ return `${r},${c}`; }

// ====== Setup & New Game ======
function newGame(){
  state.board = emptyBoard();
  state.supply = shuffle(makeDeck());
  state.display = [];
  for(let i=0;i<6;i++) drawFromSupplyToDisplay();
  state.current = 0;
  state.phase = "place";
  state.selected = null; state.validDests.clear(); state.selectedDisplay = null;
  updateSupplyBadge();
  renderDisplay();
  sizeBoardToViewport()
  render();
  showFocusDialog();
  setStatus();
}

function showFocusDialog(){
  const dlg = document.getElementById('focusDialog');
  dlg.showModal();
  document.getElementById('startBtn').onclick = () => {
    const p1 = document.querySelector('input[name="p1"]:checked').value;
    const p2 = document.querySelector('input[name="p2"]:checked').value;
    state.focuses = [p1,p2];
    dlg.close();
    setStatus();
  };
}

function drawFromSupplyToDisplay(){
  if(state.supply.length>0 && state.display.length<6){
    state.display.push(state.supply.pop());
  }
}

// ====== Canvas & Rendering ======
const canvas = document.getElementById('board');
const ctx = canvas.getContext('2d');

function sizeBoardToViewport() {
  const header = document.querySelector('header');
  const mainPad = 32;                 // rough padding around content
  const extraBottom = 180;            // status line + breathing room
  const availableH = Math.max(
  360,
  window.innerHeight - (header?.offsetHeight || 0) - mainPad - (isDesktop ? 240 : 180)
  );


  // The board sits inside the left card; measure that card’s inner width
  const boardSection = document.getElementById('boardContainer').parentElement;
  const availableW = boardSection.getBoundingClientRect().width - 32; // minus card padding
  
  const isDesktop = window.matchMedia('(min-width: 900px)').matches;
  const MAX_BOARD = isDesktop ? 480 : 720;
  const target = Math.floor(Math.min(availableW, availableH, MAX_BOARD));
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  canvas.style.width  = target + 'px';     // CSS size (what you see)
  canvas.style.height = target + 'px';
  canvas.width  = Math.floor(target * dpr); // backing pixels (what we draw into)
  canvas.height = Math.floor(target * dpr);

}

// Re-size when the window changes
window.addEventListener('resize', () => { sizeBoardToViewport(); render(); });

function render(){
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0,0,W,H);
  // background
  ctx.fillStyle = '#0d0f14'; ctx.fillRect(0,0,W,H);
  // outer frame
  roundRect(ctx, 4,4,W-8,H-8, 18, '#11141b', '#2a2f3a', 2);
  // grid
  const pad = 24; const size = W - pad*2; const cell = size / SIZE;
  // labels
  ctx.fillStyle = '#c9ccd3'; ctx.font = '14px system-ui'; ctx.textAlign='center'; ctx.textBaseline='middle';
  for(let r=0;r<SIZE;r++){
    ctx.fillText(String(r+1), pad-10, pad + r*cell + cell/2);
    ctx.fillText(String(r+1), pad+size+10, pad + r*cell + cell/2);
  }
  for(let c=0;c<SIZE;c++){
    ctx.fillText(String.fromCharCode(65+c), pad + c*cell + cell/2, pad-10);
    ctx.fillText(String.fromCharCode(65+c), pad + c*cell + cell/2, pad+size+10  );
  }
  // grid lines
  ctx.strokeStyle = '#2a2f3a'; ctx.lineWidth = 1.5;
  for(let i=0;i<=SIZE;i++){
    const y = pad + i*cell; ctx.beginPath(); ctx.moveTo(pad, y); ctx.lineTo(pad+size, y); ctx.stroke();
    const x = pad + i*cell; ctx.beginPath(); ctx.moveTo(x, pad); ctx.lineTo(x, pad+size); ctx.stroke();
  }
  // highlight valid destinations
  for(const k of state.validDests){
    const [r,c] = k.split(',').map(Number);
    const x = pad + c*cell; const y = pad + r*cell;
    ctx.fillStyle = 'rgba(110,168,254,0.18)'; ctx.fillRect(x+2,y+2,cell-4,cell-4);
    ctx.strokeStyle = '#6ea8fe'; ctx.lineWidth = 2; ctx.strokeRect(x+2,y+2,cell-4,cell-4);
  }
  // draw tiles
  for(let r=0;r<SIZE;r++){
    for(let c=0;c<SIZE;c++){
      const t = state.board[r][c];
      if(!t) continue;
      const x = pad + c*cell; const y = pad + r*cell;
      drawTile(ctx, x,y, cell, t, state.selected && state.selected.r===r && state.selected.c===c);
    }
  }
}

function roundRect(ctx, x,y,w,h, r, fill, stroke, lw=1){
  ctx.beginPath();
  ctx.moveTo(x+r,y);
  ctx.arcTo(x+w,y, x+w,y+h, r);
  ctx.arcTo(x+w,y+h, x,y+h, r);
  ctx.arcTo(x,y+h, x,y, r);
  ctx.arcTo(x,y, x+w,y, r);
  if(fill){ ctx.fillStyle = fill; ctx.fill(); }
  if(stroke){ ctx.lineWidth = lw; ctx.strokeStyle = stroke; ctx.stroke(); }
}

function drawTile(ctx, x, y, size, tile, selected=false){
  // card background
  roundRect(ctx, x+6, y+6, size-12, size-12, 14, '#f4f5f6', '#0f1218', 2);
  // header text
  ctx.fillStyle = '#10141b'; ctx.font = 'bold 14px system-ui'; ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText(tile.genre, x + size/2, y + size*0.14);

  // icon area
  const cx = x + size/2, cy = y + size*0.56; const s = size*0.8;
  drawIcon(ctx, tile, cx, cy, s);

  // footer text
  ctx.fillStyle = '#3a3f4a'; ctx.font = '12px system-ui';
  ctx.fillText(tile.color, x + size/2, y + size*0.88);

  if(selected){
    ctx.strokeStyle = '#6ea8fe'; ctx.lineWidth = 3; ctx.strokeRect(x+4,y+4,size-8,size-8);
  }
}

function drawIcon(ctx, tile, cx, cy, s){
  const color = COLOR_RGB[tile.color];
  ctx.save();
  // shadow
  ctx.fillStyle = 'rgba(0,0,0,0.08)'; ctx.beginPath(); ctx.ellipse(cx, cy + s*0.25, s*0.23, s*0.06, 0, 0, Math.PI*2); ctx.fill();
  // choose by toy
  switch(tile.genre){
    case 'Robot': drawRobot(ctx, cx, cy, s, color); break;
    case 'Dinosaur': drawDino(ctx, cx, cy, s, color); break;
    case 'Car': drawCar(ctx, cx, cy, s, color); break;
    case 'Doll': drawDoll(ctx, cx, cy, s, color); break;
    case 'Puzzle': drawPuzzle(ctx, cx, cy, s, color); break;
    case 'Ball': drawBall(ctx, cx, cy, s, color); break;
  }
  ctx.restore();
}

// ====== Simple Icon Drawing (Toy set) ======
function drawRobot(ctx, cx, cy, s, color){
  const w = s*0.30, h = s*0.22;
  // head
  ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  roundPath(ctx, cx-w*0.7, cy-h*1.4, w*1.4, h*1.0, 8); ctx.fill(); ctx.stroke();
  // eyes
  ctx.fillStyle = '#0f1218'; ctx.beginPath(); ctx.arc(cx-10, cy-h*0.95, 4, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(cx+10, cy-h*0.95, 4, 0, Math.PI*2); ctx.fill();
  // antenna
  ctx.beginPath(); ctx.moveTo(cx, cy-h*1.4); ctx.lineTo(cx, cy-h*1.65); ctx.stroke(); ctx.beginPath(); ctx.arc(cx, cy-h*1.75, 4, 0, Math.PI*2); ctx.fillStyle=color; ctx.fill(); ctx.stroke();
  // body
  ctx.fillStyle = color; roundPath(ctx, cx-w, cy-h*0.8, w*2, h*1.7, 10); ctx.fill(); ctx.stroke();
  // panel
  ctx.fillStyle = 'rgba(255,255,255,0.6)'; roundPath(ctx, cx-w*0.6, cy-h*0.5, w*1.2, h*0.8, 6); ctx.fill();
  // arms
  ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(cx-w, cy-h*0.4); ctx.lineTo(cx-w*1.4, cy-h*0.2); ctx.moveTo(cx+w, cy-h*0.4); ctx.lineTo(cx+w*1.4, cy-h*0.2); ctx.stroke();
  // legs
  ctx.beginPath(); ctx.moveTo(cx-w*0.4, cy+h*0.9); ctx.lineTo(cx-w*0.4, cy+h*1.3); ctx.moveTo(cx+w*0.4, cy+h*0.9); ctx.lineTo(cx+w*0.4, cy+h*1.3); ctx.stroke();
}
function drawDino(ctx, cx, cy, s, color){
  ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  roundPath(ctx, cx-s*0.30, cy-s*0.12, s*0.60, s*0.36, 16); ctx.fill(); ctx.stroke();
  // spikes
  ctx.beginPath(); for(let i=0;i<5;i++){ const x=cx-s*0.20+i*s*0.10; const y=cy-s*0.16; ctx.moveTo(x, y); ctx.lineTo(x+s*0.04, y-s*0.10); ctx.lineTo(x+s*0.08, y); }
  ctx.fillStyle = '#0f1218'; ctx.fill();
  // eye
  ctx.beginPath(); ctx.arc(cx+s*0.18, cy-s*0.02, 3, 0, Math.PI*2); ctx.fill();
}
function drawCar(ctx, cx, cy, s, color){
  ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  roundPath(ctx, cx-s*0.28, cy-s*0.06, s*0.56, s*0.20, 10); ctx.fill(); ctx.stroke();
  // roof
  roundPath(ctx, cx-s*0.18, cy-s*0.14, s*0.36, s*0.12, 10); ctx.fill(); ctx.stroke();
  // wheels
  ctx.fillStyle = '#0f1218'; ctx.beginPath(); ctx.arc(cx-s*0.16, cy+s*0.10, s*0.06, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(cx+s*0.16, cy+s*0.10, s*0.06, 0, Math.PI*2); ctx.fill();
}
function drawDoll(ctx, cx, cy, s, color){
  ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  // head
  ctx.beginPath(); ctx.arc(cx, cy-s*0.08, s*0.12, 0, Math.PI*2); ctx.fill(); ctx.stroke();
  // body
  roundPath(ctx, cx-s*0.12, cy, s*0.24, s*0.24, 12); ctx.fill(); ctx.stroke();
  // eyes
  ctx.fillStyle = '#0f1218'; ctx.beginPath(); ctx.arc(cx-6, cy-s*0.10, 3, 0, Math.PI*2); ctx.fill(); ctx.beginPath(); ctx.arc(cx+6, cy-s*0.10, 3, 0, Math.PI*2); ctx.fill();
}
function drawPuzzle(ctx, cx, cy, s, color){
  // simple puzzle piece silhouette
  ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  const w=s*0.36, h=s*0.28; roundPath(ctx, cx-w, cy-h, w*2, h*2, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#0f1218'; ctx.beginPath(); ctx.arc(cx, cy-h, 6, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(cx-w, cy, 6, 0, Math.PI*2); ctx.fill();
}
function drawBall(ctx, cx, cy, s, color){
  const r=s*0.18; ctx.fillStyle = color; ctx.strokeStyle = '#0f1218'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2); ctx.fill(); ctx.stroke();
  ctx.strokeStyle = 'white'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(cx, cy, r*0.6, 0, Math.PI*2); ctx.stroke();
}

function roundPath(ctx,x,y,w,h,r){
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r);
}

// ====== Input Handling ======
canvas.addEventListener('click', (e)=>{
  const rect = canvas.getBoundingClientRect();
  const px = (e.clientX - rect.left) * (canvas.width / rect.width);
  const py = (e.clientY - rect.top) * (canvas.height / rect.height);
  const pad = 40; const size = canvas.width - pad*2; const cell = size / SIZE;
  if(px<pad || py<pad || px>pad+size || py>pad+size) return; // outside grid
  const c = Math.floor((px - pad)/cell);
  const r = Math.floor((py - pad)/cell);
  onBoardClick(r,c);
});

function onBoardClick(r,c){
  if(state.phase === 'slide'){
    const t = state.board[r][c];
    if(t && !state.selected){
      state.selected = {r,c};
      computeValidDests(r,c);
    } else if(state.selected && state.validDests.has(key(r,c))){
      // perform slide
      const {r:sr,c:sc} = state.selected;
      state.board[r][c] = state.board[sr][sc];
      state.board[sr][sc] = null;
      state.selected = null; state.validDests.clear();
      state.phase = 'place'; state.selectedDisplay = null;
    } else {
      // click elsewhere cancels selection
      state.selected = null; state.validDests.clear();
    }
  } else if(state.phase === 'place'){
    if(state.board[r][c]===null && state.selectedDisplay!=null){
      // place selected display tile
      state.board[r][c] = state.display[state.selectedDisplay];
      state.display.splice(state.selectedDisplay,1);
      drawFromSupplyToDisplay();
      state.selectedDisplay = null;
      // end check
      if(boardFull()){
        endAndScore();
      } else {
        // next player
        state.current = 1 - state.current;
        state.phase = 'slide';
      }
    }
  }
  renderDisplay();
  render();
  setStatus();
}

function computeValidDests(r,c){
  state.validDests.clear();
  // scan in 4 directions until blocked; add empty cells with clear path
  const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
  for(const [dr,dc] of dirs){
    let nr=r+dr, nc=c+dc;
    while(inBounds(nr,nc) && state.board[nr][nc]===null){
      state.validDests.add(key(nr,nc));
      nr+=dr; nc+=dc;
    }
  }
}

function boardFull(){
  for(let r=0;r<SIZE;r++) for(let c=0;c<SIZE;c++) if(!state.board[r][c]) return false;
  return true;
}

// ====== Display panel ======
function renderDisplay(){
  const cont = document.getElementById('display');
  cont.innerHTML='';
  state.display.forEach((t,idx)=>{
    const div = document.createElement('div');
    div.className = 'slot' + (state.selectedDisplay===idx ? ' sel':'' );
    div.title = `${t.genre} — ${t.color}`;
    const canv = document.createElement('canvas'); canv.width=120; canv.height=90;
    const c2 = canv.getContext('2d');
    // draw tiny tile
    drawTile(c2, 10, 5, 100, t, false);
    div.appendChild(canv);
    div.onclick = ()=>{
      if(state.phase!=='place') return;
      state.selectedDisplay = idx; renderDisplay(); setStatus();
    };
    cont.appendChild(div);
  });
  updateSupplyBadge();
}

function updateSupplyBadge(){
  document.getElementById('supplyBadge').textContent = `Supply: ${state.supply.length}`;
}

function setStatus(){
  const p = state.current+1;
  const focus = state.focuses[state.current]==='genre' ? 'Toys' : 'Colors';
  const phase = state.phase==='slide' ? 'Slide a toy' : (state.selectedDisplay==null ? 'Place: select a display tile' : 'Place: click an empty cell');
  document.getElementById('status').textContent = `Player ${p} · Focus: ${focus} · ${phase}`;
}

// ====== Scoring ======
const SCORE_TABLE = {2:1,3:3,4:6,5:10,6:15};

function computeScoreFor(playerIdx){
  const focus = state.focuses[playerIdx];
  const seen = Array.from({length:SIZE},()=>Array(SIZE).fill(false));
  let total = 0; const groups = [];
  for(let r=0;r<SIZE;r++){
    for(let c=0;c<SIZE;c++){
      const t = state.board[r][c];
      if(!t || seen[r][c]) continue;
      // BFS for attribute
      const attr = focus==='genre' ? t.genre : t.color;
      const q=[[r,c]]; seen[r][c]=true; let sz=0; const cells=[[r,c]];
      while(q.length){
        const [cr,cc]=q.shift(); sz++;
        const nbs=[[1,0],[-1,0],[0,1],[0,-1]];
        for(const [dr,dc] of nbs){
          const nr=cr+dr, nc=cc+dc;
          if(!inBounds(nr,nc) || seen[nr][nc]) continue;
          const t2 = state.board[nr][nc];
          if(t2 && ((focus==='genre' && t2.genre===attr) || (focus==='color' && t2.color===attr))){
            seen[nr][nc]=true; q.push([nr,nc]); cells.push([nr,nc]);
          }
        }
      }
      if(sz>=2){
        const pts = SCORE_TABLE[sz] ?? (sz>6 ? 15 : 0);
        total += pts; groups.push({attr, size:sz, pts, cells});
      }
    }
  }
  return {total, groups, focus};
}

function endAndScore(){
  const s1 = computeScoreFor(0);
  const s2 = computeScoreFor(1);
  const win = s1.total===s2.total ? 'Draw!' : (s1.total>s2.total? 'Player 1 wins!' : 'Player 2 wins!');
  showScoreModal(s1,s2,win);
}

function showScoreModal(s1,s2,headline='Scores'){
  const box = document.getElementById('scoreContent');
  box.innerHTML = `
    <p><b>${headline}</b></p>
    <div class="hr"></div>
    <p><b>Player 1</b> — Focus: ${s1.focus==='genre'?'Toys':'Colors'} — <b>${s1.total}</b> pts</p>
    ${renderGroupList(s1.groups)}
    <div class="hr"></div>
    <p><b>Player 2</b> — Focus: ${s2.focus==='genre'?'Toys':'Colors'} — <b>${s2.total}</b> pts</p>
    ${renderGroupList(s2.groups)}
  `;
  document.getElementById('scoreDialog').showModal();
}

function renderGroupList(groups){
  if(!groups.length) return '<p class="hint">No scoring groups.</p>';
  return '<ul>' + groups.map(g=>`<li>${g.size} in ${g.attr} → ${g.pts} pts</li>`).join('') + '</ul>';
}

// ====== Buttons & Modals ======
document.getElementById('newBtn').onclick = newGame;
document.getElementById('rulesBtn').onclick = ()=>document.getElementById('rulesDialog').showModal();
document.getElementById('closeRules').onclick = ()=>document.getElementById('rulesDialog').close();
document.getElementById('scoreBtn').onclick = ()=>{
  const s1 = computeScoreFor(0); const s2 = computeScoreFor(1);
  showScoreModal(s1,s2,'Current Board');
};
document.getElementById('closeScore').onclick = ()=>document.getElementById('scoreDialog').close();

// ====== Kickoff ======
newGame();