package de.hawhamburg.v7;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class StudentManagerTest {

    StudentManager studentManager = new StudentManager();

    @Test
    void findStudentsByUniversityName() {
        // Arrange
        String query = "HAW Hamburg";
        Student hawHamburg = new Student(query);
        studentManager.add(hawHamburg);

        // Act
        List<Student> actual = studentManager.findStudentByUniversity(query);

        // Assert
        List<Student> expected = new ArrayList<>();
        expected.add(hawHamburg);
        assertEquals(expected, actual);
    }

    @Test
    void findStudentsByUniversityNameNoMatch() {
        // Arrange
        Student hawHamburg = new Student("HAW Hamburg");
        studentManager.add(hawHamburg);

        // Act
        List<Student> actual = studentManager.findStudentByUniversity("HAW Hambrug");

        // Assert
        List<Student> expected = new ArrayList<>();
        assertEquals(expected, actual);
    }

    @Test
    void findStudentsByUniversityNameTrim() {
        // Arrange
        Student hawHamburg = new Student("HAW Hamburg");
        studentManager.add(hawHamburg);

        // Act
        List<Student> actual = studentManager.findStudentByUniversity("  HAW Hamburg   ");

        // Assert
        List<Student> expected = new ArrayList<>();
        expected.add(hawHamburg);
        assertEquals(expected, actual);
    }


    @Test
    void findStudentsByUniversityNameEmptyString() {
        // Arrange
        Student hawHamburg = new Student("HAW Hamburg");
        studentManager.add(hawHamburg);

        // Act
        List<Student> actual = studentManager.findStudentByUniversity("");

        // Assert
        List<Student> expected = new ArrayList<>();
        assertEquals(expected, actual);
    }

    @Test
    void findStudentsByUniversityNameNull() {
        // Arrange
        Student hawHamburg = new Student("HAW Hamburg");
        studentManager.add(hawHamburg);

        // Act
        List<Student> actual = studentManager.findStudentByUniversity(null);

        // Assert
        List<Student> expected = new ArrayList<>();
        assertEquals(expected, actual);
    }

    // Beispiel für assertThrows, um Exceptions zu testen
//    @Test
//    void findStudentsByUniversityNameNullOrEmptyThrowsException() {
//        assertThrows(
//            IllegalArgumentException.class, // Der erwartete Typ der Exception
//            () -> studentManager.findStudentByUniversity(null) // lambda () -> ... act ...
//        );
//    }
}