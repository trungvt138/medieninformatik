package de.hawhamburg.v7;

import java.util.ArrayList;
import java.util.List;

class StudentManager {

    private List<Student> students = new ArrayList<>();

    void add(Student student) {
        students.add(student);
    }

    List<Student> findStudentByUniversity(String universityName) { // ""
        if(universityName == null || universityName.isEmpty()) { // edge case
            return new ArrayList<>(); // best practice
//            throw new IllegalArgumentException("University Name must not be null or empty.");
        }

        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if(student.universityName.equals(universityName.trim())) {
                result.add(student);
            }
        }
        return result;
    }
}
