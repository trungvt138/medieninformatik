package de.hawhamburg.v7;

class Student {

    String name;
    String matricelNumber;
    String universityName;

    String name() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }

    String matricelNumber() {
        return matricelNumber;
    }

    void setMatricelNumber(String matricelNumber) {
        this.matricelNumber = matricelNumber;
    }

    Student(String universityName) {
        this.universityName = universityName;
    }

    void sleep() {

    }

    String universityName() {
        return universityName;
    }
}
