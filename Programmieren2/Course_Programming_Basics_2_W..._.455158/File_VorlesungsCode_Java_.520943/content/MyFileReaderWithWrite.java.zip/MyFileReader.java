package de.hawhamburg.v2;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

class MyFileReader {

    void main() { // nio
//        readFile();
//        write();
    }

    private static void write() {
        Path path = Path.of("text.txt");
        List<String> text = new ArrayList<>();
        text.add("Tada");
        try {
            Files.write(path, text, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void readFile() {
        Path path = Path.of("text.txt");
        try {
            List<String> lines = Files.readAllLines(path);
            IO.println(lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
