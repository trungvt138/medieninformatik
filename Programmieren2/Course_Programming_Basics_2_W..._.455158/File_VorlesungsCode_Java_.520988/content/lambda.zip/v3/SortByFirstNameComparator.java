package de.hawhamburg.v3;

import java.util.Comparator;

//class SortByFirstNameComparator implements Comparator<Student> {
//
//    @Override
//    public int compare(Student s1, Student s2) {
//        return s1.firstName().compareTo(s2.firstName());
//    }
//}
