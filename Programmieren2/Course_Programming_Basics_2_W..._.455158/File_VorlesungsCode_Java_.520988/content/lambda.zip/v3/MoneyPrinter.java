package de.hawhamburg.v3;

@FunctionalInterface
interface MoneyPrinter {
    void value(int amount);

    static void main() {
        MoneyPrinter euro = amount -> IO.println(amount); // Lazy
        euro.value(42); // evaluate lambda | führe das Lambda aus
    }
}
