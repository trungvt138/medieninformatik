package de.hawhamburg.v3;

import java.util.Comparator;

class SortByLastNameComparator implements Comparator<Student> {

    @Override
    public int compare(Student s1, Student s2) {
        return s1.lastName().compareTo(s2.lastName());
    }
}
