package de.hawhamburg.v14;

record Rectangle(int h, int w) implements Shape {

    @Override
    public double area() {
        return h * w;
    }

    @Override
    public double outline() {
        return 2 * (h * w);
    }
}
