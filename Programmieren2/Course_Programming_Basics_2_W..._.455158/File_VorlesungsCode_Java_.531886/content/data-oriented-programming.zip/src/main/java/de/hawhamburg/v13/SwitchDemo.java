package de.hawhamburg.v13;


class SwitchDemo {

    sealed interface Shape permits Circle, Rectangle { // , Triangle, Quader
    }

    record Circle(int radius) implements Shape {}
    record Rectangle(int h, int w) implements Shape {}
    // record Triangle(int h, int w) implements Shape {}
    // record Triangle(int h, int base) implements Shape {}
    // record Quader(int h, int base) implements Shape {}

    static void main() {
//        Shape shape = new Circle(10);
//        Shape circle = new Circle(10);
        Shape shape = new Rectangle(5, 20);
        area(shape); // Fläche berechnen (Operation)
        outline(shape); // Umfang berechnen (Operation)
        // Operationen n ...

        // ShapeEnum shape = ShapeEnum.Quader;
        // enhancedSwitch(shape);
        // bad practice inzwischen
        // oldSwitchWithFallThrough(shape);
    }

    private static void outline(Shape shape) {
        double result = switch (shape) { // Exhaustiveness
            // case null -> IO.println("Fehler"); // case null -> enhanced switch
            // case Circle circle when circle.radius() > 10 && circle.radius() < 20 -> IO.println("1"); // Guard
            // case Circle circle -> 2 * Math.PI * circle.radius(); // pattern matching -> enhanced switch
            case Circle(int radius) -> 2 * Math.PI * radius; // record pattern matching -> enhanced switch
            case Rectangle(var h, var _) -> 2 * (h * h);
            // default -> throw new IllegalStateException("Unexpected value: " + shape);
        };
        IO.println(result);
    }

    private static void area(Shape shape) {
        double result = switch (shape) { // Exhaustiveness
            // case null -> IO.println("Fehler"); // case null -> enhanced switch
            // case Circle circle when circle.radius() > 10 && circle.radius() < 20 -> IO.println("1"); // Guard
            case Circle circle -> Math.PI * 2 * circle.radius(); // pattern matching -> enhanced switch
            case Rectangle rectangle -> rectangle.h * rectangle.w;
            // default -> throw new IllegalStateException("Unexpected value: " + shape);
        };
        IO.println(result);
    }

    private static void draw(Shape shape) {
        switch (shape) { // Exhaustiveness
            // case null -> IO.println("Fehler"); // case null -> enhanced switch
            // case Circle circle when circle.radius() > 10 && circle.radius() < 20 -> IO.println("1"); // Guard
            case Circle circle -> IO.println("Kreis"); // pattern matching -> enhanced switch
            case Rectangle rectangle -> IO.println("Rechteck");
            // default -> throw new IllegalStateException("Unexpected value: " + shape);
        };
    }

    private static void enhancedSwitch(ShapeEnum shape) {
        switch(shape) { // Exhaustiveness (Vollständigkeit)
            case null -> IO.println("Ist null"); // enchanced switch, der auf Exhaustiveness prüft
            case Circle -> IO.println("Kreis");
            case Rectanle -> IO.println("Rechteck");
            case Triangle -> IO.println("Dreieck");
            case Quader -> IO.println("Quader");
            case Polygon -> IO.println("Polygon");
            // default -> IO.println("Irgendwas");
        }
    }

    private static void oldSwitchWithFallThrough(ShapeEnum shape) {
        switch (shape) { // old switch mit fall-through
            case Circle: IO.println("Kreis"); break;
            case Rectanle: IO.println("Rechteck"); break;
            case Triangle: IO.println("Dreieck"); break;
            case Quader: IO.println("Quader"); break;
            case Polygon: IO.println("Polygon"); break;
        }
    }

    private static void enchanhedSwitch(ShapeEnum shape) {
        enhancedSwitch(shape);
    }
}
