package de.hawhamburg.v12;

import java.io.IOException;
import java.util.stream.Stream;

class MyUncheckedException extends Exception { // CheckedException

    MyUncheckedException(String message) {
        super(message);
    }

    int calc(int number) throws RuntimeException { // UnCheckedException
        return 42; // irgendeine berechnung
    }

    void submethod() {
        //throw new MyUncheckedException("Demo");

            Stream.of(1, 2, 3)
                .filter(number -> calc(42) > 0)
                .toList();

        try {
            throw new MyUncheckedException("Demo");
        } catch (MyUncheckedException ex) {
            IO.println(ex.getMessage());
        } catch (IllegalAccessError e) {
            // ignore
        }
    }
}
