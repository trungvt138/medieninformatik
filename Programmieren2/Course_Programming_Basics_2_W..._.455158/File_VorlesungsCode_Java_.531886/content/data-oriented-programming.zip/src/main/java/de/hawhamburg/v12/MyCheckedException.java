package de.hawhamburg.v12;

class MyCheckedException extends Exception {

    private int id;

    MyCheckedException(String message, int id) {
        super(message);
        this.id = id;
    }

    static void main() {
        try {
            throw new MyCheckedException("Demo", 1);
        } catch (MyCheckedException ex) {
            IO.println(ex.getMessage());
        }
    }
}


