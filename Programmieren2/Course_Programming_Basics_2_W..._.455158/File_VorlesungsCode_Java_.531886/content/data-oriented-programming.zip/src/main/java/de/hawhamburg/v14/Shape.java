package de.hawhamburg.v14;

import java.util.List;

interface Shape {

    double area();
    double outline();

    static void main() {
        // Shape shape = new Circle(10);

        List<Shape> shapes = List.of(new Circle(10), new Rectangle(5, 20), new Triangle(1,2));

        // Hier ganze viele Sachen passieren hier mit shape
        for (Shape shape : shapes) {
            IO.println(shape.area()); // Polymorphie
        }
    }
}
