package de.hawhamburg.v14;

record Triangle(int h, int base) implements Shape {

    @Override
    public double area() {
        return 0;
    }

    @Override
    public double outline() {
        return 0;
    }
}
