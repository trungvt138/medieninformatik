package de.hawhamburg.v12;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

class ExceptionDemo {

    List<Integer> numbers(int number) { // bei Methoden mit Listen als Rückgabewert ist Optional nicht nötig, stattdessen einfach eine leere Liste zurückgeben.
        return List.of();
    }

    Optional<Integer> number() {
        return Optional.ofNullable(null); // ofNullable statt of wirft keine Unchecked Exception und gibt Optional.emtpy zurück
    }

    static void main() {
        ExceptionDemo exceptionDemo = new ExceptionDemo();
        Optional<Integer> optionalNumber = exceptionDemo.number();
        if(optionalNumber.isPresent()) {
            IO.println(optionalNumber.get());
        }

        IO.println(optionalNumber.orElse(-1));
        optionalNumber.orElseThrow();

        // Checked und Unchecked Exception
//        try {
//            hilfsmethode();
//        } catch (Exception e) {
//            //e.printStackTrace();
//        }
//        IO.println("Hello World");
    }

    private static void hilfsmethode() {
        IntStream.of(1,2,3).average();
        // throw new IOException("Vorlesung Demo Checked Exception");
        throw new RuntimeException("Vorlesung Demo Unchecked Exception"); // Unchecked Exception
//        IO.println("Hello World"); // Unreachable code
    }
}
