package de.hawhamburg.v13;

enum Day {
    Monday,
    Tuesday
}
