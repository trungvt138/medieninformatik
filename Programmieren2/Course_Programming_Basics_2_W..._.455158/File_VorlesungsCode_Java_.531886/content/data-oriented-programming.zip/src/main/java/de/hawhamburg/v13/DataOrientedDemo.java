package de.hawhamburg.v13;

class DataOrientedDemo {

    record Student(String name) {}

    static void main() {

        Object object = new Student("Andre");
        // Pattern Matching
        if(object instanceof Student student) { // instanceof-Prüfung + Cast + Zuweisung
            // Student student = (Student)object; // Cast + Zuweisung
            // IO.println(object.name());
            IO.println(student.name());
        }
    }
}
