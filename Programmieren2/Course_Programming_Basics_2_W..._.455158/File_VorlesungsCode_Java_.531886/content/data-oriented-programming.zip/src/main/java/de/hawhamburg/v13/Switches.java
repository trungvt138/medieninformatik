package de.hawhamburg.v13;

class Switches {

    static void main() {
        int number = switch(Day.Monday) { // expression weil Rückabewert
            case Monday: yield 1;
            case Tuesday: yield 2;
        };
        IO.println(number);
    }
}
