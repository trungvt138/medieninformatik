package de.hawhamburg.v13;

enum ShapeEnum {
    Rectanle,
    Circle,
    Triangle,
    Quader,
    Polygon
    // ....
}
