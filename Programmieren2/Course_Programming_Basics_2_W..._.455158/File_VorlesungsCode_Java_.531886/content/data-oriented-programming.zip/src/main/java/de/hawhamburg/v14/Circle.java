package de.hawhamburg.v14;

class Circle implements Shape {

    private int radius;

    Circle(int radius) {
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }

    @Override
    public double outline() {
        return 2 * Math.PI * radius;
    }
}
