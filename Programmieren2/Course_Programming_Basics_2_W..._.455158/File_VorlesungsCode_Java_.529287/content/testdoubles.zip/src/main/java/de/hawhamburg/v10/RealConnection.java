package de.hawhamburg.v10;

import java.util.LinkedList;
import java.util.List;

class RealConnection implements Connection { // wird netzwerkverbindung zur einer Datenbank aufgebaut

    List<Student> students = new LinkedList<>();

    @Override
    public List<Student> query(String name) {
        return students.stream()
            .filter(student -> student.name().equals(name))
            .toList();
    }

    @Override
    public void insert(Student student) {
        students.add(student);
    }
}
