package de.hawhamburg.v10;

record Student(String name) {}
