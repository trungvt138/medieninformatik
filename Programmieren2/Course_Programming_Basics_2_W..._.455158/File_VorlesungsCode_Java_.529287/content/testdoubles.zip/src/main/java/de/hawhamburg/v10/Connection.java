package de.hawhamburg.v10;

import java.util.List;

interface Connection {

    List<Student> query(String name);
    void insert(Student student);
}
