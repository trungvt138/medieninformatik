package de.hawhamburg.v10;

import java.util.List;

class SuperDuperPowerConnection implements Connection {

    @Override
    public List<Student> query(String name) {
        return List.of();
    }

    @Override
    public void insert(Student student) {

    }
}
