package de.hawhamburg.v10;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DatabaseTest {

    @Test
    void findStudentById() {
        // Arrange
        Database database = new Database(new MockedConnection());
        String andre = "Andre";
        database.add(new Student(andre));

        // Act
        List<Student> actual = database.findStudentByName(andre);

        // Assert
        assertEquals(List.of(new Student(andre)), actual);
    }

    @Test
    void add() {
        // Arrange
        Database database = new Database(new MockedConnection());
        String anna = "Anna";

        List<Student> actual = database.findStudentByName(anna);
        assertEquals(List.of(), actual);

        // Act
        database.add(new Student(anna));

        // Assert
        actual = database.findStudentByName(anna);
        assertEquals(List.of(new Student(anna)), actual);
    }
}