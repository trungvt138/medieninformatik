package de.hawhamburg.v5;

import static de.hawhamburg.v5.Calculator.printNumber;

class Student {

    Student(int age) {
        printNumber(age);
        sleep();
    }

    void sleep() {

    }
}
