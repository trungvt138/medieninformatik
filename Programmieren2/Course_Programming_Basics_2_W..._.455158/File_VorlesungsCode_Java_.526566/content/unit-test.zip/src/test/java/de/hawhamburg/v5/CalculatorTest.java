package de.hawhamburg.v5;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test; //ju5

import static org.junit.jupiter.api.Assertions.assertEquals; //ju5

class CalculatorTest { // testklassen, testcode

    Calculator calculator = new Calculator(); // Attribute wird bei jedem Testfall neu zugewiesen

    @Test // testfall
    void addingTwoNumbersReturnTheCorrectResult() {
        // Arrange
        Calculator calculator = new Calculator();

        // Act (Aufruf der Methode, die man testen moechte)
        int actual = calculator.addition(1, 2);

        // Assert
        assertEquals(3, actual);
    }

    @Test // testfall
    void addingTwoNumbersWithOneBeingNegativeReturnTheCorrectResult() {
        int result = calculator.addition(-3, 5);
        assertEquals(2, result);
    }

    @Test // testfall
    void addLastA() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }

    @Test // testfall
    void addLastC() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }

    @Test // testfall
    void addLastB() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }
}
