package de.hawhamburg;

class Car implements Drivable {

    public void drive() {
        IO.println("Faehrt ganz schnell...");
    }

    public void accelerate() {
        IO.println("Accelerate");
    }

    public void breakNow() {

    }
}
