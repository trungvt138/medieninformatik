package de.hawhamburg;

import java.util.*;

public class Bicycle implements Drivable {

    public static void printAll(Iterable<Integer> numbers) {
        for (Integer number : numbers) {
            IO.println("number: " + number);
        }
    }

    public static void main(String[] args) {
//        arrays();
//        arrayList();
//        linkedList();
//        interfaces();
//        hashSet();
//        hashMap();
    }

    private static void hashMap() {
        // Map: Key kann beliebiger Typ sein und Value kann beliebiger Typ sein.
        Map<String, String> map = new HashMap<>();
        map.put("3", "String 1"); // key - value paar
        map.put("10", "String 2"); // key - value paar
        map.put("100245", "String 3"); // key - value paar
        if(map.containsKey("-1")) {
            IO.println(map.get("-1").length()); // value is ein String und hat einen Wert
        } else {
            IO.println("Fehler");
        }

        String value = map.get("-1");
        if(value != null) {
            IO.println(value.length()); // value is ein String und hat einen Wert
        } else {
            IO.println("Fehler");
            // null
        }

        IO.println(map.keySet());
        IO.println(map.values());

        var number = 5; // var statt int, Typ wird automatisch von Java inferiert (hergeleitet)
        for (var entry : map.entrySet()) {
            IO.println(entry.getKey() + " => " + entry.getValue());
        }
    }

    private static void hashSet() {
        Set<Integer> numbers = new HashSet<>();
        numbers.add(1);
        IO.println(numbers.add(2)); // true, weil hinzugefuegt wurde
        IO.println(numbers.add(2)); // false, weil duplikat und nicht hinzugefuegt wurde
        numbers.add(3);
        IO.println(numbers);
    }

    private static void interfaces() {
        Car car = new Car();
        Drivable drivableCar = car;

        car.breakNow();
        ArrayList<Drivable> drivables = new ArrayList<>();
        drivables.add(car);
        Drivable bicycle = new Bicycle();
        drivables.add(bicycle);
        for (Drivable drivable : drivables) {
            drivable.drive();
            drivable.accelerate();
        }

        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        printAll(list);
    }

    private static void linkedList() {
        LinkedList<Integer> numbers = new LinkedList<>();
        numbers.add(1);
        numbers.add(2); // soll removed werden
        numbers.add(3);
        numbers.add(4); // neues groesseres Array erzeugen, umkopieren und neuen Wert hinzuefuegen
        numbers.add(5); // neues groesseres Array erzeugen, umkopieren und neuen Wert hinzuefuegen
        IO.println("Zweites Element: " + numbers.get(1));
        numbers.remove(1);
        IO.println(numbers);
    }

    private static void arrayList() {
        ArrayList<Integer> numbers = new ArrayList<>(3);
        numbers.add(1);
        numbers.add(2); // soll removed werden
        numbers.add(3);
        numbers.add(4); // neues groesseres Array erzeugen, umkopieren und neuen Wert hinzuefuegen
        numbers.add(5); // neues groesseres Array erzeugen, umkopieren und neuen Wert hinzuefuegen
        IO.println("Zweites Element: " + numbers.get(1));
        numbers.remove(1);
        IO.println(numbers);
        // primitive Datentypen: int, long, float, double, short, byte, char
    }

    private static void arrays() {
        int [] numbers = new int[3];
        numbers[0] = 1;
        numbers[1] = 2;
        numbers[2] = 3;
        IO.println(Arrays.toString(numbers));

        int [] numbersBigger = new int[4];
        numbersBigger[3] = 4;

        IO.println(numbers[1]);

        for (int i = 0; i < numbers.length; i+=2) {
            IO.println(numbers[i]);
        }

        for (int number : numbers) {
            IO.println(number);
        }
    }

    public void drive() {
        IO.println("tuff tuff...");
    }

    @Override
    public void accelerate() {
        IO.println("accel...");
    }
}