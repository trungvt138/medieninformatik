package de.hawhamburg;

// Vertrag
public interface Drivable {

    default void drive() {
        IO.println("...");
    }

    void accelerate();
}
