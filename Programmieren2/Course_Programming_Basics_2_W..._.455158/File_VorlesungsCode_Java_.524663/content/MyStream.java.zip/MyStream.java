package de.hawhamburg.v4;

import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class MyStream {

    static void main() {
        List<String> names = List.of("Michael", "Anna", "Anna", "Andre", "Ola"); // immutable List
        // Intermediate Operationen
        //mapAndFilter(names);
        //tertiaererOperator();
        // sorted(names);
        // flatMap();
        // skipLimitDistinct(names);

        // Terminale Operationen
        // collect(names);
        // forEach(names);
        // anyAllNoneMatch(names);
        // count(names);
        // comparePrimitiveData();
        findAnyAndOptional();
    }

   // ---------------- Pseudo-Optional Nachimplementierung ---------------------

    private Student value;

    Student orElseThrow(Supplier<Exception> lambdaWithException) {
        if(value == null) {
            lambdaWithException.get(); // evaluate oder: Exception wird hier erst erzeugt (was langsam ist)
        }
        return value;
    }

    void orElseThrow(Exception ex) {
        // Warum wurde orElseThrow nicht so wie hier implementiert, wo das Exception-Objekt direkt übergeben wird?
    }

    // ---------------- Pseudo-Optional Nachimplementierung ---------------------

    private static void findAnyAndOptional() {
        record Student(String name) {}
        record Person(String name) {}

        List<Student> strings = List.of();
        Optional<Student> student = strings.stream().findAny(); // return kein null, wenn leer ist
        IO.println(student);

        Student result = student.orElse(new Student("noName"));

        Student andre = student.orElseThrow(() -> new RuntimeException()); // lazy evaluated (Exception erzeugen ist teuer)
        //Student andre2 = student.orElseThrow(new RuntimeException()); // das wäre nicht lazy, Exception wird immer hier zuerst erzeugt.

        IO.println(andre);

        IO.println(result);
        student.ifPresent(s -> IO.println(s.name()));

        // Student in Person umwandeln:
        Person person = student
            .map(s -> new Person(s.name()))
            .orElse(new Person("default"));
        IO.println(person);

//        if (student.isPresent()) { // ist wert vorhanden? Bad practice
//            String result = student.get();
//            IO.println(result); // ja: wert vorhanden. Garantiert ein Rueckgabewert
//        }

//        try {
//            String result = student.get();
//            IO.println(result);
//        } catch (NoSuchElementException e) {
//            // e.printStackTrace();
//        }
    }

    private static void comparePrimitiveData() {
        record Person(String name, int age) {}

        List<Person> persons = List.of(
            new Person("Bob", 21),
            new Person("Alice", 15),
            new Person("Jane", 20)
        );

        List<Person> result = persons.stream()
            .sorted((p1, p2) -> Integer.compare(p1.age(), p2.age()))
            .sorted(Comparator.comparingInt(Person::age))
            .toList();
        IO.println(result);
    }

    private static void count(List<String> names) {
        IO.println(names.stream().filter(name -> name.startsWith("An")).count()); // terminal
        IO.println(names.size());
    }

    private static void anyAllNoneMatch(List<String> names) {
        boolean anyMatch = names.stream().noneMatch(name -> {
            // fsdsdf
            return name.toLowerCase().contains("a");
        }); // anyMatch ist terminal wie toList
        IO.println(anyMatch);
    }

    private static void forEach(List<String> names) {
        names.stream().forEach(name -> IO.print(new Student(name))); // terminal. forEach ist nicht gleich map!!!!
    }

    private static void collect(List<String> names) {
        IO.println(names.stream().toList()); // immutable wie bei List.of

        Set<String> result = names.stream().collect(Collectors.toSet()); // mutable List
        result.add("Nicole");
        IO.println(result);
    }

    private static void skipLimitDistinct(List<String> names) {
        List<String> listWithoutDuplicates = names.stream().distinct().toList();
        IO.println(listWithoutDuplicates);
        List<String> listWithLimit = names.stream()
            .distinct()
            .skip(1)
            .limit(2)
            .toList();
        IO.println(listWithLimit);
    }

    private static void flatMap() {
        List<List<Object>> nestedNames = List.of(List.of("Andre", List.of("Anna")), List.of("Micheal", "Ola"));
        IO.println(nestedNames);
        List<Object> result = nestedNames.stream()
            .flatMap(list -> list.stream())
            .toList();
        IO.println(result);
    }

    private static void sorted(List<String> names) {
        List<String> result = names.stream()
            .sorted((nameA, nameB) -> nameA.compareTo(nameB))
            .toList();
        IO.println(result);
    }

    private static void tertiaererOperator() {
        boolean isOffline = true;
        if(isOffline) {
            IO.println("Ist offline");
            //
        //} else if(...) {
        } else {
            IO.println("Ist online");
            //
        }

        IO.println(isOffline ? "Ist offline" : "Ist online"); // tertiaerer operator
    }

    private static void mapAndFilter(List<String> names) {
        // for-each-Schreibweise (oldschool)
        List<String> result = new ArrayList<>();
        for (String name : names) {
            if(name.startsWith("An")) {
                result.add(name.toUpperCase());
            }
        }
        IO.println(result);

        // Stream<String> namesStreamDemo = Stream.of("Andre", "Anna", "Michael");
        List<Student> result2 = names.stream() // 1. Stream erzeugen
            // string-objekte
            .filter(name -> name.startsWith("An")) // 2. intermediate operation // lazy
            .map(name -> new Student(name.toUpperCase())) // lazy
            // student-objekte
            .toList(); // 3. terminale operation
        IO.println(result2);

        Stream<Student> result3 = names.stream() // 1. Stream erzeugen
            // string-objekte
            .filter(name -> name.startsWith("An")) // 2. intermediate operation // lazy
            .map(name -> new Student(name.toUpperCase())); // lazy
        // student-objekte
        // .toList(); // 3. terminale operation

        result3.toList(); // 1. terminale aufruf, danach ist der Stream geschlossen.
        // result3.filter(student -> student.name().startsWith("An")).toList(); // nicht erlaubt, da Stream geschlossen

        helper(result3);
    }

    static List<Student> helper(Stream<Student> students) { // bad practice
        return students.toList();
    }
}
