package de.hawhamburg.v2;

import java.time.LocalDate;
import java.util.*;

class Demo {

    void main(String[] args) {
        // wiederholung();
        // listMethoden();
        List<Student> students = new ArrayList<>();
        Student andre = new Student("Andre", null);

        IO.println(andre.hashCode());

        students.add(andre);
        Student anna = new Student("Andre", "Jewp");
        IO.println(anna.hashCode());

        students.add(anna);
        students.add(new Student("Bela", "Rus"));
        IO.println(students.contains(new Student("Andre", null)));

        Set<Student> studentSet = new HashSet<>(students);

        Map<Student, String> map = new HashMap<>();
        map.put(andre, "Hamburg");


        // Collections.shuffle(numbers);
    }

    private static void listMethoden() {
        Set<Integer> other = new HashSet<>();
        other.add(2);
        other.add(3);

        List<Integer> list = new ArrayList<>(other);
        list.add(1);
        // addAll

        IO.println(list);
        IO.println(list.size());
        IO.println(list.isEmpty());
    }

    private void wiederholung() {
        IO.println("Hello");

        int[] array = {1, 2}; // primitive
        IO.println(array[0]);

        List<Integer> list;

        Map<Double, LocalDate> map = new HashMap<>();
        map.put(0.1, LocalDate.now());

        LocalDate localDate = map.get(0.1);
    }
}