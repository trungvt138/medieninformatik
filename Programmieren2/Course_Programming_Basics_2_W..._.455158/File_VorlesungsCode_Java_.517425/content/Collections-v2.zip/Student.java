package de.hawhamburg.v2;

import java.util.Objects;

class Student extends Object {

    String firstName;
    String lastName;

    Student(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Student other
                && Objects.equals(this.firstName, other.firstName)
                && Objects.equals(this.lastName, other.lastName)
        );
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.firstName, this.lastName);
    }

    String getFirstName() {
        return firstName;
    }
}
