package de.hawhamburg.v3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Lambda {

    void main() {
        List<Student> students = new ArrayList<>();
        students.add(new Student("Maria", "Schmidt"));
        students.add(new Student("Andre", "Jewo"));
        students.add(new Student("Anna", "Bell"));

        Collections.sort(students, (o1, o2) -> o1.firstName().compareTo(o2.firstName()));
        Collections.sort(students, (o1, o2) -> o1.lastName().compareTo(o2.lastName()));

        Collections.sort(students, new SortByLastNameComparator());
        Collections.sort(students, (o1, o2) -> o1.firstName().compareTo(o2.firstName()));
        Collections.sort(students, (o1,  o2) -> {
            // Weitere Zeilen moeglich.
            return o1.firstName().compareTo(o2.firstName());
        });

        IO.println(students);

        List<Integer> numbers = new ArrayList<>(List.of(1,4,3));
        Collections.sort(numbers);
        IO.println(numbers);
    }
}
