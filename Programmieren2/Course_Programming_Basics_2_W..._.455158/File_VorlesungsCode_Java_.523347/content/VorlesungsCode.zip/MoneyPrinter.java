package de.hawhamburg.v3;

@FunctionalInterface
interface MoneyPrinter {
    void value(int amount);

    static void anotherValue(int amount) {
        IO.println(amount + " Yuan");
    }

    static void main() {
        MoneyPrinter euro = (amount) -> IO.println(amount + " Euro"); // Lazy evaluation
        euro.value(42); // evaluate lambda | führe das Lambda aus

        MoneyPrinter dollar = amount -> {
            IO.println(amount + " Dollar");
        }; // Lazy evaluation

        MoneyPrinter lire = amount -> {
        }; // Lazy evaluation
        dollar.value(43); // evaluate lambda | führe das Lambda aus

        MoneyPrinter yuan = MoneyPrinter::anotherValue;
        yuan.value(44);
    }
}
