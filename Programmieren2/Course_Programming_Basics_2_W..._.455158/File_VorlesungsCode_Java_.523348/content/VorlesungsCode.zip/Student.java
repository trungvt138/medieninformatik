package de.hawhamburg.v4;

record Student(String name) {

    @Override
    public String toString() {
        return "Student: " + name;
    }
}