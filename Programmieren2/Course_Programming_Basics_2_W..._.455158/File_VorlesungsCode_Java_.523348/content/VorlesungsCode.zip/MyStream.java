package de.hawhamburg.v4;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class MyStream {

    static void main() {
        List<String> names = List.of("Michael", "Anna", "Anna", "Andre", "Ola"); // immutable List
        // Intermediate Operationen
        //mapAndFilter(names);
        //tertiaererOperator();
        // sorted(names);
        // flatMap();
        // skipLimitDistinct(names);

        // Terminale Operationen
        // collect(names);
        // forEach(names);
        // anyAllNoneMatch(names);
        // count(names);
        findAnyAndOptional();
    }

    private static void findAnyAndOptional() {
        Optional<String> name = List.of("Andre").stream().findAny(); // return kein null, wenn leer ist
        IO.println(name.orElse("defaultName")); // optional.isEmpty
    }

    private static void count(List<String> names) {
        IO.println(names.stream().filter(name -> name.startsWith("An")).count()); // terminal
        IO.println(names.size());
    }

    private static void anyAllNoneMatch(List<String> names) {
        boolean anyMatch = names.stream().noneMatch(name -> {
            // fsdsdf
            return name.toLowerCase().contains("a");
        }); // anyMatch ist terminal wie toList
        IO.println(anyMatch);
    }

    private static void forEach(List<String> names) {
        names.stream().forEach(name -> IO.print(new Student(name))); // terminal. forEach ist nicht gleich map!!!!
    }

    private static void collect(List<String> names) {
        IO.println(names.stream().toList()); // immutable wie bei List.of

        Set<String> result = names.stream().collect(Collectors.toSet()); // mutable List
        result.add("Nicole");
        IO.println(result);
    }

    private static void skipLimitDistinct(List<String> names) {
        List<String> listWithoutDuplicates = names.stream().distinct().toList();
        IO.println(listWithoutDuplicates);
        List<String> listWithLimit = names.stream()
            .distinct()
            .skip(1)
            .limit(2)
            .toList();
        IO.println(listWithLimit);
    }

    private static void flatMap() {
        List<List<Object>> nestedNames = List.of(List.of("Andre", List.of("Anna")), List.of("Micheal", "Ola"));
        IO.println(nestedNames);
        List<Object> result = nestedNames.stream()
            .flatMap(list -> list.stream())
            .toList();
        IO.println(result);
    }

    private static void sorted(List<String> names) {
        List<String> result = names.stream()
            .sorted((nameA, nameB) -> nameA.compareTo(nameB))
            .toList();
        IO.println(result);
    }

    private static void tertiaererOperator() {
        boolean isOffline = true;
        if(isOffline) {
            IO.println("Ist offline");
            //
        //} else if(...) {
        } else {
            IO.println("Ist online");
            //
        }

        IO.println(isOffline ? "Ist offline" : "Ist online"); // tertiaerer operator
    }

    private static void mapAndFilter(List<String> names) {
        // for-each-Schreibweise (oldschool)
        List<String> result = new ArrayList<>();
        for (String name : names) {
            if(name.startsWith("An")) {
                result.add(name.toUpperCase());
            }
        }
        IO.println(result);

        // Stream<String> namesStreamDemo = Stream.of("Andre", "Anna", "Michael");
        List<Student> result2 = names.stream() // 1. Stream erzeugen
            // string-objekte
            .filter(name -> name.startsWith("An")) // 2. intermediate operation // lazy
            .map(name -> new Student(name.toUpperCase())) // lazy
            // student-objekte
            .toList(); // 3. terminale operation
        IO.println(result2);

        Stream<Student> result3 = names.stream() // 1. Stream erzeugen
            // string-objekte
            .filter(name -> name.startsWith("An")) // 2. intermediate operation // lazy
            .map(name -> new Student(name.toUpperCase())); // lazy
        // student-objekte
        // .toList(); // 3. terminale operation

        result3.toList(); // 1. terminale aufruf, danach ist der Stream geschlossen.
        // result3.filter(student -> student.name().startsWith("An")).toList(); // nicht erlaubt, da Stream geschlossen

        helper(result3);
    }

    static List<Student> helper(Stream<Student> students) { // bad practice
        return students.toList();
    }
}
