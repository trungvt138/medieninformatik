package de.hawhamburg.filesystem;

class File extends FileSystemElement {

    private long size;

    File(String name, int size) {
        super(name);
        this.size = size;
    }

    @Override
    long fetchSize() {
        return size;
    }

    @Override
    boolean contains(FileSystemElement element) {
        return false;
    }
}