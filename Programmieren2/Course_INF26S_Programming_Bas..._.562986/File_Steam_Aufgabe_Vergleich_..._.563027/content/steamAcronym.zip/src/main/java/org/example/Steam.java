package org.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

class Steam {
    private final Collection<Game> library = new ArrayList<>();
    public Steam() {
        library.addAll(List.of(
                new Game("Horizon Zero Dawn", 743.1),
                new Game("Monkey Island 2: LeChuck's Revenge", 367.2),
                new Game("A Plague Tale: Innocence", 409.3),
                new Game("XOM 2", 664.4),
                new Game("Palworld", 1000.0), // most popular
                new Game("Return to Monkey Island", 331.5),
                new Game("Mario Kart", 782.8),
                new Game("A Plague Tale: Requiem", 535.0),
                new Game("A Way Out", 84.6),
                new Game("The Secret of Monkey Island", 567.2)
        ));
    }

    //Mit Streams aus der Lösung:
    public Collection<Game> findAllGamesWithAcronymizedNames() {
        return library.stream()
                .map(game -> {
                    var words = game.name().split(" ");
                    StringBuilder acronymizedName = new StringBuilder();
                    for (String word : words) {
                        char firstLetter = word.charAt(0);
                        acronymizedName.append(firstLetter);
                    }
                    return new Game(acronymizedName.toString(), game.popularity());
                })
                .toList();
    }

    //Ohne Streams:
    public Collection<Game> findAllGamesWithAcronymizedNamesWithoutStreams() {
        // 1. Ergebnis-Liste vorbereiten (ersetzt den Collector)
        Collection<Game> acronymizedGames = new ArrayList<>();

        // 2. Durch alle Spiele iterieren (ersetzt .stream())
        for (Game game : library) {

            // 3. Die Transformations-Logik (ehemals im .map())
            String[] words = game.name().split(" ");
            StringBuilder acronymizedName = new StringBuilder();

            for (String word : words) {
                // Sicherheitscheck: Verhindert Fehler bei doppelten Leerzeichen
                if (!word.isEmpty()) {
                    char firstLetter = word.charAt(0);
                    acronymizedName.append(firstLetter);
                }
            }

            // 4. Das neue Game-Objekt zur Liste hinzufügen
            acronymizedGames.add(new Game(acronymizedName.toString(), game.popularity()));
        }

        // 5. Die gefüllte Liste zurückgeben
        return acronymizedGames;
    }

    static  void main(String[] args) {
        Steam steam = new Steam();
        System.out.println(steam.findAllGamesWithAcronymizedNames());

        System.out.println(steam.findAllGamesWithAcronymizedNamesWithoutStreams());
    }
}
