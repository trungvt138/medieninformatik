package org.example;

record Game(String name, double popularity) {
    @Override
    public String toString() {
        return name + " (" + popularity + ')';
    }
}
