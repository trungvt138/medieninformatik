package org.example;

import org.junit.jupiter.api.Test;

import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

class SteamTest {

    // Vergleichstest: Consistency Check als Refactoring-Absicherung
    // Dieser Test prüft nur, ob beide Methoden das Gleiche tun, aber nicht unbedingt, ob sie das Richtige tun.
    @Test
    void findAllGamesWithAcronymizedNamesWithoutStreams() {
        //Arrange
        Steam steam = new Steam();
        Collection<Game> withStreams = steam.findAllGamesWithAcronymizedNames();

        //Act
        Collection<Game> withoutStreams = steam.findAllGamesWithAcronymizedNamesWithoutStreams();

        //Assert
        assertEquals(withStreams, withoutStreams);
    }
}