package org.example;

class Fibonacci {
    // Iterative Lösung: Effizienter (O(n)), da keine Stack-Overflow-Gefahr besteht
    static long fibonacciIterative(int n) {
        // WICHTIG: Prüfung der Basisfälle. Wenn n 0 oder 1 ist, ist das Ergebnis n selbst.
        // Dies deckt die ersten beiden Zahlen der Fibonacci-Folge ab.
        if (n <= 1) {
            return n;
        }

        // Initialisierung der zwei Vorgänger-Zahlen (F(n-2) und F(n-1))
        long prev1 = 0; // Entspricht F(0)
        long prev2 = 1; // Entspricht F(1)
        long current = 0;

        // Schleife beginnt bei 2, da 0 und 1 bereits oben behandelt wurden.
        // Wir berechnen iterativ hoch bis n.
        for (int i = 2; i <= n; i++) {
            current = prev1 + prev2; // Berechnet F(i) = F(i-2) + F(i-1)

            // WICHTIG: Verschieben der Werte ("Fenster" rückt eins weiter)
            // Der alte prev2 wird zum neuen prev1 (F(i-1) wird zu F(i-2) für den nächsten Schritt)
            prev1 = prev2;
            // Der gerade berechnete Wert wird zum direkten Vorgänger für den nächsten Schritt
            prev2 = current;
        }
        return current;
    }

    // Rekursive Lösung: Direkte Umsetzung der mathematischen Definition
    static long fibonacci(int n) {
        // WICHTIG: Die Abbruchbedingung (Base Case).
        // Ohne diese Prüfung würde die Rekursion unendlich laufen (StackOverflowError).
        // F(0) = 0, F(1) = 1.
        if (n <= 1)
            return n;

        // WICHTIG: Der rekursive Schritt.
        // Die Funktion ruft sich selbst auf, um die Teilprobleme zu lösen.
        // Die Ergebnisse der beiden vorherigen Zahlen werden addiert: F(n) = F(n-1) + F(n-2).
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}