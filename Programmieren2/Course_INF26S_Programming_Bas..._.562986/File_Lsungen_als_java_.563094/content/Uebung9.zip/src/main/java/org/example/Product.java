package org.example;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

// Composite (Kompositum): Kann Kinder (Parts) enthalten
class Product extends Component {
    // Speichert sowohl Material (Leaf) als auch andere Products (Composites)
    private final List<Component> parts = new LinkedList<>();

    public Product(String name, int price) {
        super(name, price);
    }

    // Fügt Komponenten mehrfach hinzu (Simulation von Stückzahlen)
    public void addPart(Component part, Integer amount) {
        for (int i = 0; i < amount; i++)
            parts.add(part);
    }

    @Override
    public boolean contains(Component component) {
        // Iteriert durch alle direkten Kinder
        for (Component part : parts) {
            // Prüfung 1: Ist das Kind selbst die gesuchte Komponente? (part.equals)
            // Prüfung 2: Rekursion - Enthält das Kind (falls es ein Product ist) die Komponente? (part.contains)
            if (part.equals(component) || part.contains(component)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Integer fetchTotalPrice() {
        int result = price; // Startwert ist der Eigenpreis des Produkts
        // Rekursive Summation aller Teilepreise
        for (Component part : parts)
            result += part.fetchTotalPrice(); // Polymorpher Aufruf (egal ob Material oder Product)
        return result;
    }

    @Override
    public List<Material> fetchMaterialList() {
        var result = new LinkedList<Material>();
        // Delegiert das Sammeln an die Kinder weiter (Rekursion)
        for (Component part : parts)
            result.addAll(part.fetchMaterialList());
        // Gibt eine unmodifizierbare Liste zurück (Good Practice)
        return Collections.unmodifiableList(result);
    }
}