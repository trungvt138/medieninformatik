package org.example;

abstract class FileSystemElement {

    protected String name;

    FileSystemElement(String name) {
        this.name = name;
    }

    abstract long fetchSize();

    abstract boolean contains(FileSystemElement element);
}