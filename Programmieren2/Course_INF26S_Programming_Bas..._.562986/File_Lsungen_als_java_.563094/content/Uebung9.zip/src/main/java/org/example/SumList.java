package org.example;

import java.util.LinkedList;
import java.util.List;

final class SumList {

    // Ansatz 1: Rekursion über "Head" und "Tail" (Listen-Sicht)
    static double sumWithRemaining(List<Integer> numbers) {
        // Abbruchbedingung (Base Case): Eine leere Liste hat die Summe 0.
        // Dies beendet die Rekursion.
        if (numbers.isEmpty())
            return 0;

        // Rekursiver Schritt: Wir nehmen das erste Element (Head)
        // und addieren das Ergebnis des rekursiven Aufrufs mit der Rest-Liste (Tail).
        return numbers.getFirst() + sumWithRemaining(remaining(numbers));
    }

    private static List<Integer> remaining(List<Integer> numbers) {
        // Erzeugt eine "Sicht" (View) auf den Rest der Liste (Index 1 bis Ende).
        // Wichtig: Es werden keine Elemente kopiert, was Speicher spart.
        return numbers.subList(1, numbers.size());
    }

    // Ansatz 2: Rekursion über einen Index (Pointer-Arithmetik Simulation)
    static double sumWithIndex(List<Integer> numbers) {
        return sumWithIndex(numbers, 0); // Startet die Rekursion beim Index 0
    }

    // MethodOverloading: Hilfsmethode, die den aktuellen Index mitführt
    static double sumWithIndex(List<Integer> numbers, int index) {
        // Abbruchbedingung: Wenn der Index die Listengröße erreicht, sind wir fertig.
        // Entspricht dem Ende einer for-Schleife (i < size).
        if (index >= numbers.size())
            return 0;

        // Rekursiver Schritt: Element am aktuellen Index holen + Rekursion für den nächsten Index.
        // Die Liste selbst bleibt dabei unverändert.
        return numbers.get(index) + sumWithIndex(numbers, index + 1);
    }

    // Ansatz 3: Rekursion durch destruktives Verkleinern der Liste
    static double sumWithHelper(List<Integer> numbers) {
        // WICHTIG: Kopieren in eine veränderbare Liste (LinkedList).
        // Nötig, weil 'List.of(...)' immutable (unveränderbar) ist und 'removeFirst' sonst crashen würde.
        // LinkedList ist hier effizienter für das Entfernen am Anfang (O(1)).
        return sumInternal(new LinkedList<>(numbers));
    }

    private static double sumInternal(List<Integer> numbers) {
        // Abbruchbedingung: Wenn die Liste leer "geräumt" ist, ist die Summe 0.
        if (numbers.isEmpty())
            return 0;

        // Rekursiver Schritt: Das erste Element wird physisch entfernt (Verkleinerung des Problems)
        // und zum Ergebnis des Restes addiert.
        return numbers.removeFirst() + sumInternal(numbers);
    }

    static void main(String[] args) {
        System.out.println(sumWithRemaining(List.of(1, 2, 3, 4, 5))); // soll 15.0 sein
        System.out.println(sumWithIndex(List.of(1, 0, -2))); // -1.0
        System.out.println(sumWithHelper(List.of(0))); // 0.0
    }
}