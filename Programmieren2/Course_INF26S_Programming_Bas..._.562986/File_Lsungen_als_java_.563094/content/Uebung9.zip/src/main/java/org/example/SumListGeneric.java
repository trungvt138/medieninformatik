package org.example;

import java.util.LinkedList;
import java.util.List;

final class SumListGeneric {

    // WICHTIG: "? extends Number" (Upper Bounded Wildcard) erlaubt Listen
    // von jedem Typ, der von Number erbt (z.B. Integer, Double, Long).
    static double sumWithRemaining(List<? extends Number> numbers) {
        // Abbruchbedingung (Base Case): Rekursion endet bei leerer Liste.
        if (numbers.isEmpty())
            return 0;

        // Rekursiver Schritt: Wert des ersten Elements + Summe der Restliste.
        // Hilfsmethoden 'first' und 'remaining' abstrahieren den Zugriff.
        return first(numbers) + sumWithRemaining(remaining(numbers));
    }

    private static double first(List<? extends Number> numbers) {
        // Da wir den genauen Typ (Integer, Double) nicht kennen, nutzen wir .doubleValue()
        // der Klasse Number, um einen gemeinsamen Rechentyp (double) zu erhalten.
        return numbers.getFirst().doubleValue(); // alternativ return (double)numbers.getFirst();
    }

    // WICHTIG: Hier wird ein Typparameter <T> verwendet statt Wildcard.
    // Das stellt sicher, dass subList den gleichen Listentyp zurückgibt, der reinkam.
    private static <T extends Number> List<T> remaining(List<T> numbers) {
        return numbers.subList(1, numbers.size()); // returns a View on the original list (no elements are copied)
    }

    // Ansatz 2: Index-basiert (vermeidet Erzeugung neuer Listen-Objekte)
    static double sumWithIndex(List<? extends Number> numbers) {
        return sumWithIndex(numbers, 0); // start with index at 0
    }

    // Hilfsmethode führt den Index als Status mit
    static double sumWithIndex(List<? extends Number> numbers, int index) { // helper method
        // Abbruchbedingung: Wenn Index außerhalb der Liste, ist die Summe 0.
        if (index >= numbers.size())
            return 0;

        // Zugriff über Index und Umwandlung in double für die Addition.
        return numbers.get(index).doubleValue() + sumWithIndex(numbers, index + 1);
    }

    // Ansatz 3: Destruktiv (Liste wird geleert)
    static double sumWithHelper(List<? extends Number> numbers) {
        // WICHTIG: Kopieren in eine LinkedList (mutable), da wir Elemente entfernen wollen.
        // Dies schützt davor, dass z.B. List.of() (immutable) eine Exception wirft.
        return sumInternal(new LinkedList<>(numbers));
    }

    private static double sumInternal(List<? extends Number> numbers) {
        // Abbruchbedingung: Liste ist leer.
        if (numbers.isEmpty())
            return 0;

        // removeFirst() liefert das Element UND entfernt es aus der Liste.
        // Auch hier zwingend .doubleValue() für die Arithmetik.
        return numbers.removeFirst().doubleValue() + sumInternal(numbers);
    }

    public static void main(String[] args) {
        // Beweis der Flexibilität: Funktioniert mit Integer...
        System.out.println(sumWithIndex(List.of(1, 2, 3, 4, 5))); // 15.0
        System.out.println(sumWithHelper(List.of(1, 0, -2))); // -1.0
        System.out.println(sumWithRemaining(List.of(0))); // 0.0

        // ...und funktioniert nahtlos mit Double.
        System.out.println(sumWithIndex(List.of(1.1, 0.0, -2.2))); // -1.1
    }
}