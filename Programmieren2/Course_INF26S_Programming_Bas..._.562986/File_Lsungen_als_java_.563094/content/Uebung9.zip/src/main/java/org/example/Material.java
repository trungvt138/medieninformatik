package org.example;

import java.util.List;

// Leaf (Blatt): Das Ende der Rekursion
class Material extends Component {
    public Material(String name, int price) {
        super(name, price);
    }

    // Abbruchbedingung für Suche: Ein Material kann nichts enthalten.
    @Override
    public boolean contains(Component component) {
        return false;
    }

    // Abbruchbedingung für Preis: Gibt nur den eigenen Preis zurück.
    @Override
    public Integer fetchTotalPrice() {
        return price;
    }

    // Abbruchbedingung für Liste: Gibt eine Liste zurück, die nur sich selbst enthält.
    @Override
    public List<Material> fetchMaterialList() {
        return List.of(this);
    }
}