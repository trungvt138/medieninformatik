package org.example;

import java.util.LinkedList;
import java.util.List;

class Directory extends FileSystemElement {

    private final List<FileSystemElement> elements = new LinkedList<>();

    Directory(String name) {
        super(name);
    }

    boolean add(FileSystemElement element) {
        return elements.add(element);
    }

    boolean remove(FileSystemElement element) {
        return elements.remove(element);
    }

    @Override
    long fetchSize() {
        long result = 0;
        for (FileSystemElement element : elements) {
            result += element.fetchSize();
        }
        return result;
    }

    @Override
    boolean contains(FileSystemElement element) {
        for (FileSystemElement childElement : elements) {
            if (childElement.equals(element) || childElement.contains(element)) {
                return true;
            }
        }
        return false;
    }
}
