package org.example;

import java.util.List;

// Abstrakte Basisklasse für das Composite Pattern
abstract class Component {
    protected String name;
    protected Integer price;

    public Component(String name, int price) {
        this.name = name;
        this.price = price;
    }

    // WICHTIG: Abstrakte Methoden erzwingen unterschiedliche Implementierungen
    // für Blatt (Material) und Kompositum (Product).
    public abstract boolean contains(Component component);
    public abstract Integer fetchTotalPrice();
    public abstract List<Material> fetchMaterialList();

    @Override
    public String toString() {
        return name;
    }
}