package org.example;

class SearchArray {
    // Rekursive Methode für die lineare Suche.
    // Der Parameter 'index' ersetzt hier die Zählvariable 'i' einer for-Schleife.
    static int search(int[] array, int target, int index) {
        // WICHTIG: Erste Abbruchbedingung (Base Case "Nicht gefunden").
        // Wenn der Index die Länge des Arrays erreicht, haben wir alles geprüft
        // und das Ziel nicht gefunden. Schützt zudem vor IndexOutOfBoundsException.
        if (index >= array.length) {
            return -1;
        }

        // WICHTIG: Zweite Abbruchbedingung (Base Case "Gefunden").
        // Prüft, ob das Element an der aktuellen Position dem Ziel entspricht.
        if (array[index] == target) {
            return index;
        }

        // Rekursiver Schritt: Die Methode ruft sich selbst auf, erhöht aber den Index um 1.
        // Das entspricht dem 'i++' im Schleifenkopf. Wir suchen im "Rest" des Arrays weiter.
        return search(array, target, index + 1);
    }

    public static void main(String[] args) {
        int[] array = {3, 5, 7, 9, 11, 13, 15};
        int target = 9;

        // Start des Algorithmus bei Index 0 (entspricht int i = 0).
        int result = search(array, target, 0);

        if (result != -1) {
            System.out.println("Element " + target + " gefunden an Index " + result);
        } else {
            System.out.println("Element " + target + " nicht gefunden.");
        }
    }
}