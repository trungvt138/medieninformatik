package org.example;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SumListGenericTest {

    // Testet den "Happy Path" (Standardfall) mit positiven Integern.
    // Dient zur Verifizierung, dass die generische Logik (T extends Number) grundsätzlich funktioniert.
    @Test
    void sumWithPositiveNumbers() {
        // Aufruf der Klasse SumListGeneric statt SumList.
        // Wir erwarten hier, dass die Methode auch mit Integer-Listen umgehen kann,
        // obwohl der Rückgabewert vermutlich double ist.
        var actual = SumListGeneric.sumWithHelper(List.of(1, 2, 3, 4, 5));
        assertEquals(15, actual);
    }

    // Testet die korrekte Verarbeitung von negativen Vorzeichen.
    // Wichtig für rekursive Addition, um sicherzustellen, dass nicht versehentlich subtrahiert
    // oder Beträge gebildet werden.
    @Test
    void sumWithNegativeNumbers() {
        // Testet speziell die Index-basierte Implementierung in der generischen Klasse.
        var actual = SumListGeneric.sumWithIndex(List.of(-1, -2, -3, -4, -5));
        assertEquals(-15, actual);
    }

    // Komplexerer Fall: Mischung aus positiven, negativen Zahlen und Null.
    // Testet, ob der rekursive Abstieg (Sublist) den State korrekt übergibt
    // und die Arithmetik (-1 + 2 = 1) stimmt.
    @Test
    void sumWithMixedNumbers() {
        // Hier wird geprüft, ob 'sumWithRemaining' korrekt mit Generics arbeitet.
        var actual = SumListGeneric.sumWithRemaining(List.of(-1, 2.5, 0, -3, 4, -5));
        assertEquals(-2.5, actual);
    }

    // Wichtiger Randfall (Edge Case): Leere Liste.
    // Dies testet die Abbruchbedingung der Rekursion.
    // Ohne diesen Test könnte die Methode bei Index 0 crashen (IndexOutOfBounds)
    // oder endlos laufen.
    @Test
    void sumWithEmptyIsZero() {
        var actual = SumListGeneric.sumWithIndex(List.of());
        assertEquals(0, actual);
    }

    // Randfall: Liste mit genau einem Element (hier 0, das neutrale Element der Addition).
    // Prüft, ob die Rekursion sofort im ersten Schritt korrekt terminiert
    // und nicht versucht, auf Index 1 zuzugreifen.
    @Test
    void sumWithZeroIsZero() {
        var actual = SumListGeneric.sumWithIndex(List.of(0));
        assertEquals(0, actual);
    }

    // ZUSATZ: Da die Klasse "Generic" heißt, wäre ein Test mit Double sinnvoll,
    // um die Typflexibilität wirklich zu beweisen.
    @Test
    void sumWithDoubles() {
        // Prüft, ob die Generics auch Gleitkommazahlen akzeptieren.
        var actual = SumListGeneric.sumWithIndex(List.of(1.5, 2.5, 3.0));
        assertEquals(7.0, actual);
    }
}