package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class FibonacciTest {
    // Tests für die iterative Implementierung

    // WICHTIG: Testen der Randfälle (Edge Cases) 0 und 1 ist essenziell,
    // da hier die Logik oft von der Schleife/Rekursion abweicht.
    @Test
    void fibonacciIterativeWith0() { assertEquals(0, Fibonacci.fibonacciIterative(0)); } // Erwartet 0
    @Test
    void fibonacciIterativeWith1() { assertEquals(1, Fibonacci.fibonacciIterative(1)); } // Erwartet 1

    // Tests der regulären Logik (n >= 2)
    @Test
    void fibonacciIterativeWith2() { assertEquals(1, Fibonacci.fibonacciIterative(2)); } // 0 + 1 = 1
    @Test
    void fibonacciIterativeWith3() { assertEquals(2, Fibonacci.fibonacciIterative(3)); } // 1 + 1 = 2
    @Test
    void fibonacciIterativeWith4() { assertEquals(3, Fibonacci.fibonacciIterative(4)); } // 1 + 2 = 3
    @Test
    void fibonacciIterativeWith5() { assertEquals(5, Fibonacci.fibonacciIterative(5)); }
    @Test
    void fibonacciIterativeWith6() { assertEquals(8, Fibonacci.fibonacciIterative(6)); }
    @Test
    void fibonacciIterativeWith7() { assertEquals(13, Fibonacci.fibonacciIterative(7)); }
    @Test
    void fibonacciIterativeWith8() { assertEquals(21, Fibonacci.fibonacciIterative(8)); }
    @Test
    void fibonacciIterativeWith9() { assertEquals(34, Fibonacci.fibonacciIterative(9)); }
    @Test
    void fibonacciIterativeWith10() { assertEquals(55, Fibonacci.fibonacciIterative(10)); }

    // Tests für die rekursive Implementierung

    // Auch hier: Prüfung, ob die Abbruchbedingung (Base Case) korrekt greift
    @Test
    void fibonacciWith0() { assertEquals(0, Fibonacci.fibonacci(0)); }
    @Test
    void fibonacciWith1() { assertEquals(1, Fibonacci.fibonacci(1)); }

    // Prüfung, ob der rekursive Abstieg und Aufstieg korrekt summieren
    @Test
    void fibonacciWith2() { assertEquals(1, Fibonacci.fibonacci(2)); }
    @Test
    void fibonacciWith3() { assertEquals(2, Fibonacci.fibonacci(3)); }
    @Test
    void fibonacciWith4() { assertEquals(3, Fibonacci.fibonacci(4)); }
    @Test
    void fibonacciWith5() { assertEquals(5, Fibonacci.fibonacci(5)); }
    @Test
    void fibonacciWith6() { assertEquals(8, Fibonacci.fibonacci(6)); }
    @Test
    void fibonacciWith7() { assertEquals(13, Fibonacci.fibonacci(7)); }
    @Test
    void fibonacciWith8() { assertEquals(21, Fibonacci.fibonacci(8)); }
    @Test
    void fibonacciWith9() { assertEquals(34, Fibonacci.fibonacci(9)); }
    @Test
    void fibonacciWith10() { assertEquals(55, Fibonacci.fibonacci(10)); }
}