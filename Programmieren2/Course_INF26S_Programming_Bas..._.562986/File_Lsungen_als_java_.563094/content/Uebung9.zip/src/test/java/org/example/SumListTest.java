package org.example;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SumListTest {
    // Testet Ansatz 3 (Kopie + Remove) mit positiven Zahlen
    @Test
    void sumWithPositiveNumbers() {
        var actual = SumList.sumWithHelper(List.of(1, 2, 3, 4, 5));
        assertEquals(15, actual);
    }

    // Testet Ansatz 2 (Index) mit negativen Zahlen
    @Test
    void sumWithNegativeNumbers() {
        var actual = SumList.sumWithIndex(List.of(-1, -2, -3, -4, -5));
        assertEquals(-15, actual);
    }

    // Testet Ansatz 1 (Sublist) mit gemischten Zahlen
    // Hier wird geprüft, ob die Vorzeichen korrekt verrechnet werden.
    @Test
    void sumWithMixedNumbers() {
        var actual = SumList.sumWithRemaining(List.of(-1, 2, 0, -3, 4, -5));
        assertEquals(-3, actual);
    }

    // Wichtiger Randfall: Leere Liste
    // Prüft, ob die Abbruchbedingung (if isEmpty return 0) in Ansatz 2 greift.
    @Test
    void sumWithEmptyIsZero() {
        var actual = SumList.sumWithIndex(List.of());
        assertEquals(0, actual);
    }

    // Wichtiger Randfall: Liste mit Wert 0
    // Prüft, ob die Rekursion auch bei einem einzelnen Element (n=1) korrekt terminiert.
    @Test
    void sumWithZeroIsZero() {
        var actual = SumList.sumWithIndex(List.of(0));
        assertEquals(0, actual);
    }
}