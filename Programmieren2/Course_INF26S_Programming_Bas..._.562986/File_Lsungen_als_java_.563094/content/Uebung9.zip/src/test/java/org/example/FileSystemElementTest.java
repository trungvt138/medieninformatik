package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileSystemElementTest {

    private Directory dir1;
    private Directory dir3;
    private Directory dir2;
    private Directory dir4;
    private File file1;
    private File file2;
    private File file3;

    @BeforeEach
    void setUp() {
        dir1 = new Directory("dir1");
        file1 = new File("file1", 5);
        dir1.add(file1);
        dir2 = new Directory("dir2");
        dir1.add(dir2);
        dir3 = new Directory("dir3");
        dir2.add(dir3);
        dir4 = new Directory("dir4");
        dir2.add(dir4);
        file2 = new File("file2", 10);
        dir3.add(file2);
        file3 = new File("file3", 20);
        dir3.add(file3);
    }

    @Test
    void dir4FetchSize() {
        assertEquals(0, dir4.fetchSize());
    }

    @Test
    void dir3FetchSize() {
        assertEquals(30, dir3.fetchSize());
    }

    @Test
    void file1FetchSize() {
        assertEquals(5, file1.fetchSize());
    }

    @Test
    void dir1FetchSize() {
        assertEquals(35, dir1.fetchSize());
    }

    @Test
    void dir4ContainsNothing() {
        assertFalse(dir4.contains(file2));
    }

    @Test
    void dir4DoesNotContainDir4() {
        assertFalse(dir4.contains(dir4));
    }

    @Test
    void dir3ContainsFile2() {
        assertTrue(dir3.contains(file2));
        assertTrue(dir3.contains(file3));
    }

    @Test
    void dir3DoesNotContainFile1() {
        assertFalse(dir3.contains(file1));
    }

    @Test
    void dir1ContainsFile2() {
        assertTrue(dir1.contains(file2));
    }
}