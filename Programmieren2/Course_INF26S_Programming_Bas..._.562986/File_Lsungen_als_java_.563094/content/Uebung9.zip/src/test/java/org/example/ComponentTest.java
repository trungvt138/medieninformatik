package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.*;

class ComponentTest {
    private Product p1;
    private Product p2;
    private Material m1;
    private Material m2;
    private Material m3;

    @BeforeEach
    void setUp() {
        // Aufbau einer Baumstruktur für die Tests (Composite Pattern)
        p1 = new Product("p1", 5);  // Wurzel
        p2 = new Product("p2", 10); // Unter-Knoten (Composite)

        // p1 enthält p2 zweimal (Rekursiver Aufbau)
        p1.addPart(p2, 2);

        m1 = new Material("m1", 1); // Blatt (Leaf)
        p1.addPart(m1, 5);

        m2 = new Material("m2", 2);
        p2.addPart(m2, 2);

        m3 = new Material("m3", 3);
        p2.addPart(m3, 10);

        // Struktur:
        // P2 Kosten = 10 (Eigen) + 2*2 (M2) + 10*3 (M3) = 10 + 4 + 30 = 44
        // P1 Kosten = 5 (Eigen) + 2*44 (P2) + 5*1 (M1) = 5 + 88 + 5 = 98
    }

    // Testet, ob die rekursive Suche (contains) auch tief verschachtelte Elemente findet
    @Test
    void p1ContainsP2() { assertTrue(p1.contains(p2)); } // Direktes Kind
    @Test
    void p1ContainsM1() { assertTrue(p1.contains(m1)); } // Direktes Kind
    @Test
    void p1ContainsM2() { assertTrue(p1.contains(m2)); } // Indirektes Kind (in p2) -> Testet Rekursion
    @Test
    void p1ContainsM3() { assertTrue(p1.contains(m3)); } // Indirektes Kind (in p2) -> Testet Rekursion

    // Testet die Logik innerhalb eines Unter-Kompositums
    @Test
    void p2ContainsM2() { assertTrue(p2.contains(m2)); }
    @Test
    void p2ContainsM3() { assertTrue(p2.contains(m3)); }

    // Testet das Blatt (Leaf): Darf nichts enthalten
    @Test
    void m1DoesNotContainM1() { assertFalse(m1.contains(m1)); }

    // Testet die rekursive Preisberechnung
    @Test
    void p1FetchTotalPrice() { assertEquals(98, p1.fetchTotalPrice()); } // Siehe Rechnung in setUp()
    @Test
    void p2FetchTotalPrice() { assertEquals(44, p2.fetchTotalPrice()); }

    // Testet Basis-Preis eines Blattes
    @Test
    void m1FetchTotalPrice() { assertEquals(1, m1.fetchTotalPrice()); }
    @Test
    void m2FetchTotalPrice() { assertEquals(2, m2.fetchTotalPrice()); }

    // Testet das Sammeln aller Materialien (Flattening der Struktur)
    @Test
    void m1FetchMaterialList() { assertEquals(List.of(m1), m1.fetchMaterialList()); }

    @Test
    void p1FetchMaterialList() {
        // Erwartete Liste wird konstruiert, um sie mit dem rekursiven Ergebnis zu vergleichen
        var expected = Stream.of(
                Stream.generate(() -> m3).limit(10), // Teile aus P2 (2x enthalten, aber hier nur Struktur der Komponenten)
                Stream.generate(() -> m2).limit(2),
                Stream.generate(() -> m3).limit(10), // WICHTIG: P2 ist 2x in P1, daher tauchen dessen Teile doppelt auf
                Stream.generate(() -> m2).limit(2),
                Stream.generate(() -> m1).limit(5)
        ).flatMap(component -> component).toList();

        // Sortierung ist notwendig, da die Reihenfolge der Addition nicht garantiert ist bzw. Implementierungsabhängig
        assertEqualsIgnoreOrder(expected, p1.fetchMaterialList());
    }

    @Test
    void p2FetchMaterialList() {
        var expected = Stream.of(
                Stream.generate(() -> m2).limit(2),
                Stream.generate(() -> m3).limit(10)
        ).flatMap(component -> component).toList();
        assertEqualsIgnoreOrder(expected, p2.fetchMaterialList());
    }

    // Hilfsmethode: Vergleicht Listen unabhängig von der Reihenfolge durch vorheriges Sortieren
    private static <T extends Component> void assertEqualsIgnoreOrder(List<T> expected, List<T> actual) {
        assertEquals(sorted(expected), sorted(actual));
    }
    private static <T extends Component> List<T> sorted(List<T> components) {
        return components.stream()
                .sorted(Comparator.comparing(m -> m.name)) // Primär nach Name sortieren
                .sorted(Comparator.comparing(m -> m.price)) // Sekundär nach Preis
                .toList();
    }
}