package org.example;

// Diese Klasse dient als "Client" oder "Treiber", um das Beobachter-Muster (Observer Pattern) zu testen.
class Youtube {

    /** * Die Aufgabe besteht darin, die Interaktion zwischen Usern mittels Callbacks zu steuern.
     * Das Ziel ist eine lose Kopplung: Der Uploader muss nicht wissen, wer genau ihn abonniert hat,
     * er benachrichtigt einfach alle in seiner Liste.
     */
    public static void main(String[] args) {
        // Erstellung der Akteure (User).
        // var (Local Variable Type Inference) wird genutzt, um den Code prägnanter zu halten.
        // Der Compiler leitet den Typ 'User' automatisch ab.
        var grace = new User("Grace");
        var ada = new User("Ada");
        var alan = new User("Alan");
        var linus = new User("Linus");

        // --- Wiring-Phase (Vernetzung der Beobachter) ---

        // Grace möchte Updates von Ada erhalten.
        // In der Terminologie des Observer-Patterns: Grace (Observer) registriert sich bei Ada (Subject).
        grace.subscribe(ada);

        // Alan abonniert Ada. Ada hat nun zwei Abonnenten (Grace, Alan).
        alan.subscribe(ada);

        // Grace abonniert Alan.
        grace.subscribe(alan);

        // Alan abonniert Grace. (Gegenseitiges Abonnement ist möglich).
        alan.subscribe(grace);

        // Linus abonniert Grace. Grace hat nun zwei Abonnenten (Alan, Linus).
        linus.subscribe(grace);

        // --- Trigger-Phase (Ereignisse auslösen) ---

        // Grace lädt ein Video hoch.
        // Erwartung: Ihre Abonnenten (Alan und Linus) werden benachrichtigt.
        grace.upload(new Video("Bugs, Bugs, Bugs"));

        // Alan lädt ein Video hoch.
        // Erwartung: Sein Abonnent (Grace) wird benachrichtigt.
        alan.upload(new Video("Enigma 2025"));

        // Ada lädt ein Video hoch.
        // Erwartung: Ihre Abonnenten (Grace und Alan) werden benachrichtigt.
        ada.upload(new Video("Spinning Code"));

        /* Die Ausgabe bestätigt, dass das Push-Prinzip funktioniert:
           Der Uploader (Subject) "pusht" die Information aktiv an die Abonnenten (Observer).

           Alan has been notified of a new video 'Bugs, Bugs, Bugs' by Grace
            Linus has been notified of a new video 'Bugs, Bugs, Bugs' by Grace
            Grace has been notified of a new video 'Enigma 2025' by Alan
            Alan has been notified of a new video 'Spinning Code' by Ada
            Grace has been notified of a new video 'Spinning Code' by Ada

         */
    }
}