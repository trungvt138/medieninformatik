package org.example;

import java.util.*;

// Die Klasse User fungiert in diesem Muster gleichzeitig als "Subject" (kann beobachtet werden)
// und als "Observer" (kann andere beobachten).
class User {
    private final String name;

    // Speichert die eigenen Videos. 'Collection' als Interface bietet Flexibilität (List, Set möglich).
    private final Collection<Video> videos = new ArrayList<>();

    // Speichert die Abonnenten dieses Users.
    // WARUM Set? Ein Set verhindert Duplikate. Wenn ein User versehentlich zweimal "subscribe" drückt,
    // soll er die Benachrichtigung trotzdem nur einmal erhalten.
    private final Set<User> subscribers = new HashSet<>();

    User(String name) {
        this.name = name;
    }

    /**
     * Diese Methode löst das Ereignis aus (Event Trigger).
     * Sie entspricht der Zustandsänderung im Subject.
     */
    void upload(Video video) {
        // 1. Zustand ändern: Das Video wird der Sammlung hinzugefügt.
        videos.add(video);

        // 2. Benachrichtigung (Notify):
        // Wir iterieren über alle registrierten Abonnenten (Observer).
        // 'user' ist hier der jeweilige Abonnent.
        // Wir rufen aktiv eine Methode auf dem Abonnenten-Objekt auf (Callback).
        // 'this' wird übergeben, damit der Abonnent weiß, WER das Video hochgeladen hat.
        subscribers.forEach(user -> user.notifySubscriberOfNewVideo(this, video));
    }

    /**
     * Dies ist die Callback-Methode (die Reaktion des Observers).
     * Sie wird nicht vom User selbst aufgerufen, sondern von demjenigen, den man abonniert hat (siehe upload).
     * * @param uploader Der User, der das Video hochgeladen hat (Subject).
     * @param video Das neue Video-Objekt (Payload).
     */
    private void notifySubscriberOfNewVideo(User uploader, Video video) {
        // Formatierte Ausgabe gemäß Anforderung.
        // 'name' ist der Name von 'this' (dem Empfänger der Nachricht).
        // 'uploader' ist der Sender.
        System.out.printf("%s has been notified of a new video '%s' by %s%n", name, video, uploader);
    }

    /**
     * Registriert eine Abhängigkeit (Subscription).
     * * ACHTUNG BEI DER LOGIK:
     * Wenn ich (this) sage: "Ich möchte 'otherUser' abonnieren", dann muss ich mich
     * in die Liste der Abonnenten von 'otherUser' eintragen.
     * * Im Code hier ist der Parametername 'subscriber' etwas irreführend gewählt.
     * Im Kontext von main `grace.subscribe(ada)` ist `grace` = `this` und `ada` = Parameter.
     * Grace möchte Ada abonnieren.
     */
    void subscribe(User otherUser) {
        // Wir greifen auf das Set 'subscribers' des ANDEREN Users zu und fügen UNS SELBST (this) hinzu.
        // Da 'subscribers' private ist, dürfen wir hier nur zugreifen, weil wir uns in derselben Klasse befinden.
        otherUser.subscribers.add(this);
    }

    // Getter für die Videos (nicht zwingend für die Logik nötig, aber guter Stil).
    // Gibt eine unveränderliche Sicht zurück (Defensive Copying / Unmodifiable View),
    // damit von außen niemand Videos aus der Liste löschen kann.
    Collection<Video> allUploadedVideos() {
        return Collections.unmodifiableCollection(videos);
    }

    // toString ist wichtig, damit bei System.out.printf("%s", user) nicht der HashCode,
    // sondern der lesbare Name ausgegeben wird.
    @Override public String toString() {
        return name;
    }
}