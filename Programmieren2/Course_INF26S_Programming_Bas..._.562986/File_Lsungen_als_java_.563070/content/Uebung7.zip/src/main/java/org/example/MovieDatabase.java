package org.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.function.Predicate;

// Die Klasse MovieDatabase fungiert als Container für Filme und stellt Methoden zur Verfügung,
// um diese Filme mittels "Higher-Order Functions" zu verarbeiten.
// Das bedeutet: Die Methoden akzeptieren keine Datenwerte (wie Strings), sondern Verhalten (Funktionen).
class MovieDatabase {

    // Verwendung von 'Collection' als Interface-Typ für maximale Flexibilität (List, Set, etc.).
    // 'final' stellt sicher, dass die Referenz auf die Liste nach der Initialisierung nicht mehr geändert wird.
    private final Collection<Movie> movies;

    MovieDatabase(Collection<Movie> movies) {
        this.movies = movies;
    }

    /**
     * Diese Methode ist eine Higher-Order Function, da sie eine Funktion (Consumer) als Parameter erwartet.
     * Ein Consumer<T> akzeptiert ein Element vom Typ T, führt eine Aktion aus und gibt nichts zurück (void).
     */
    void forEach(Consumer<Movie> action) {
        // Explizite Anforderung: Keine Streams verwenden. Wir iterieren "klassisch".
        for (Movie movie : movies) {
            // Hier passiert die Magie der HOF:
            // Wir wissen nicht, WAS mit dem Film passiert (Drucken? Speichern? Ändern?).
            // Wir wissen nur, DASS es ausgeführt werden soll. Das Verhalten kommt von außen ("action").
            // 'accept' ist die einzige abstrakte Methode im Consumer-Interface.
            action.accept(movie);
        }

        // Alternativ hätte man Streams nutzen können, was intern ähnlich funktioniert:
        // return movies.stream().forEach(action);
    }

    /**
     * Diese Methode ist ebenfalls eine Higher-Order Function. Sie nutzt ein Predicate<T>.
     * Ein Predicate ist eine Funktion, die ein Element prüft und wahr (true) oder falsch (false) zurückgibt.
     * Dies ermöglicht eine flexible Suche, ohne für jedes Kriterium (Titel, Genre, Jahr) eine eigene Methode schreiben zu müssen.
     */
    Collection<Movie> findByCategory(Predicate<Movie> criteria) {
        // Ergebnisliste initialisieren, um Treffer zu sammeln.
        Collection<Movie> result = new ArrayList<>();

        // Iteration durch alle gespeicherten Filme.
        for (Movie movie : movies) {
            // Das 'criteria'-Objekt repräsentiert die Suchlogik (das Lambda aus dem Test).
            // Die Methode 'test(movie)' führt diese Logik auf dem aktuellen Film aus.
            // Wenn 'test' true liefert, erfüllt der Film die Bedingung.
            if (criteria.test(movie)) {
                result.add(movie);
            }
        }
        return result;

        // Die Stream-Alternative wäre deklarativer, ist aber laut Aufgabe untersagt:
        // return movies.stream().filter(criteria).toList();
    }
}