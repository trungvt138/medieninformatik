package org.example;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;

// Repräsentiert ein unveränderliches Datenobjekt (Value Object) für einen Film.
// Änderungen sind nach der Erstellung nicht möglich (alle Felder final), was Seiteneffekte in HOFs verhindert.
class Movie {
    private final String name;
    // Speichert Kategorien in einem Set, um Duplikate zu vermeiden und schnelle 'contains'-Prüfungen zu ermöglichen.
    private final Set<Category> categories;

    // Konstruktor mit Varargs (Category... categories):
    // Erlaubt den Aufruf wie new Movie("Name", Cat.ACTION, Cat.DRAMA) ohne manuelles Erstellen einer Liste.
    Movie(String name, Category... categories) {
        this.name = name;
        // EnumSet.copyOf ist eine performante Spezialimplementierung für Enums.
        // Arrays.asList wandelt das Varargs-Array in eine Liste um, die copyOf versteht.
        this.categories = EnumSet.copyOf(Arrays.asList(categories));
    }

    String name() {
        return name;
    }

    // Essentielle Hilfsmethode für die Lambdas.
    // Ermöglicht lesbaren Code wie: movie -> movie.hasCategory(Category.ACTION)
    boolean hasCategory(Category category) {
        return categories.contains(category);
    }

    // equals und hashCode sind zwingend erforderlich für Unit Tests (assertThat...containsExactlyElementsIn).
    // Ohne diese Methoden würde Java die Speicheradressen vergleichen statt des Inhalts (Name + Kategorien).
    @Override
    public final boolean equals(Object object) {
        if (this == object) return true; // Performance: Ist es dasselbe Objekt im Speicher?
        // Pattern Matching for instanceof (Java 14+ Feature, hier klassisch lesbar): Prüft Typ.
        if (!(object instanceof Movie movie)) return false;
        // Zwei Filme sind gleich, wenn Name UND Kategorien identisch sind.
        return Objects.equals(name, movie.name) &&
                Objects.equals(categories, movie.categories);
    }

    @Override
    public int hashCode() {
        // Generiert einen eindeutigen Hashwert basierend auf den Feldern.
        // Wichtig, wenn Movie in HashMaps oder HashSets (wie hier im Test indirekt) genutzt wird.
        int result = Objects.hashCode(name);
        result = 31 * result + Objects.hashCode(categories);
        return result;
    }

    @Override
    public String toString() {
        // Schönere Textausgabe für Debugging und Fehlermeldungen im Test.
        return "%s %s".formatted(name, categories);
    }
}