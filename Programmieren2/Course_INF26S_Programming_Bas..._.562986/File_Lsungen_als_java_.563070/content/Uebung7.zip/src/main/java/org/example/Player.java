package org.example;

// Eine einfache Datenklasse, die den Zustand eines Spielers repräsentiert.
class Player {
    // 'final' für den Namen, da sich die Identität des Spielers nach der Erstellung nicht mehr ändern soll (Immutability).
    private final String name;

    // Der Punktestand ist veränderlich (mutable), da er sich im Spielverlauf ändert.
    private int score;

    Player(String name) {
        this.name = name;
    }

    String name() {
        return name;
    }

    // Getter für den Score, um den Zustand von außen (z.B. im Test) prüfen zu können.
    int score() {
        return score;
    }

    // Methode zur Zustandsänderung. Kapselt die Logik "Score erhöhen" innerhalb der Klasse,
    // anstatt das Feld 'score' public zu machen (Data Hiding).
    void incrementScore() {
        score++;
    }

    // Wichtig für das Debugging und aussagekräftige Fehlermeldungen in Unit Tests,
    // damit man sieht, WELCHER Spieler gemeint ist.
    @Override public String toString() {
        return "Player{name='" + name + '\'' + ", score=" + score + '}';
    }
}