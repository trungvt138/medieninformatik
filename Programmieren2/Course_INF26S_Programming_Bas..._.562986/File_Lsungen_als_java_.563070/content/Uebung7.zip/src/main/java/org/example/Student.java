package org.example;

import java.util.Collection;
import java.util.LinkedList;
import java.util.function.Consumer;

// Diese Klasse repräsentiert nicht nur Daten (Model), sondern fungiert auch als "Subject" im Observer-Pattern.
// Das bedeutet, andere Objekte können sich anmelden, um über Änderungen informiert zu werden.
class Student {
    private int id;
    private String name;

    // Speichert die Liste der "Beobachter" (Observer).
    // Statt ein eigenes Interface zu definieren, nutzen wir hier `Consumer<Student>`.
    // Warum Consumer? Ein Consumer akzeptiert ein Argument (den Student) und gibt nichts zurück (void).
    // Das passt perfekt für Event-Handler, die einfach nur auf ein Update reagieren sollen.
    // Wir nutzen `LinkedList`, da hier vermutlich häufig iteriert wird und die Reihenfolge der Anmeldung beibehalten werden soll.
    // (Hinweis: In echten Multi-Thread-Umgebungen müsste man hier auf Thread-Safety achten, z.B. CopyOnWriteArrayList).
    private final Collection<Consumer<Student>> onModifiedSubscribers = new LinkedList<>();

    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Methode zum Registrieren eines Beobachters (Subscribe).
    // Externe Klassen übergeben hier ein Lambda oder eine Methodenreferenz, die ausgeführt werden soll,
    // wenn sich der Student ändert.
    void subscribeOnModified(Consumer<Student> subscriber) {
        // Fügt den Callback zur Liste hinzu.
        this.onModifiedSubscribers.add(subscriber);
    }

    // Diese Methode löst das Event aus (Notify).
    // Sie ist `private`, da nur die Klasse selbst wissen sollte, wann sich ihr interner Zustand so stark geändert hat,
    // dass eine Benachrichtigung notwendig ist.
    private void publishOnModified() {
        // Iteriert über alle registrierten Callbacks.
        // `subscriber.accept(this)` ruft die Logik des Beobachters auf und übergibt `this` (die aktuelle Instanz).
        // Dadurch hat der Beobachter sofort Zugriff auf die neuesten Daten (Push-Prinzip mit Payload).
        onModifiedSubscribers.forEach(subscriber -> subscriber.accept(this));
    }

    int id() {
        return id;
    }

    String name() {
        return name;
    }

    // Setter mit Seiteneffekt (Side Effect).
    void setId(int id) {
        this.id = id;
        // Nachdem der Wert geändert wurde, informieren wir sofort alle Abonnenten.
        // Warum danach? Damit die Abonnenten beim Zugriff auf `.id()` bereits den neuen Wert erhalten.
        publishOnModified();
    }

    // Setter mit Seiteneffekt.
    void setName(String name) {
        this.name = name;
        // Auch hier: Zustandsänderung löst Benachrichtigung aus.
        // Das ist essentiell für Reactive Programming oder UI-Updates (View aktualisiert sich automatisch bei Model-Änderung).
        publishOnModified();
    }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name='" + name + '\'' + '}';
    }
}