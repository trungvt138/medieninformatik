package org.example;

// Ein 'record' (seit Java 14/16) ist ideal für reine Datencontainer (Data Carrier).
// WARUM Record?
// 1. Es ist unveränderlich (immutable) - ein Video-Titel ändert sich nicht nachträglich.
// 2. Es spart Boilerplate-Code: Konstruktor, Getter, equals(), hashCode() und toString()
//    werden automatisch generiert.
record Video(String title) {

    // Wir überschreiben toString manuell.
    // Der Standard-Record-toString würde etwas ausgeben wie "Video[title=Bugs...]".
    // Laut gewünschter Konsolenausgabe benötigen wir aber nur den reinen Titel "Bugs...".
    @Override public String toString() {
        return title;
    }
}