package org.example;

// Einfaches Enum zur Definition der unterstützten Sprachen.
// Dient als Typsicherheit für die titleTranslator-Funktion.
enum Language {
    GERMAN,
    KLINGON,
    ENGLISH
}