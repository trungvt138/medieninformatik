package org.example;

@FunctionalInterface // Kennzeichnet das Interface explizit für die Verwendung mit Lambda-Ausdrücken.
interface Combiner<T, R> { // T für die beiden Eingabeparameter, R für den Rückgabewert (wie in den Tests gefordert).
    // Die Methode muss zwei Parameter gleichen Typs akzeptieren und ein Ergebnis (potenziell anderen Typs) liefern.

    /**
     * Die abstrakte Methode definiert die "Signatur" der Funktion.
     * * Im Kontext von HOFs bedeutet diese Signatur:
     * "Ich akzeptiere eine Verhaltensweise, die zwei Dinge vom Typ T nimmt
     * und daraus ein Ding vom Typ R macht."
     * * - T (Type): Der Typ der beiden Eingabeparameter (z. B. String oder Integer).
     * - R (Return): Der Typ des Ergebnisses (z. B. String oder Double).
     * * Durch diese Generics wird die Funktion abstrakt und wiederverwendbar für
     * verschiedenste Datentypen, was typisch für HOF-Konzepte ist (Trennung von Algorithmus und Datentyp).
     */

    R combine(T element1, T element2);
}