package org.example;

import java.util.function.Function;
import java.util.function.Supplier;

// Die Klasse dient zum Zusammenbauen eines HTML-Strings.
// Sie nutzt das "Method Chaining" (Builder Pattern) und Higher-Order Functions für maximale Flexibilität.
class HtmlGenerator {

    // Konstanten für Formatierung, um Konsistenz sicherzustellen und "Magic Strings" im Code zu vermeiden.
    private static final String LINE_BREAK = "\n";
    private static final String INDENT = " "; // Ein Leerzeichen als Einrückung laut Anforderung.

    // HOF-Feld: titleTranslator
    // Statt einen festen String zu speichern, speichern wir eine Funktion (Logik).
    // Diese Funktion weiß, wie man aus einer 'Language' einen 'String' (Titel) macht.
    // Der Default-Wert `_ -> ""` ist ein Lambda, das den Input ignoriert (Unterstrich ab Java 21 üblich für ungenutzte Parameter)
    // und einen leeren String liefert. Das verhindert NullPointerExceptions, wenn setTitle nicht aufgerufen wird.
    private Function<Language, String> titleTranslator = _ -> "";

    // HOF-Feld: body
    // Ein Supplier<T> liefert ein Ergebnis vom Typ T, nimmt aber keine Parameter entgegen.
    // Er wird oft für "Lazy Evaluation" genutzt (der String wird erst erzeugt, wenn .get() aufgerufen wird).
    private Supplier<String> body = () -> "";

    // Der aktuelle Zustand (Konfiguration) des Generators.
    private Language language = Language.ENGLISH;

    // Builder-Pattern Methode (Fluent Interface):
    // Gibt `HtmlGenerator` (this) zurück, damit Methoden verkettet werden können (.setLanguage(...).setTitle(...)).
    HtmlGenerator setLanguage(Language language) {
        this.language = language;
        return this;
    }

    // Higher-Order Function (Setter):
    // Akzeptiert eine Funktion als Parameter. Damit wird die Logik, wie der Titel übersetzt wird,
    // von außen injiziert (Dependency Injection light). Der Generator muss die Übersetzungslogik nicht selbst kennen.
    HtmlGenerator setTitle(Function<Language, String> titleTranslator) {
        this.titleTranslator = titleTranslator;
        return this;
    }

    // Higher-Order Function (Setter):
    // Hinweis aus der Aufgabe: Für reinen Text wäre String ausreichend.
    // Die Nutzung von Supplier dient hier Übungszwecken für funktionale Schnittstellen.
    // Vorteil in der Praxis: Wenn die Erzeugung des Body-Strings sehr rechenintensiv wäre,
    // würde sie hier noch nicht ausgeführt werden, sondern erst beim Aufruf von .generate() (Lazy Loading).
    HtmlGenerator setBody(Supplier<String> supplier) {
        body = supplier;
        return this;
    }

    // Hauptmethode: Baut das finale Produkt zusammen.
    String generate() {
        // Ruft die Teil-Methoden auf und konkateniert die Strings.
        return startHtml() + generateHead() + generateBody() + closeHtml();
    }

    private String startHtml() {
        // Verwendung von Text Blocks (""" ... """) für mehrzeilige Strings.
        // Das ist lesbarer als "Line 1\n" + "Line 2\n".
        return """
                <!DOCTYPE html>
                <html>
                """;
    }

    private String closeHtml() {
        return "</html>";
    }

    private String generateHead() {
        // Hier wird die gespeicherte Higher-Order Function ausgeführt!
        // titleTranslator.apply(language): Wir übergeben den aktuellen Zustand (Sprache) an die Funktion,
        // die wir vorher per setTitle injiziert bekommen haben.
        // .formatted() fügt das Ergebnis in den Platzhalter %s ein.
        return """
                <head>
                <title>%s</title>
                </head>
                """.formatted(titleTranslator.apply(language));
    }

    private String generateBody() {
        // StringBuilder ist effizienter als String-Konkatenation in Schleifen (vermeidet Erzeugen vieler temporärer Objekte).
        StringBuilder result = new StringBuilder();
        result.append("<body>").append(LINE_BREAK);

        // body.get() ruft den Supplier auf und holt den eigentlichen Inhalt.
        // .split(LINE_BREAK) zerlegt den mehrzeiligen String, um jede Zeile einzeln bearbeiten zu können.
        String[] lines = body.get().split(LINE_BREAK);

        // Iteration über die Zeilen, um die geforderte Einrückung (INDENT) hinzuzufügen.
        for (String line : lines) {
            result.append(INDENT).append(line).append(LINE_BREAK);
        }

        result.append("</body>").append(LINE_BREAK);
        return result.toString();
    }
}