package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

// Generische Klasse MyList<T>: Das <T> ist ein Platzhalter für einen Datentyp.
// Das ermöglicht es uns, MyList für Strings, Integers, Movies oder beliebige andere Objekte zu nutzen,
// ohne für jeden Typ eine neue Klasse schreiben zu müssen.
class MyList<T> {

    // 'final' bedeutet hier, dass die Referenz auf die Liste nicht mehr geändert werden kann,
    // sobald das Objekt erstellt wurde. Das erhöht die Sicherheit und Vorhersehbarkeit des Codes.
    private final List<T> elements;

    // Hauptkonstruktor: Nimmt eine beliebige Collection (Liste, Set, etc.) entgegen.
    MyList(Collection<T> elements) {
        // Defensive Copy: Wir speichern nicht direkt die übergebene Liste, sondern erstellen eine Kopie.
        // Warum? Wenn der Aufrufer seine Liste später ändert, soll unsere MyList davon unberührt bleiben.
        // Zudem erlaubt uns 'new ArrayList', eine modifizierbare Liste zu haben, selbst wenn 'elements' unveränderlich war.
        this.elements = new ArrayList<>(elements);
    }

    // Bonusaufgabe: Varargs-Konstruktor
    // Erlaubt den Aufruf via new MyList<>("A", "B", "C") statt new MyList<>(List.of("A", "B", "C")).
    // @SafeVarargs unterdrückt Warnungen, die bei der Mischung von Generics und Arrays (Varargs sind Arrays) entstehen,
    // da wir hier sicherstellen, dass nichts Unsicheres mit dem Array passiert.
    @SafeVarargs
    MyList(T... elements) {
        // Konstruktor-Verkettung (Constructor Chaining):
        // Wir wandeln das Array in eine Liste um und rufen den Hauptkonstruktor auf (this(...)).
        // Warum? Um Code-Duplizierung zu vermeiden (#DRY - Don't Repeat Yourself).
        this(Arrays.asList(elements));
    }

    // Standard-Methode: Prüft auf Objekt-Gleichheit.
    boolean contains(T element) {
        // Delegiert an die Standard-Implementierung von ArrayList.
        // Nutzt intern die equals()-Methode des Objekts T.
        return elements.contains(element);
    }

    // Higher-Order Function: Prüft mittels einer Funktion (Predicate).
    // Ein Predicate<T> ist ein funktionales Interface, das einen Test definiert (Input T -> Output boolean).
    // Dies ermöglicht eine flexible Suche (z.B. Case-Insensitive, komplexe Bedingungen), ohne die Klasse ändern zu müssen.
    boolean contains(Predicate<T> criteria) {
        // Manuelle Iteration über die Liste.
        // Warum keine Streams? Laut Aufgabenstellung sollte hier die klassische Iteration geübt werden.
        for (T element : elements) {
            // Führt das Verhalten aus, das der Aufrufer als Lambda übergeben hat.
            // Wenn criteria.test(element) 'true' liefert, haben wir einen Treffer.
            if (criteria.test(element)) {
                return true; // Early Return: Sobald ein Element passt, brechen wir ab (Performance-Optimierung).
            }
        }
        // Wenn die Schleife durchläuft, ohne dass das Predicate jemals 'true' war, ist das Element nicht enthalten.
        return false;

        // Alternative mit Streams (deklarativer Stil):
        // return elements.stream().anyMatch(criteria);
    }
}