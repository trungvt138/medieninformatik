package org.example;

import java.util.*;

// Die Kernklasse, die die Spiellogik steuert. Sie fungiert im Observer-Pattern als "Subject" (das beobachtbare Objekt).
class GameEngine {
    private static final int PLAYERS_TO_CREATE = 10;

    // Ein gemeinsames Random-Objekt für die gesamte Klasse.
    // 'static', damit es nicht bei jeder Instanziierung neu erzeugt wird (Effizienz)
    // und um bessere Zufallsverteilung bei schnellen Instanziierungen zu gewährleisten.
    private static final Random RANDOM = new Random();

    // Speichert die aktiven Spieler.
    private final List<Player> players = new ArrayList<>();

    // Liste der Abonnenten (Observer). Hier werden alle registrierten Callbacks gespeichert.
    // Verwendung von 'Collection' als generischer Typ für Flexibilität (List, Set, etc.).
    private final Collection<PlayerEliminated> playerEliminatedSubscribers = new ArrayList<>();

    GameEngine() {
        createPlayers();
    }

    // Private Hilfsmethode zur Initialisierung. Kapselt die Erstellungslogik.
    private void createPlayers() {
        for (int i = 0; i < PLAYERS_TO_CREATE; i++) {
            String defaultName = "Player" + i;
            players.add(new Player(defaultName));
        }
    }

    // Ermöglicht externen Klassen (wie dem Unit Test), sich für Ereignisse zu registrieren.
    // Das ist der "Subscribe"-Teil des Observer-Patterns.
    void subscribePlayerEliminated(PlayerEliminated subscriber) {
        playerEliminatedSubscribers.add(subscriber);
    }

    // Löst das Ereignis aus und benachrichtigt alle Abonnenten.
    // Dies entkoppelt die Logik "Was passiert im Spiel" von "Was soll danach passieren (Logging, UI-Update, Test-Assert)".
    void notifyPlayerEliminated(Player eliminator, Player eliminatee) {
        playerEliminatedSubscribers.forEach(subscriber -> subscriber.playerEliminated(eliminator, eliminatee));
    }

    // Die eigentliche Spielrunde ("Game Loop" Schritt).
    void run() {
        // Zufällige Auswahl der Akteure.
        Player eliminator = getRandomPlayer();
        Player eliminatee = getRandomPlayer();

        // Spielregel: Man bekommt nur Punkte, wenn man jemand anderen eliminiert.
        // Selbsteliminierung gibt keine Punkte.
        if (eliminator != eliminatee) {
            eliminator.incrementScore();
        }

        // Unabhängig von den Punkten wird das Ereignis "Schuss abgefeuert" gemeldet.
        notifyPlayerEliminated(eliminator, eliminatee);
        // eliminator has just shot eliminatee
    }

    // Hilfsmethode, um Code-Duplizierung bei der Auswahl von zwei Spielern zu vermeiden (#DRY).
    private Player getRandomPlayer() {
        return players.get(randomPlayerIndex());
    }

    // Kapselt den Zugriff auf das Random-Objekt und die Listengrenzen.
    private int randomPlayerIndex() {
        return RANDOM.nextInt(0, players.size());
    }
}