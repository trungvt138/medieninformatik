package org.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

// Die Klasse ist `final`, da es sich um eine Utility-Klasse handelt.
// Eine Vererbung ist hier weder sinnvoll noch erwünscht.
final class HigherOrderUtil {

    // Methode 1: Transformation (Mapping)
    // Parameter `Collection<Integer>`: Wir akzeptieren hier bewusst das allgemeinere Interface (Liskov Substitution Principle),
    // damit die Methode mit Listen, Sets oder Queues funktioniert.
    // Parameter `UnaryOperator<Integer>`: Ein spezielles Functional Interface, bei dem Eingabe- und Ausgabetyp gleich sind (Integer -> Integer).
    // Wäre der Rückgabetyp anders (z.B. Integer -> String), müsste man `Function<Integer, String>` nutzen.
    static List<Integer> applyToEach(Collection<Integer> numbers, UnaryOperator<Integer> function) {
        // Wir erstellen eine neue Ergebnisliste, um Seiteneffekte auf der ursprünglichen Liste zu vermeiden (Immutability-Gedanke).
        List<Integer> result = new ArrayList<>();

        // Manuelle Iteration (anstatt Streams), um die Funktionsweise "unter der Haube" zu verstehen.
        for (Integer number : numbers) {
            // Hier wird das übergebene "Verhalten" ausgeführt.
            // Die Methode weiß nicht, was `function` tut (verdoppeln? quadrieren? +1?),
            // sie führt es einfach nur mittels `.apply()` aus. Das ist Polymorphismus durch Interfaces.
            Integer i = function.apply(number);
            result.add(i);
        }
        return result;

        // Alternative mit Streams (deklarativer Stil):
        // return numbers.stream()
        // .map(function) // 'map' entspricht genau unserer applyToEach-Logik
        // .toList();
    }

    // Methode 2: Bedingte Transformation (Filter + Map)
    // Parameter `Predicate<Integer>`: Ein Functional Interface, das einen Wert nimmt und `boolean` zurückgibt.
    // Es dient standardmäßig zum Testen von Bedingungen.
    static List<Integer> applyToEachIf(Collection<Integer> numbers, UnaryOperator<Integer> function, Predicate<Integer> condition) {
        List<Integer> result = new ArrayList<>();

        for (Integer number : numbers) {
            // Zuerst prüfen wir die Bedingung (`condition.test`).
            // Nur wenn das Predicate `true` zurückgibt, wird fortgefahren.
            if (condition.test(number)) {
                // Erst jetzt wenden wir die teure Business-Logik (`function.apply`) an.
                // Das ist effizienter, als erst alles zu berechnen und dann zu filtern.
                Integer i = function.apply(number);
                result.add(i);
            }
        }
        return result;

        // Alternative mit Streams:
        // return numbers.stream()
        // .filter(condition) // Erst Filtern (Reduzierung der Menge)
        // .map(function)     // Dann Verarbeiten
        // .toList();
    }
}