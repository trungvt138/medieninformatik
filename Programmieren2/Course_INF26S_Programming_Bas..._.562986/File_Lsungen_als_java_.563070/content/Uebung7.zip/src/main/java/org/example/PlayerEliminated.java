package org.example;

// Dieses Interface definiert den Vertrag für das Observer-Pattern (Beobachter-Muster).
// Es ermöglicht, dass externe Klassen auf Ereignisse in der GameEngine reagieren können, ohne dass
// die GameEngine diese Klassen kennen muss (lose Kopplung).
@FunctionalInterface // Markiert das Interface explizit für die Nutzung mit Lambda-Ausdrücken.
interface PlayerEliminated {
    // Die Callback-Methode. Sie wird aufgerufen, wenn ein Spieler eliminiert wurde.
    // Parameter übergeben den Kontext (Wer hat wen eliminiert?), damit der Beobachter reagieren kann.
    void playerEliminated(Player eliminator, Player eliminatee);
}