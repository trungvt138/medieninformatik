package org.example;

// Einfaches Enum zur Definition der Genre-Konstanten.
enum Category {
    HORROR, ROMANCE, ACTION, SCIFI, FANTASY, COMEDY, THRILLER, DRAMA
}