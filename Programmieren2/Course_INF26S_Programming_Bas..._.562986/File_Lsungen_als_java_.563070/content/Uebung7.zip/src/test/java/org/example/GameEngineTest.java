package org.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

class GameEngineTest {

    private GameEngine gameEngine;

    // @BeforeEach garantiert eine frische Instanz der GameEngine vor jedem einzelnen Test.
    // Das stellt sicher, dass Seiteneffekte (z.B. Score-Änderungen) aus einem Test
    // nicht die Ergebnisse eines anderen Tests verfälschen (Isolation).
    @BeforeEach void setUp() {
        gameEngine = new GameEngine();
    }

    /**
     * Testet, ob das Observer-Pattern funktioniert: Wird der Callback wirklich aufgerufen?
     */
    @Test void publishSubscribePlayerEliminated() { // this test case is a bit hacky (difficult to test).
        // Arrange
        // Ein boolean-Array als "Container" für den Status.
        // WARUM ein Array? Variablen, die in einem Lambda verwendet werden, müssen "effectively final" sein.
        // Wir können 'boolean wasCalled = false' im Lambda nicht auf 'true' setzen.
        // Aber wir können den INHALT eines finalen Arrays (Referenztyp) ändern. Dies ist ein gängiger Trick ("Hack") in Java-Tests.
        boolean[] wasCalled = new boolean[1];

        // Act
        // Wir registrieren einen Observer, der einfach nur das Flag im Array auf 'true' setzt.
        // Die Parameter (_, _) sind Java 21+ Syntax für unbenutzte Variablen (Unnamed Variables).
        // Falls älteres Java genutzt wird, müsste hier (p1, p2) stehen.
        gameEngine.subscribePlayerEliminated((_, _) -> {
            wasCalled[0] = true; // Side-Effect erzeugen, um den Aufruf nachweisbar zu machen.
        });

        // Wir lassen die Engine laufen, was intern 'notifyPlayerEliminated' auslösen sollte.
        gameEngine.run();

        // Assert
        // Wenn das Array-Feld true ist, wurde der Lambda-Code ausgeführt -> Success.
        assertTrue(wasCalled[0]);
    }

    /**
     * Testet die Spiellogik (Punktevergabe).
     * @RepeatedTest(10): Da die Engine Zufallswerte (Random) verwendet, könnte ein einzelner Durchlauf
     * zufällig "funktionieren" oder einen seltenen Fall (eliminator == eliminatee) verpassen.
     * Durch die Wiederholung erhöhen wir die Wahrscheinlichkeit, beide Pfade (Treffer und Selbsttreffer) zu testen.
     */
    @RepeatedTest(10) void scored() { // due to randomness, repeat this test case ten times
        // Assert & Act (gemischt)

        // Wir nutzen den Observer, um die Assertions VORZUNEHMEN.
        // Warum? Weil wir hier Zugriff auf die genau in diesem Durchlauf zufällig gewählten
        // 'eliminator' und 'eliminatee' Objekte haben.
        // Würden wir erst nach gameEngine.run() prüfen, wüssten wir nicht, welche der 10 Spieler wir prüfen müssen.
        gameEngine.subscribePlayerEliminated((eliminator, eliminatee) -> {

            if (eliminator != eliminatee) { // Fall A: Normaler Treffer
                // Der Schütze muss jetzt genau 1 Punkt haben (da frische Engine pro Test).
                assertEquals(1, eliminator.score());
                // Das Opfer darf keine Punkte bekommen haben.
                assertEquals(0, eliminatee.score());
            } else {
                // Fall B: Selbsttreffer (Zufall wählte gleichen Index)
                // Niemand bekommt Punkte.
                assertEquals(0, eliminator.score());
            }
        });

        // Act: Startet die Logik, die den oben definierten Callback auslöst.
        gameEngine.run();
    }
}