package org.example;

import org.junit.jupiter.api.Test;
import java.util.List;
import static com.google.common.truth.Truth.assertThat;

// Dieser Test spezifiziert das Verhalten unserer Utility-Klasse.
// Er demonstriert, wie man "Verhalten" (Code) in Form von Lambda-Ausdrücken an Methoden übergibt.
class HigherOrderUtilTest {

    @Test
    void applyToEach() {
        // Vorbereitung: Erstellung einer unveränderlichen Liste als Datenquelle.
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        // Aufruf der Higher-Order Function.
        // Der zweite Parameter `x -> x * 2` ist das Herzstück:
        // Wir übergeben keine Daten, sondern die Logik "Verdoppeln".
        // Der Test muss nicht wissen, WIE iteriert wird, nur WAS mit den Zahlen geschehen soll.
        List<Integer> doubled = HigherOrderUtil.applyToEach(numbers, x -> x * 2);

        // Überprüfung des Ergebnisses mittels Google Truth (Fluent Assertion).
        // Erwartet wird: [2, 4, 6, 8, 10].
        assertThat(doubled).isEqualTo(List.of(2, 4, 6, 8, 10));
    }

    @Test
    void applyToEachIf() {
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        // Dieser Testfall kombiniert Filtern und Abbilden (Map).
        // Parameter 2 (`x -> x / 2`): Die Transformation (Mapping). Was soll passieren?
        // Parameter 3 (`x -> x % 2 == 0`): Die Bedingung (Filter). Wann soll es passieren?
        // Diese Trennung von Iterationslogik, Geschäftslogik (Halbieren) und Bedingung (Gerade)
        // macht den Code extrem flexibel und wiederverwendbar.
        List<Integer> halfedIfEven = HigherOrderUtil.applyToEachIf(
                numbers,
                x -> x / 2,      // UnaryOperator: Berechnet neuen Wert
                x -> x % 2 == 0  // Predicate: Entscheidet über Aufnahme
        );

        // Ablauf:
        // 1 (ungerade) -> ignoriert
        // 2 (gerade) -> 2/2 = 1 -> gespeichert
        // 3 (ungerade) -> ignoriert
        // 4 (gerade) -> 4/2 = 2 -> gespeichert
        // 5 (ungerade) -> ignoriert
        assertThat(halfedIfEven).isEqualTo(List.of(1, 2));
    }
}