package org.example;

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat;

class HtmlGeneratorTest {

    @Test
    void generate() {
        // Hier sehen wir das Builder-Pattern in Aktion.
        // Ein Objekt wird instanziiert und in einer Kette konfiguriert.
        String htmlDocument = new HtmlGenerator() // Method Chaining Start
                .setLanguage(Language.GERMAN) // Setzt den Zustand auf DEUTSCH.

                // HOF-Einsatz: Wir übergeben ein Lambda (Verhalten).
                // "Wenn du eine Sprache bekommst, ruf die Methode titleTranslator auf".
                .setTitle(language -> titleTranslator(language))

                // HOF-Einsatz: Wir übergeben einen Supplier (Lieferanten).
                // "Wenn du den Body brauchst, nimm diesen Text Block".
                .setBody(() -> """
                                <h1>Hello World!</h1>
                                <a href\"impressum\">Impressum</a>""")

                .generate(); // Finaler Aufruf, der alles zusammensetzt.

        // Validierung des Ergebnisses.
        // Wichtig: Text Blocks in Java entfernen automatisch die gemeinsame Einrückung (Incidental Whitespace).
        // Die Formatierung im Erwartungswert muss exakt mit der Logik in generateBody() übereinstimmen.
        assertThat(htmlDocument).isEqualTo("""
                                                    <!DOCTYPE html>
                                                    <html>
                                                    <head>
                                                    <title>Beste Seite der Welt</title>
                                                    </head>
                                                    <body>
                                                     <h1>Hello World!</h1>
                                                     <a href\"impressum\">Impressum</a>
                                                    </body>
                                                    </html>""");
    }

    // Hilfsmethode für den Test, die die Übersetzungslogik kapselt.
    // Dies simuliert eine externe Logik, die dem HtmlGenerator übergeben wird.
    private static String titleTranslator(Language language) {
        // Switch Expression (seit Java 14): Kompakte Schreibweise, gibt direkt einen Wert zurück.
        return switch (language) {
            case GERMAN -> "Beste Seite der Welt";
            case KLINGON -> "taghDI' qo' vIDa ";
            default -> "Best Page of the World";
        };
    }
}