package org.example;

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat;

// Laut Aufgabenstellung (Seite 2) ist dieser Unit Test gegeben und darf nicht verändert werden.
// Er diktiert die Signatur und die Generics des zu implementierenden Interfaces.
class CombinerTest {
    private static final double TOLERANCE = 0.000000000001;

    @Test
    void stringsWithSpaceCombiner() {
        // Anforderung 1: Das Interface muss zwei Strings akzeptieren und einen String zurückgeben.
        Combiner<String, String> withSpaceCombiner = (string1, string2) -> "%s %s".formatted(string1, string2);

        String actual = withSpaceCombiner.combine("Ada", "Lovelace");
        assertThat(actual).isEqualTo("Ada Lovelace");
    }

    @Test
    void integersAsStringCombiner() {
        // Anforderung 2: Hier sind die Eingabeparameter Integer , aber der Rückgabewert ist String.
        // Dies erzwingt, dass das Interface zwei unterschiedliche generische Typen haben muss.
        Combiner<Integer, String> numbersAsStringCombiner = (number1, number2) -> "%s%s".formatted(number1, number2);
        String actual = numbersAsStringCombiner.combine(4, 2);
        assertThat(actual).isEqualTo("42");
    }

    @Test
    void integersAsDoubleCombiner() {
        // Anforderung 3: Eingabe Integer (T), Rückgabe Double (R). Bestätigt die Notwendigkeit der Trennung von Ein- und Ausgabetyp.
        Combiner<Integer, Double> numbersAsStringCombiner = (number1, number2) -> (double) (number1 + number2);
        Double actual = numbersAsStringCombiner.combine(4, 2);
        assertThat(actual).isWithin(TOLERANCE).of(6.0);
    }
}

