package org.example;

import org.junit.jupiter.api.Test;
import java.util.*;
import static com.google.common.truth.Truth.assertThat;

class MovieDatabaseTest {
    // List.of erstellt eine unveränderliche Liste mit Testdaten.
    private static final List<Movie> MOVIES = List.of(
            new Movie("The Godfather", Category.DRAMA),
            new Movie("Toy Story", Category.COMEDY),
            new Movie("Guardians of the Galaxy", Category.ACTION, Category.COMEDY, Category.SCIFI),
            new Movie("Titanic", Category.DRAMA, Category.ROMANCE),
            new Movie("The Dark Knight", Category.ACTION, Category.DRAMA),
            new Movie("Finding Nemo", Category.COMEDY, Category.DRAMA),
            new Movie("Interstellar", Category.SCIFI, Category.DRAMA),
            new Movie("Alien", Category.SCIFI, Category.HORROR),
            new Movie("Terminator", Category.SCIFI, Category.ACTION),
            new Movie("Dune", Category.SCIFI, Category.ACTION, Category.DRAMA)
    );

    // Setup: Die Datenbank wird einmalig mit den Testfilmen initialisiert.
    private final MovieDatabase movieDatabase = new MovieDatabase(MOVIES);

    @Test
    void forEachCallsLambdaWithEachMovie() {
        // Vorbereitung: Eine leere Liste, in die wir die Filme kopieren wollen.
        List<Movie> movies = new LinkedList<>();

        // Test der 'forEach'-Methode.
        // Das Lambda (movie -> { ... }) ist hier der Consumer.
        // Besonderheit: Dieses Lambda hat einen "Seiteneffekt". Es verändert den Zustand außerhalb des Lambdas
        // (es schreibt in die 'movies'-Variable). Das ist bei 'forEach' typisch.
        movieDatabase.forEach(movie -> {
            movies.add(movie);
        });

        // Prüfung: Enthält unsere manuell befüllte Liste exakt die gleichen Elemente wie die Ur-Liste?
        assertThat(movies).containsExactlyElementsIn(MOVIES);
    }

    @Test
    void findMoviesByCategory() {
        // Test der 'findByCategory'-Methode.
        // Hier übergeben wir die Suchlogik als Lambda (Predicate).
        // Die Logik ist zusammengesetzt: (Ist SciFi?) UND (Ist Action?).
        // Das '&&' verknüpft zwei boolesche Ausdrücke.
        Collection<Movie> actual = movieDatabase.findByCategory(movie ->
                movie.hasCategory(Category.SCIFI) && movie.hasCategory(Category.ACTION)
        );

        // Prüfung: Wir erwarten genau 3 spezifische Filme, die beide Kategorien haben.
        // Guardians (Action, SciFi, Comedy) -> Treffer
        // Terminator (Action, SciFi) -> Treffer
        // Dune (Action, SciFi, Drama) -> Treffer
        // Alien (SciFi, Horror) -> Kein Treffer (fehlt Action)
        assertThat(actual).containsExactlyElementsIn(List.of(
                new Movie("Guardians of the Galaxy", Category.ACTION, Category.SCIFI, Category.COMEDY),
                new Movie("Terminator", Category.ACTION, Category.SCIFI),
                new Movie("Dune", Category.ACTION, Category.SCIFI, Category.DRAMA)
        ));
    }
}