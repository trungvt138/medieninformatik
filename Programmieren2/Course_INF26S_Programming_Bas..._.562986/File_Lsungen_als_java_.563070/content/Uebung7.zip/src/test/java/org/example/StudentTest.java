package org.example;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

class StudentTest {

    private Student student;

    // @BeforeEach sorgt für Test-Isolation.
    // Jeder Test startet mit einer frischen Instanz von Student.
    // Warum? Damit Änderungen in einem Test (z.B. ID ändern) keine unerwarteten Fehler in anderen Tests verursachen.
    @BeforeEach
    void setUp() {
        student = new Student(1, "Grace");
    }

    // Standard-Test für Getter und Setter ohne Event-Logik.
    @Test
    void getSetId() {
        student.setId(2);
        assertEquals(2, student.id());
    }

    @Test
    void getSetName() {
        student.setName("Grace Hopper");
        assertEquals("Grace Hopper", student.name());
    }

    @Test
    void toStringWithIdAndName() {
        var actual = student.toString();
        assertEquals("Student{id=1, name='Grace'}", actual);
    }

    // Test des Observer-Patterns für ID-Änderungen.
    @Test
    void idModified() {
        // Assert (Vorbereitung der Erwartungshaltung)
        // Wir registrieren den Callback VOR der Aktion.
        // Das Lambda definiert, was wir prüfen wollen, SOBALD das Event eintritt.
        student.subscribeOnModified(modifiedStudent -> {
            // Hier prüfen wir: Hat das Objekt, das im Event übergeben wurde, wirklich die neue ID?
            assertEquals(2, modifiedStudent.id());
            // Und: Ist der Name unverändert geblieben?
            assertEquals("Grace", modifiedStudent.name());
        });

        // Act (Auslösen der Aktion)
        // Das Setzen der ID muss intern `publishOnModified` aufrufen, was unser Lambda oben ausführt.
        student.setId(2);
    }

    // Test des Observer-Patterns für Namens-Änderungen.
    @Test
    void nameModified() {
        // Assert (Callback definieren)
        // `modifiedStudent` ist der Parameter `this`, der aus `publishOnModified` übergeben wird.
        student.subscribeOnModified(modifiedStudent -> {
            // Wir erwarten, dass die ID gleich geblieben ist...
            assertEquals(1, modifiedStudent.id());
            // ...aber der Name aktualisiert wurde.
            assertEquals("Grace Hopper", modifiedStudent.name());
        });

        // Act
        // Löst die Kette aus: setName -> Feld ändern -> publish -> Callback aufrufen -> Assertions prüfen.
        student.setName("Grace Hopper");
    }
}