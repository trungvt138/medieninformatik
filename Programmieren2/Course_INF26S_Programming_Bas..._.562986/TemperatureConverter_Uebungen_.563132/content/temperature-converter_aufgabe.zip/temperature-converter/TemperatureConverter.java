package refactoring.temperatureConverter;

class TemperatureConverter {

    public static float convert(String c, float v) {
        int t = Integer.parseInt(c);
        float value = v;
        if (t == 1) {
            float value1 = (float) ((value * (1.8)) + 32);
            value = value1;
        }
        if (t == 2) {
            float value2 = (value - 32);
            float value3 = (value2 * (5) / 9);
            value = value3;
        }
        return value;
    }
}