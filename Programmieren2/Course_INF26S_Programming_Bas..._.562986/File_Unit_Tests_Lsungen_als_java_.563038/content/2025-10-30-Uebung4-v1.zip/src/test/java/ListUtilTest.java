import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Dies ist die Testklasse für ListUtil.
 * Das Ziel ist 100% Testabdeckung, inklusive Edge-Cases.
 */
class ListUtilTest {

    /**
     * Testfall für die createLinkedList() Methode.
     * Dies ist der "Happy Path" (der normale, erwartete Fall).
     */
    @Test
    void createLinkedList() {
        // Arrange: Definiere das erwartete Ergebnis.
        // Laut Aufgabenstellung soll eine Liste mit bestimmten Strings erstellt werden.
        LinkedList<String> expectedResult = new LinkedList<>(List.of("This", "will", "be", "tested", "with", "JUnit"));

        // Act: Rufe die zu testende Methode auf.
        List<String> actualResult = ListUtil.createLinkedList();

        // Assert: Vergleiche das tatsächliche Ergebnis mit dem erwarteten.
        assertEquals(expectedResult, actualResult);

        // HINWEIS: Der auskommentierte Test prüft den spezifischen Implementierungstyp (LinkedList).
        // Das ist ein "Fragile Test" (zerbrechlicher Test). Die Methode gibt 'List' zurück;
        // ob dahinter eine LinkedList oder ArrayList steckt, ist ein Implementierungsdetail
        // und sollte den Test nicht interessieren, solange der Inhalt stimmt.
        // assertInstanceOf(LinkedList.class, actualResult); // Nicht empfohlen #FragileTest
    }

    /**
     * Testfall für getMostFrequentElement().
     * Dies ist der "Happy Path", der die Hauptlogik testet.
     * Die Anforderung: "Returns the most-often-occurring item".
     * Bei Gleichstand: "the lowest one is returned".
     */
    @Test
    void getMostFrequentElementTest() {
        // Arrange: Erstelle eine Testliste.
        // Zählung: 3 (1x), 1 (2x), 2 (3x), 4 (1x)
        List<Integer> integerList = List.of(3, 1, 2, 2, 1, 2, 4);
        // Das häufigste Element ist '2' (kommt 3x vor).
        Integer expectedResult = 2;

        // Act: Rufe die Methode auf.
        Integer actualResult = ListUtil.getMostFrequentElement(integerList);

        // Assert: Prüfe, ob das korrekte Element (2) gefunden wurde.
        assertEquals(expectedResult, actualResult);
    }

    /**
     * Testfall für getMostFrequentElement().
     * Dies ist der "Edge Case" (Grenzfall), der in der Aufgabenstellung verlangt wurde[cite: 21].
     * Was passiert, wenn die Liste leer ist?
     * Laut Implementierung (siehe ListUtil.java) wird eine NoSuchElementException erwartet.
     */
    @Test
    void getMostFrequentElementNoSuchElementException() {
        // Arrange: Erstelle eine leere Liste.
        List<Integer> integerList = List.of();

        // Act & Assert: Wir prüfen, ob der Aufruf der Methode eine Exception auslöst.
        // 'assertThrows' ist eine JUnit 5 Methode, um Exceptions zu testen.
        // 1. Parameter: Die *erwartete* Exception-Klasse (NoSuchElementException.class).
        // 2. Parameter: Ein "Executable" (ausführbarer Code), oft als Lambda-Ausdruck geschrieben: () -> ...
        //    Dieser Lambda-Ausdruck enthält den "Act"-Teil, also den Aufruf, der die Exception werfen soll.
        assertThrows(NoSuchElementException.class, () -> ListUtil.getMostFrequentElement(integerList));
    }
}