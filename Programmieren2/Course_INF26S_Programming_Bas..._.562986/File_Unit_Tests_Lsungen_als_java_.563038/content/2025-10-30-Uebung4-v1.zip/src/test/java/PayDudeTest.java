import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PayDudeTest {

    /**
     * Testet den Edge-Case (Grenzfall) für die 'deposit'-Methode.
     * Prüft, ob die Validierung 'assertNotNegative' ausgelöst wird.
     */
    @Test
    void depositNegativeAmountNotAllowed() {
        // Arrange: Erstelle das Testobjekt.
        // (Das 'var' ist eine moderne Java-Schreibweise für 'PayDude dude = ...')
        var dude = new PayDude();

        // Act + Assert: Wir führen die Aktion aus UND prüfen das Ergebnis gleichzeitig.
        // 'assertThrows' wird verwendet, wenn das *erwartete* Ergebnis eine Exception ist.
        // 1. Parameter: Die erwartete Exception-Klasse (unsere eigene PayDudeException).
        // 2. Parameter: Ein Lambda-Ausdruck, der den Code ausführt, der die Exception
        //    auslösen soll (der "Act"-Teil).
        assertThrows(PayDudeException.class, () -> dude.deposit(-1));
    }

    /**
     * Testet den Edge-Case für die 'transfer'-Methode.
     * Prüft ebenfalls 'assertNotNegative', aber diesmal im Kontext von 'transfer'.
     */
    @Test
    void transferNegativeAmountNotAllowed() {
        // Arrange: Wir brauchen zwei Dudes für eine Überweisung.
        var dude = new PayDude();
        var otherDude = new PayDude();

        // Act + Assert: Wie oben, wir erwarten eine PayDudeException.
        assertThrows(PayDudeException.class, () -> dude.transfer(-1, otherDude));
    }

    /**
     * Testet den Initialzustand eines Objekts.
     * Ein guter Test prüft, ob ein Objekt im korrekten Zustand startet (hier: balance = 0).
     */
    @Test
    void eachNewDudeStartsBroke() {
        // Arrange: Erstelle ein neues Objekt.
        var dude = new PayDude();

        // Act: Hole den Startwert.
        var actual = dude.getBalance();

        // Assert: Vergleiche den tatsächlichen Wert (actual) mit dem erwarteten (0).
        assertEquals(0, actual);
    }

    /**
     * Testet den "Happy Path" (Normalfall) der 'deposit'-Methode.
     * Prüft, ob Einzahlungen korrekt aufaddiert werden.
     */
    @Test
    void sumOfDepositedMoneyIsReturnedAsBalanced() {
        // Arrange: Erstelle ein Objekt und führe mehrere Aktionen aus.
        var dude = new PayDude();
        dude.deposit(1);
        dude.deposit(2);
        dude.deposit(3);

        // Act: Hole das Endergebnis.
        var actual = dude.getBalance();

        // Assert: Prüfe, ob die Summe (1 + 2 + 3) korrekt berechnet wurde.
        assertEquals(6, actual);
    }

    /**
     * Testet den "Happy Path" (Normalfall) der 'transfer'-Methode.
     * Dies ist der wichtigste Test für 'transfer', da er *beide* Seiten
     * der Transaktion prüft.
     */
    @Test
    void whenTransferMoneyToOtherDudeThanOneDudeLoosesMoneyAndOtherDudeReceivesMoney() {
        // Arrange: Sender erstellen und ihm Geld geben. Empfänger erstellen.
        var dude = new PayDude();
        dude.deposit(1);
        var otherDude = new PayDude();

        // Act: Die Überweisung durchführen.
        dude.transfer(1, otherDude);

        // Assert: Wir brauchen zwei Asserts, um den Zustand beider Objekte zu prüfen.
        // 1. Hat der Sender das Geld verloren?
        assertEquals(0, dude.getBalance());
        // 2. Hat der Empfänger das Geld erhalten?
        assertEquals(1, otherDude.getBalance());
    }

    /**
     * Testet den "Sad Path" (Fehlerfall) der 'transfer'-Methode.
     * Prüft die Geschäftsregel 'assertBalanceIsSufficient'.
     */
    @Test
    void cannotTransferMoneyIfDudeHasNotEnoughMoney() {
        // Arrange: Sender erstellen und ihm 1 Cent geben. Empfänger erstellen.
        var dude = new PayDude();
        dude.deposit(1);
        var otherDude = new PayDude();

        // Act & Assert: Wir erwarten eine Exception, wenn der Sender versucht,
        // mehr Geld (2) zu überweisen, als er hat (1).
        assertThrows(PayDudeException.class, () -> dude.transfer(2, otherDude));
    }
}