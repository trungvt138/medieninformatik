import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CurrencyConverterTest {
    private static final double CONVERSION_TOLERANCE = 0.000000000001d;
    private CurrencyConverter converter;

    @BeforeEach
    void setup() {
        converter = new CurrencyConverter();
    }

    @Test
    void convertFromEuroToDollar() {
        // Act
        var actual = converter.convert(Currency.EURO, Currency.DOLLAR, 2.0);
        // Assert
        assertEquals(Currency.DOLLAR, actual.currency());
        assertEquals(2.12608, actual.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void convertFromDollarToEuro() {
        // Act
        var actual = converter.convert(Currency.DOLLAR, Currency.EURO, 2.0);
        // Assert
        assertEquals(Currency.EURO, actual.currency());
        assertEquals(1.88112, actual.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void convertWithMoneyToGivenCurrency() {
        // Arrange
        var money = new Money(2.0, Currency.EURO);
        // Act
        var actual = converter.convert(money, Currency.DOLLAR);
        // Assert
        assertEquals(Currency.DOLLAR, actual.currency());
        assertEquals(2.12608, actual.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void convertFromDollarToEuroWithFloatAmount() {
        // Act
        var actual = converter.convert(Currency.DOLLAR, Currency.EURO, 2.0f);
        // Assert
        assertEquals(Currency.EURO, actual.currency());
        assertEquals(1.88112, actual.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void returnsZeroWhenConvertingZero() {
        // Act
        var actual = converter.convert(Currency.EURO, Currency.DOLLAR, 0.0);
        // Assert
        assertEquals(Currency.DOLLAR, actual.currency());
        assertEquals(0.0, actual.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void throwExceptionWhenConvertingNonExistingCurrencyPair() {
        assertThrows(CurrencyNotSupportedException.class, () -> converter.convert(Currency.EURO, Currency.INVALID, 1.0));
        assertThrows(CurrencyNotSupportedException.class, () -> converter.convert(Currency.INVALID, Currency.DOLLAR, 1.0));
    }

    @Test
    void throwExceptionWhenConvertingCurrencyWithItself() {
        assertThrows(CurrencyNotSupportedException.class, () -> converter.convert(Currency.EURO, Currency.EURO, 1.0));
        assertThrows(CurrencyNotSupportedException.class, () -> converter.convert(Currency.DOLLAR, Currency.DOLLAR, 1.0));
        assertThrows(CurrencyNotSupportedException.class, () -> converter.convert(Currency.INVALID, Currency.INVALID, 1.0));
    }

    @Test
    void throwExceptionWhenConvertingNegativeAmounts() {
        assertThrows(NegativeValueException.class, () -> converter.convert(Currency.EURO, Currency.DOLLAR, -1.0));
    }

    @Test
    void getConversionRateForEuroToDollar() {
        // Act
        var euroToDollarRate = converter.getConversionRate(Currency.EURO, Currency.DOLLAR);
        // Assert
        assertEquals(1.06304, euroToDollarRate.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void getConversionRateForDollarToEuro() {
        // Act
        var dollarToEuroRate = converter.getConversionRate(Currency.DOLLAR, Currency.EURO);
        // Assert
        assertEquals(0.94056, dollarToEuroRate.value(), CONVERSION_TOLERANCE);
    }

    @Test
    void throwExceptionWhenGettingNonExistingConversionRate() {
        assertThrows(CurrencyNotSupportedException.class, () -> converter.getConversionRate(Currency.EURO, Currency.INVALID));
    }
}
