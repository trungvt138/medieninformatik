import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;


class HospitalTest {
    // Eine Konstante, um die Tests konsistent zu machen.
    private static final int NUMBER_OF_BEDS = 2;

    // Das "Subject Under Test" (SUT) oder "Objekt unter Test".
    private Hospital hospital;

    /**
     * Diese @BeforeEach-Methode wird *vor jedem einzelnen Test* ausgeführt.
     * Sie stellt sicher, dass jeder Test mit einem frischen, sauberen
     * 'hospital'-Objekt (mit 2 Betten) startet.
     * Das nennt man **Test-Isolation**.
     */
    @BeforeEach
    void setup() {
        hospital = new Hospital(NUMBER_OF_BEDS);
    }

    /**
     * "Happy Path"-Test für 'add()' und 'patientCount()'.
     * Prüft, ob sich der Zähler nach dem Hinzufügen erhöht.
     */
    @Test
    void whenAddPatient_thenNumberOfPatientsIncreases() {
        // Arrange
        var expectedNumber = 1;

        // Act
        hospital.add(new Patient("1"));
        var actualNumber = hospital.patientCount();

        // Assert
        assertEquals(expectedNumber, actualNumber);
    }

    /**
     * "Happy Path"-Test für 'healNextPatient()' und 'patientCount()'.
     * Prüft, ob sich der Zähler nach dem Heilen verringert.
     */
    @Test void whenHealPatient_thenNumberOfPatientsDecreases() {
        // Arrange
        var expectedNumber = 1;
        hospital.add(new Patient("1"));
        hospital.add(new Patient("2")); // Hospital ist jetzt voll (2/2)

        // Act
        hospital.healNextPatient(); // Heilt Patient "1"

        // Assert
        var actualNumber = hospital.patientCount(); // Sollte jetzt 1 sein
        assertEquals(expectedNumber, actualNumber);
    }

    /**
     * "Happy Path"-Test für 'add()'.
     * Prüft, ob die Methode 'true' zurückgibt, wenn das Hinzufügen klappt.
     */
    @Test void whenAddPatient_thenReturnTrue() {
        // Arrange
        var patient = new Patient("1");

        // Act
        var actualResult = hospital.add(patient);

        // Assert
        assertTrue(actualResult);
    }

    /**
     * "Sad Path" / Business-Rule-Test für 'add()'.
     * Prüft, ob die Methode 'false' zurückgibt, wenn man einen
     * bereits existierenden Patienten hinzufügt (Guard-Klausel Nr. 3).
     */
    @Test void whenAddExistingPatient_thenReturnFalse() {
        // Arrange
        var patient = new Patient("1");
        hospital.add(patient); // Erstes Hinzufügen (sollte klappen)

        // Act
        var actualResult = hospital.add(patient); // Zweites Hinzufügen (sollte fehlschlagen)

        // Assert
        assertFalse(actualResult);
    }

    /**
     * "Sad Path" / Business-Rule-Test für 'add()'.
     * Prüft, ob die Methode 'false' zurückgibt, wenn das Krankenhaus voll ist
     * (Guard-Klausel Nr. 2).
     */
    @Test void givenFullHospital_whenAddPatient_thenDoNotAddPatient() {
        // Arrange: Krankenhaus füllen (Kapazität ist 2)
        hospital.add(new Patient("1"));
        hospital.add(new Patient("2"));

        // Act: Versuchen, einen dritten Patienten hinzuzufügen
        var actualValue = hospital.add(new Patient("3"));

        // Assert: Das Hinzufügen muss fehlschlagen ('false').
        assertFalse(actualValue);
    }

    /**
     * "Happy Path"-Test für 'healNextPatient()'.
     * Dieser Test ist SEHR WICHTIG: Er prüft die FIFO-Logik (First-In, First-Out).
     * Der Patient, der als *erster* reinkam ("1"), muss als *erster* geheilt werden.
     */
    @Test void whenNextPatientIsHealed_thenReturnFirstPatient() {
        // Arrange
        var expectedCard = new Patient("1"); // Der erste Patient
        hospital.add(expectedCard);
        hospital.add(new Patient("2")); // Der zweite Patient

        // Act
        var actualCard = hospital.healNextPatient(); // Muss "1" sein

        // Assert
        assertEquals(expectedCard, actualCard);
    }

    /**
     * "Happy Path"-Test für 'contains()'.
     */
    @Test void whenPatientWasAdded_thenHospitalContainsAddedPatient() {
        // Arrange
        var expectedCard = new Patient("1");
        hospital.add(expectedCard);
        hospital.add(new Patient("2"));

        // Act
        var actualValue = hospital.contains(expectedCard);

        // Assert
        assertTrue(actualValue);
    }

    /**
     * "Sad Path"-Test für 'contains()'.
     */
    @Test void whenPatientNotExists_thenHospitalDoesNotContainPatient() {
        // Arrange
        hospital.add(new Patient("1"));
        hospital.add(new Patient("2"));

        // Act: Suchen nach einem Patienten, der nicht hinzugefügt wurde.
        var actualValue = hospital.contains(new Patient("3"));

        // Assert
        assertFalse(actualValue);
    }

    /**
     * "Happy Path"-Test für 'add()'.
     * (Ähnlich wie 'whenAddPatient_thenReturnTrue', aber prüft explizit
     * den Fall "nicht voll").
     */
    @Test void givenNonFullHospital_whenAddPatient_thenAddPatient() {
        // Act
        var actualValue = hospital.add(new Patient("1"));

        // Assert
        assertTrue(actualValue);
    }

    /**
     * "Sad Path" / Edge-Case-Test für 'healNextPatient()'.
     * Prüft, ob eine 'HospitalException' geworfen wird, wenn man
     * 'healNextPatient()' auf einem leeren Krankenhaus aufruft.
     */
    @Test void givenEmptyHospital_whenHealNextPatient_thenReturnException() {
        // 'assertThrows' prüft, ob der Lambda-Ausdruck () -> ...
        // die erwartete Exception (HospitalException.class) wirft.
        assertThrows(HospitalException.class, () -> hospital.healNextPatient());
    }

    /**
     * "Happy Path" / Edge-Case-Test für 'hasPatients()'.
     * Prüft, ob 'hasPatients()' korrekterweise 'false' zurückgibt,
     * nachdem der letzte Patient geheilt wurde.
     */
    @Test void whenHealLastPatient_thenHospitalHasNoPatients() {
        // Arrange
        hospital.add(new Patient("1"));

        // Act
        hospital.healNextPatient(); // Jetzt ist das Krankenhaus leer

        // Assert
        assertFalse(hospital.hasPatients());
    }

    /**
     * "Happy Path"-Test für 'hasPatients()'.
     * Prüft, ob 'hasPatients()' 'true' zurückgibt, solange noch
     * Patienten übrig sind.
     */
    @Test void whenHealAnotherPatient_thenHospitalHasStillPatients() {
        // Arrange
        hospital.add(new Patient("1"));
        hospital.add(new Patient("2"));

        // Act
        hospital.healNextPatient(); // Patient "1" ist weg, "2" ist noch da

        // Assert
        assertTrue(hospital.hasPatients());
    }

    /**
     * "Sad Path" / Edge-Case-Test für 'add()'.
     * Prüft, ob die Methode 'false' zurückgibt, wenn man 'null' hinzufügt
     * (Guard-Klausel Nr. 1).
     */
    @Test void whenAddNullPatient_thenReturnFalse() {
        // Act
        var actualResult = hospital.add(null);

        // Assert
        assertFalse(actualResult);
    }

    /**
     * Test für die Bonus-Methode 'longtermPatients()'.
     * Prüft, ob die Methode die ersten 'max' Patienten in der
     * korrekten Reihenfolge (FIFO) zurückgibt.
     */
    @Test
    void givenHospitalWithThreePatients_whenGetLongtermPatientsTwo_thenReturnFirstTwoPatients()
    {
        // Arrange:
        // Wir brauchen ein neues Hospital mit 3 Betten (das @BeforeEach hat nur 2).
        var anotherHospital = new Hospital(3);
        var patient1 = new Patient("1"); // Kam als Erster
        var patient2 = new Patient("2"); // Kam als Zweiter
        anotherHospital.add(patient1);
        anotherHospital.add(patient2);
        anotherHospital.add(new Patient("3")); // Kam als Dritter

        // Das erwartete Ergebnis (die 2 längsten Patienten) sind "1" und "2".
        var expectedPatients = List.of(patient1, patient2);

        // Act: Rufe die Methode auf
        var actualPatients = anotherHospital.longtermPatients(2);

        // Assert
        assertEquals(expectedPatients, actualPatients);
    }
}