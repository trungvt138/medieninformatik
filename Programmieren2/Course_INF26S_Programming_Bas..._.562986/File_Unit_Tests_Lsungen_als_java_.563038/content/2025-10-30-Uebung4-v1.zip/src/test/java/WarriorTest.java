import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;



class WarriorTest {
    @Test
    void testAttackWithRocketLauncher() {
        // Arrange
        var attacker = new Warrior(100, new RocketLauncher());
        var defender = new Warrior(1000, new Love());
        // Act
        attacker.attack(defender);
        // Assert
        assertEquals(900, defender.getHealth());
    }
    @Test
    void testLoveCausesNegativeHealth() {
        // Arrange
        var attacker = new Warrior(100, new Love());
        var defender = new Warrior(1000, new RocketLauncher());
        // Act
        attacker.attack(defender);
        // Assert
        assertEquals(-1.7976931348623157E308, defender.getHealth(), 0.000000000000001);
    }
    @Test
    void testAttackWithNull() {
        // Arrange
        var attacker = new Warrior(100, null);
        var defender = new Warrior(1000, new RocketLauncher());
        // Act & Assert
        assertThrows(NullPointerException.class, () -> attacker.attack(defender));
    }
    @Test
    void testAttackSelf() {
        // Arrange
        var self = new Warrior(100, new RocketLauncher());
        // Act
        self.attack(self);
        // Assert
        assertEquals(0, self.getHealth());
    }
}