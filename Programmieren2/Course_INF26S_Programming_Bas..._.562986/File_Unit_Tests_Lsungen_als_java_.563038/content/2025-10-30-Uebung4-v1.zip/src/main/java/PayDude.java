class PayDude {
    // Jede Instanz von PayDude hat ihr eigenes Guthaben.
    // 'private' stellt sicher, dass es nicht von außen direkt manipuliert werden kann.
    // Es startet bei 0, was im Test "eachNewDudeStartsBroke" geprüft wird.
    private long balance = 0; // Steht für eine beliebige Währung in Cents

    /**
     * Zahlt Geld auf das Konto ein.
     */
    void deposit(long amount) { // Geld einzahlen
        // Zuerst wird geprüft, ob der Betrag gültig ist.
        // Wenn 'amount' negativ ist, wirft diese Methode eine 'PayDudeException'.
        assertNotNegative(amount);

        // Nur wenn die Prüfung besteht, wird das Guthaben erhöht.
        balance += amount;
    }

    /**
     * Überweist Geld an einen anderen PayDude-Empfänger.
     */
    void transfer(long amount, PayDude recipient) { // Geld überweisen
        // Schritt 1: Prüfen, ob der Betrag negativ ist.
        assertNotNegative(amount);

        // Schritt 2: Prüfen, ob das eigene Guthaben ('balance') ausreicht.
        assertBalanceIsSufficient(amount);

        // Schritt 3: Betrag vom eigenen Guthaben abziehen.
        balance -= amount;

        // Schritt 4: Betrag beim Empfänger einzahlen.
        // Diese Methode ruft intern wieder recipient.assertNotNegative() auf,
        // aber da wir 'amount' bereits in Schritt 1 geprüft haben, ist das hier sicher.
        recipient.deposit(amount);
    }

    /**
     * Private Hilfsmethode zur Validierung des Guthabens.
     * Wirft eine Exception, wenn das Guthaben nicht ausreicht.
     */
    private void assertBalanceIsSufficient(long amount) { // Prüfen, ob ausreichend Geld vorhanden ist
        // Dies ist die Geschäftsregel: Man kann nicht mehr überweisen, als man hat.
        if (balance < amount) {
            // "throw" bricht die Methode sofort ab und signalisiert einen Fehler.
            // Dieser Fehler wird im Test "cannotTransferMoneyIfDudeHasNotEnoughMoney" erwartet.
            throw new PayDudeException("Go get some money, dude.");
        }
    }

    /**
     * Private Hilfsmethode zur Validierung von Beträgen.
     * Verhindert negative Einzahlungen oder Überweisungen.
     */
    private void assertNotNegative(long amount) {
        if (amount < 0) {
            // Dieser Fehler wird in "depositNegativeAmountNotAllowed"
            // und "transferNegativeAmountNotAllowed" geprüft.
            throw new PayDudeException("Negative amounts are not allowed.");
        }
    }

    /**
     * Getter-Methode, um das Guthaben von außen lesbar zu machen (z.B. für Tests).
     */
    long getBalance() {
        return balance;
    }
}
