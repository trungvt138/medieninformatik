// Ein Record für das Endergebnis, das den Wert und die Währung bündelt.
record Money(double value, Currency currency) {
}