class Warrior {
    private double health;
    private final Weapon weapon;
    Warrior(double health, Weapon weapon) {
        this.health = health;
        this.weapon = weapon;
    }
    void attack(Warrior otherWarrior) {
        otherWarrior.receiveDamage(weapon.attack());
    }
    private void receiveDamage(double damage) {
        health -= damage;
    }
    double getHealth() {
        return health;
    }
}