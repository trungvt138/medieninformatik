// Noch ein Record, diesmal für den Umrechnungskurs.
// Es kapselt den 'double'-Wert, was den Code lesbarer macht als
// 'Map<CurrencyPair, Double>'.
record ConversionRate(double value) {
    // Factory-Methode für bessere Lesbarkeit.
    static ConversionRate of(double value) {
        return new ConversionRate(value);
    }
}
