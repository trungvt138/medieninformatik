// Eigene Exception-Klasse für den Fall, dass ein Währungspaar nicht unterstützt wird.
class CurrencyNotSupportedException extends RuntimeException {
    public CurrencyNotSupportedException(String message) {
        super(message); // Gibt die Nachricht an die Elternklasse (RuntimeException) weiter.
    }
}