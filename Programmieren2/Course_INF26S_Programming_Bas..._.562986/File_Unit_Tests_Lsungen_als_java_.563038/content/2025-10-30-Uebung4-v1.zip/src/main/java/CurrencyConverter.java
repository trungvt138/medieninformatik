import java.util.HashMap;
import java.util.Map;

class CurrencyConverter {

    // Ein 'record' (eingeführt in Java 14) ist eine kompakte Art,
    // eine "dumme" Datencontainer-Klasse zu erstellen.
    // Der Compiler generiert automatisch:
    // 1. Private final Felder (from, to)
    // 2. Einen Konstruktor (public CurrencyPair(Currency from, Currency to))
    // 3. Getter-Methoden (from(), to())
    // 4. equals(), hashCode() und toString() Methoden
    // Dieses Record dient als zusammengesetzter Schlüssel für unsere Map.
    private record CurrencyPair(Currency from, Currency to) {
        // 'of' ist eine "Factory-Methode". Sie macht den Code lesbarer.
        // Statt 'new CurrencyPair(a, b)' schreiben wir 'CurrencyPair.of(a, b)'.
        public static CurrencyPair of(Currency from, Currency to) {
            return new CurrencyPair(from, to);
        }
    }

    // Eine Map speichert Schlüssel-Wert-Paare.
    // - Schlüssel (Key): CurrencyPair (z.B. von EURO nach DOLLAR)
    // - Wert (Value): ConversionRate (der Umrechnungskurs)
    // 'final' bedeutet, dass die Map selbst nicht neu zugewiesen werden kann
    // (wir können aber Einträge hinzufügen/entfernen).
    private final Map<CurrencyPair, ConversionRate> conversions = new HashMap<>();

    // Dies ist der Konstruktor der Klasse.
    // Er wird jedes Mal aufgerufen, wenn ein neues CurrencyConverter-Objekt
    // mit 'new CurrencyConverter()' erstellt wird.
    CurrencyConverter() {
        // Beim Erstellen wird die Map sofort mit den Kursen befüllt.
        initConversionRates();
    }

    // Private Methode, um die Kurse zu laden.
    private void initConversionRates() {
        // .put() fügt einen Eintrag zur Map hinzu.
        conversions.put(CurrencyPair.of(Currency.EURO, Currency.DOLLAR), ConversionRate.of(1.06304));
        conversions.put(CurrencyPair.of(Currency.DOLLAR, Currency.EURO), ConversionRate.of(0.94056));
    }

    /**
     * Bequemlichkeitsmethode (Convenience Method).
     * Sie nimmt ein 'Money'-Objekt entgegen, extrahiert dessen Werte
     * und ruft die detailliertere 'convert'-Methode unten auf.
     */
    Money convert(Money fromMoney, Currency toCurrency) {
        // Delegiert den Aufruf an die andere 'convert'-Methode.
        return convert(fromMoney.currency(), toCurrency, fromMoney.value());
    }

    /**
     * Die Haupt-Logikmethode. Konvertiert einen Betrag von einer Währung zur anderen.
     */
    Money convert(Currency fromCurrency, Currency toCurrency, double amount) {
        // Schritt 1: Validierung (ein "Guard Clause" oder Wächter).
        // Negative Beträge sind nicht erlaubt.
        if (amount < 0) {
            // "throw" bricht die Methode sofort ab und wirft einen Fehler.
            // Dieser Fehlerfall wird im Test "throwExceptionWhenConvertingNegativeAmounts" geprüft.
            throw new NegativeValueException("Negative amount cannot be converted.");
        }

        // Schritt 2: Den Umrechnungskurs holen.
        // Diese Methode kann selbst eine Exception werfen, wenn das Währungspaar
        // nicht existiert (wird in Tests geprüft).
        var conversionRate = getConversionRate(fromCurrency, toCurrency);

        // Schritt 3: Die Umrechnung durchführen.
        var result = amount * conversionRate.value();

        // Schritt 4: Das Ergebnis als neues 'Money'-Objekt zurückgeben.
        return new Money(result, toCurrency);
    }

    /**
     * Holt den Umrechnungskurs aus der Map.
     * (Diese Methode ist "package-private", d.h. sie ist auch für die Testklasse sichtbar).
     */
    ConversionRate getConversionRate(Currency fromCurrency, Currency toCurrency) {
        // Erstellt das Schlüssel-Objekt, nach dem wir in der Map suchen.
        var currencyPair = CurrencyPair.of(fromCurrency, toCurrency);

        // Prüft, ob ein Eintrag für diesen Schlüssel existiert.
        var currencyPairExists = conversions.containsKey(currencyPair);

        // Schritt 1: Validierung.
        if (!currencyPairExists) {
            // Wenn der Kurs nicht in der Map ist (z.B. EURO -> INVALID),
            // wird eine Exception geworfen.
            // Dies wird in "throwExceptionWhenConvertingNonExistingCurrencyPair"
            // und "throwExceptionWhenConvertingCurrencyWithItself" getestet.
            throw new CurrencyNotSupportedException(currencyPair.toString());
        }

        // Schritt 2: Den Wert aus der Map holen und zurückgeben.
        return conversions.get(currencyPair);
    }
}






