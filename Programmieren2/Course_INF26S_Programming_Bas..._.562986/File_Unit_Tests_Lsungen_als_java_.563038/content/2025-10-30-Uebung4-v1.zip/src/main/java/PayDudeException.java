
/**
 * Dies ist eine "Custom Exception" (eigene Exception-Klasse).
 * Wozu brauche ich die?
 * * 1. Semantik: Sie macht den Code lesbarer. Wenn ein Test fehlschlägt und
 * eine `PayDudeException` sieht, weiß der Entwickler sofort, dass der Fehler
 * innerhalb der `PayDude`-Logik passiert ist (z.B. "Guthaben nicht ausreichend")
 * und nicht durch einen generischen Java-Fehler (wie `NullPointerException`
 * oder `IllegalArgumentException`).
 * 2. Spezifisches Fangen: Man könnte diese spezielle Exception gezielt
 * in einer Anwendung fangen (z.B. in einem `try-catch`-Block), um dem
 * Benutzer eine saubere Fehlermeldung anzuzeigen ("Du hast nicht genug Geld!"),
 * während andere, unerwartete Exceptions (z.B. `NullPointerException`)
 * zum Absturz der App führen würden.
 * Sie erbt von `RuntimeException`, was bedeutet, dass sie eine "unchecked" Exception ist.
 * Der Entwickler *muss* sie nicht mit `try-catch` behandeln.
 */
class PayDudeException extends RuntimeException {
    public PayDudeException(String message) {
        // super(message); bedeutet: "Rufe den Konstruktor meiner Elternklasse auf, der einen String als Parameter akzeptiert."
        // auf und übergibt die Fehlermeldung.
        super(message);
    }
}