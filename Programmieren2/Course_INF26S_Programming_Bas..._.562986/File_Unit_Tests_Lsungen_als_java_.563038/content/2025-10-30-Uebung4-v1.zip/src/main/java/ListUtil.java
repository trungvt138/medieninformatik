import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

final class ListUtil {
    /**
     * * Create and return a List with the following Strings: "This", "will", "be", "tested", "with", "JUnit".
     */
    static List<String> createLinkedList() {
        // Die Methode gibt 'List' zurück, obwohl sie intern 'LinkedList' verwendet.
        // Das ist gut ("Coding against interfaces").
        return new LinkedList<>(List.of("This", "will", "be", "tested", "with", "JUnit"));
    }

    /**
     * Returns the most-often-occurring item in the given list.
     * If there is more than one most-often element, the lowest one is returned.
     * Tip: Ignore the actual implementation of this method. Instead, focus on the input parameter and the return value for your unit test.
     * Example: input [4, 4, 3, 2, 1] returns 4
     * Example: input [4, 3, 3, 2, 2, 1] returns 2
     * Example: input [4, 3, 2, 1] returns 1
     */
    static Integer getMostFrequentElement(List<Integer> integerList) {

        // --- Schritt 1: Frequenzen zählen ---
        Map<Integer, Long> elementToFrequency = integerList.stream()
                // .stream(): Wandelt die Liste in einen Stream um. Ein Stream ist eine Sequenz
                // von Elementen (hier Integers), die nacheinander verarbeitet werden können.

                .collect(
                        // .collect(): Eine "terminale Operation", die den Stream beendet und das Ergebnis
                        // in einer neuen Datenstruktur (z.B. List, Set, Map) sammelt.

                        Collectors.groupingBy(
                                // Collectors.groupingBy(...): Ein Collector, der Elemente gruppiert,
                                // Er erstellt eine Map.

                                Function.identity(),
                                // 1. Parameter (Classifier): Womit wird gruppiert?
                                // 'Function.identity()' bedeutet "nimm das Element selbst"
                                // (also die Zahl). Jede Zahl wird ein Key in der Map.

                                Collectors.counting()
                                // 2. Parameter (Downstream Collector): Was passiert mit den
                                // Elementen *innerhalb* einer Gruppe?
                                // 'Collectors.counting()' zählt sie einfach.
                        )
                );
        // Ergebnis von Schritt 1: Eine Map, z.B. {1=2, 2=3, 3=1, 4=1}


        // --- Schritt 2: Das häufigste Element finden ---
        return new TreeMap<>(elementToFrequency)
                // new TreeMap<>(...): Die Map wird in eine TreeMap umgewandelt.
                // EINE TREEMAP SORTIERT IHRE EINTRÄGE AUTOMATISCH NACH DEM SCHLÜSSEL (KEY).
                // Dies ist der Trick, um die Anforderung "the lowest one is returned"
                // bei Gleichstand zu erfüllen (siehe Beispiel [4,3,3,2,2,1] -> 2).

                .entrySet().stream()
                // .entrySet(): Holt alle (Key, Value)-Paare aus der Map.
                // .stream(): Wandelt diese Paare (Map.Entry) in einen neuen Stream um.

                .max(Map.Entry.comparingByValue())
                // .max(...): Findet das größte Element im Stream.
                // Map.Entry.comparingByValue(): Sagt .max(), dass es die Paare
                // anhand ihres *Wertes* (Value) – also der gezählten Frequenz (Long) –
                // vergleichen soll.
                // Dank der TreeMap [cite: 41] wird bei Frequenz-Gleichstand (z.B. 2=2, 3=2)
                // der Eintrag mit dem niedrigsten Key (2=2) gefunden.

                .orElseThrow(() -> new NoSuchElementException("Provided List was empty!"))
                // .max() gibt ein 'Optional' zurück, da der Stream leer sein könnte
                // (wenn die ursprüngliche Liste leer war).
                // .orElseThrow(...): Wenn das Optional leer ist (kein Max gefunden),
                // wird die hier definierte Exception geworfen.
                // Dies ist der "Edge Case", der im Test 'getMostFrequentElementNoSuchElementException'
                // geprüft werden muss.

                .getKey();
        // Wenn .max() einen Eintrag gefunden hat (z.B. das Paar 2=3),
        // holen wir uns mit .getKey() den Schlüssel (Key) dieses Eintrags,
        // also die Zahl '2'. Dies ist das Endergebnis.
    }
}