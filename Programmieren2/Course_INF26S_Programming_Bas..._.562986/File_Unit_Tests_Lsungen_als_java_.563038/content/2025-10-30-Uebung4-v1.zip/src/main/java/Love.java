class Love implements Weapon {
    @Override
    public double attack() {
        return Double.MAX_VALUE;
    }
}