// Eigene Exception-Klasse für den Fall, dass ein negativer Wert übergeben wird.
class NegativeValueException extends RuntimeException {
    public NegativeValueException(String message) {
        super(message); // Gibt die Nachricht an die Elternklasse weiter.
    }
}