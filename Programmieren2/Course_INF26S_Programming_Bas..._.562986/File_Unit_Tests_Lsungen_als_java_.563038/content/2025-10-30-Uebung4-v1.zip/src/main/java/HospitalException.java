/**
 * Eigene Exception-Klasse für Fehlerfälle im Hospital.
 * Erbt von RuntimeException (unchecked exception).
 */
class HospitalException extends RuntimeException {
    public HospitalException(String message) {
        super(message); // Leitet die Nachricht an die Elternklasse weiter.
    }
}