interface Weapon {
    double attack(); // Der Rückgabewert ist der Schaden, den die Waffe macht.
}