// Ein Enum (Aufzählung) definiert eine feste Menge von Konstanten.
// Hier werden die Währungen, mit denen die App umgehen kann, fest vordefiniert.
enum Currency {
    EURO, DOLLAR, INVALID
}