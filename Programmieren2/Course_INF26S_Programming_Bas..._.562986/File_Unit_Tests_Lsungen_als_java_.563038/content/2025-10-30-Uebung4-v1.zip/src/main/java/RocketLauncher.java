class RocketLauncher implements Weapon {
    @Override
    public double attack() {
        return 100;
    }
}