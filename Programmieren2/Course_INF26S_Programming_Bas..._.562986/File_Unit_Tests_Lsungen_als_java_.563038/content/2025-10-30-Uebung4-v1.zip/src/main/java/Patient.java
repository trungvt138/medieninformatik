/**
 * Ein 'record' ist eine kompakte Klasse zur Speicherung von Daten.
 * Es erstellt automatisch einen Konstruktor, Getter (name()), equals(),
 * hashCode() und toString().
 */
record Patient(String name) {
}