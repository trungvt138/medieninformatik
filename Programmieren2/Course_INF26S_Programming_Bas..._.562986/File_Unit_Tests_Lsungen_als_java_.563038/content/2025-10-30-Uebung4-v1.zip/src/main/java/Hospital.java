import java.util.LinkedList;
import java.util.List;

class Hospital {
    // 'final' bedeutet, dass die Kapazität nach der Erstellung
    // des Hospitals nicht mehr geändert werden kann.
    private final int numberOfBeds;

    // Die Kern-Datenstruktur.
    // Eine 'LinkedList' wird hier wie eine 'Queue' (Warteschlange) verwendet.
    // Neue Patienten kommen ans Ende (addLast).
    // Der nächste Patient zur Heilung wird vom Anfang genommen (removeFirst).
    // Dieses Prinzip nennt man FIFO (First-In, First-Out).
    private final LinkedList<Patient> patients = new LinkedList<>();

    // Konstruktor: Setzt die maximale Bettenanzahl.
    Hospital(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    /**
     * Fügt einen Patienten zur Warteschlange hinzu.
     * Gibt 'true' zurück, wenn erfolgreich, sonst 'false'.
     */
    boolean add(Patient patient) {
        // Dies ist eine "Guard Clause" (Wächter-Klausel).
        // Sie prüft alle ungültigen Zustände auf einmal.
        // 1. 'patient == null': Wir fügen keine 'null'-Patienten hinzu (Edge-Case).
        // 2. 'noBedsAvailable()': Wir fügen niemanden hinzu, wenn voll (Business-Rule).
        // 3. 'contains(patient)': Wir fügen denselben Patienten nicht doppelt hinzu (Business-Rule).
        if (patient == null || noBedsAvailable() || contains(patient)) {
            return false;
        }

        // 'addLast' fügt den Patienten ans *Ende* der Liste/Warteschlange.
        patients.addLast(patient);
        return true;
    }

    /**
     * Prüft, ob ein Patient bereits im Krankenhaus ist.
     */
    boolean contains(Patient patient) {
        // Delegiert an die 'contains'-Methode der LinkedList.
        return patients.contains(patient);
    }

    /**
     * Private Hilfsmethode, um die Kapazität zu prüfen.
     */
    private boolean noBedsAvailable() {
        return patientCount() >= numberOfBeds;
    }

    /**
     * Gibt die aktuelle Anzahl der Patienten zurück.
     */
    int patientCount() {
        return patients.size();
    }

    /**
     * Heilt den nächsten Patienten und entfernt ihn aus dem Krankenhaus.
     * "Nächster" bedeutet hier: der Patient, der am längsten wartet (FIFO).
     */
    Patient healNextPatient() {
        // Prüft, ob überhaupt Patienten da sind.
        if (hasPatients()) {
            // 'removeFirst()' entfernt den Patienten am *Anfang* der Liste
            // (den, der als erstes hinzugefügt wurde) und gibt ihn zurück.
            return patients.removeFirst();
        }

        // Wenn 'hasPatients()' false ist, wird eine Exception geworfen.
        // Das wird im Test "givenEmptyHospital_whenHealNextPatient_thenReturnException" geprüft.
        throw new HospitalException("No patients available.");
    }

    /**
     * Hilfsmethode, die prüft, ob Patienten vorhanden sind.
     */
    boolean hasPatients() {
        // 'isEmpty()' ist 'true', wenn die Liste leer ist.
        // Wir wollen 'true', wenn Patienten da sind, also kehren wir es um (!).
        return !patients.isEmpty();
    }

    /**
     * (Bonus-Methode)
     * Gibt eine Liste der Patienten zurück, die am längsten im Krankenhaus sind.
     * @param max Die maximale Anzahl der zurückzugebenden Patienten.
     */
    List<Patient> longtermPatients(int max) {
        // .stream(): Wandelt die LinkedList in einen Stream um.
        // WICHTIG: Der Stream behält die Reihenfolge der LinkedList bei.
        // Da wir eine FIFO-Queue nutzen (addLast, removeFirst),
        // sind die Patienten am *Anfang* der Liste die, die am längsten warten.

        // .limit(max): Schneidet den Stream nach 'max' Elementen ab.
        // Es nimmt die *ersten* 'max' Elemente, was genau unsere
        // "Long-Term-Patienten" sind.

        // .toList(): Sammelt die Elemente im (jetzt verkürzten) Stream
        // und gibt sie als neue Liste zurück.
        return patients.stream().limit(max).toList();
    }
}



