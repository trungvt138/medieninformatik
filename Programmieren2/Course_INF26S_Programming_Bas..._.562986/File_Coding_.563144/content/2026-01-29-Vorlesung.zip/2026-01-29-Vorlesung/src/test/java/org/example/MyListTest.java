package org.example;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.Assert.*;

class MyListTest {



    // Setup: Erstellt eine Instanz von MyList mit Strings.
    // Da MyList generisch ist (<T>), wird hier T zu String.
    // List.of(...) erstellt eine unveränderliche Liste, die unser Konstruktor dann kopiert.
    private final MyList<String> myList = new MyList<>(List.of("Ada", "Grace", "Adele", "Linus"));

    // contains mit Objekt ----------------------------------------------------------------------------------------------

    @Test
    void containsTrue() {
        // Testet den "Happy Path": Das Element ist exakt so in der Liste.
        assertTrue(myList.contains("Grace"));
    }

    @Test
    void containsFalse() {
        // Testet ein nicht vorhandenes Element. "Alan" fehlt in der Liste.
        assertFalse(myList.contains("Alan"));
    }

    @Test
    void containsFalseCaseSensitive() {
        // Testet die Grenzen der Standard-contains-Methode.
        // Da Strings in Java case-sensitive sind, ist "grace" ungleich "Grace".
        // Hier zeigt sich der Bedarf für flexiblere Methoden (siehe nächste Tests).
        assertFalse(myList.contains("grace"));
    }

    // contains mit Lambda ----------------------------------------------------------------------------------------------

    @Test
    void containsLambdaTrue() {
        // Hier übergeben wir Logik statt Daten.
        // Der Lambda-Ausdruck 'element -> element.equals("Grace")' implementiert das Predicate-Interface.
        // Das Verhalten ist identisch zum normalen contains, aber wir definieren es von außen.
        assertTrue(myList.contains(element -> element.equals("Grace")));
    }

    @Test
    void containsLambdaTrueCaseInsensitive() {
        // Der entscheidende Vorteil von Higher-Order Functions:
        // Wir ändern die Vergleichslogik zu 'equalsIgnoreCase', OHNE die MyList-Klasse anpassen zu müssen.
        // Dies entspricht dem Open-Closed-Principle (offen für Erweiterung, geschlossen für Modifikation).
        assertTrue(myList.contains(element -> element.equalsIgnoreCase("grace")));
    }

    @Test
    void containsLambdaFalse() {
        // Auch mit Lambda: Wenn kein Element "alan" (exakt) ist, kommt false zurück.
        assertFalse(myList.contains(element -> element.equals("alan")));
    }

    // contains mit Lambda, aber anderer Typ als String ----------------------------------------------------------

    @Test
    void containsOtherTypeTrue() {
        // Beweis für die Generics: Wir nutzen MyList hier mit Integer statt String.
        // 'var' (Type Inference) spart uns das Schreiben von MyList<Integer>.
        var myIntegerList = new MyList<>(List.of(1, 2, 3));

        // Lambda prüft auf numerische Gleichheit.
        assertTrue(myIntegerList.contains(element -> element.equals(3)));
    }

    @Test
    void containsOtherTypeFalse() {
        var myIntegerList = new MyList<>(List.of(1, 2, 3));
        // 4 ist nicht in der Liste -> false.
        assertFalse(myIntegerList.contains(element -> element.equals(4)));
    }




}