package org.example;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class ListUtilTest {

    @Test
    void linkedListCanBeCreated() {
        assertEquals(List.of("This","will","be","tested","with","JUnit"), ListUtil.createLinkedList());
    }

    // --- GRUPPE 1: Happy Path Tests (Branch A) ---
    // Diese 3 Tests decken den Fall ab, dass .max() etwas findet.
    // Sie sorgen dafür, dass der Code NICHT in orElseThrow springt.

    @Test
    void mostFrequentElementsHaveBeenChosen() {
        // Arrange
        List<Integer> myList = Arrays.asList(4,4,3,2,1);
        // Act
        Integer mostFrequentNumber = ListUtil.getMostFrequentElement(myList);
        // Assert
        assertEquals(4, mostFrequentNumber);
    }

    @Test
    void givenListWhereTheTwoMostFrequentNumbersAppearTwice(){
        // Dieser Test prüft zusätzlich die Logik der TreeMap (Sortierung bei Gleichstand)
        List<Integer> myList = Arrays.asList(4,3,3,2,2,1);
        assertEquals(2, ListUtil.getMostFrequentElement(myList));
    }

    @Test
    void givenListWhereAllNumbersAppearOnce(){
        List<Integer> myList = Arrays.asList(4,3,2,1);
        assertEquals(1, ListUtil.getMostFrequentElement(myList));
    }

    // --- GRUPPE 2: Edge Case / Exception Test (Branch B) ---
    // Er ist zwingend notwendig für 100% Coverage.
    // Er zwingt den Stream dazu, leer zu sein, wodurch .max() leer ist
    // und .orElseThrow() endlich ausgeführt wird.

    @Test
    void givenEmptyListThrowsException() {
        // Arrange: Eine leere Liste (führt zu leerem Stream)
        List<Integer> emptyList = Collections.emptyList();

        // Act & Assert: Wir erwarten, dass der "Else"-Zweig der Stream-Pipeline feuert
        assertThrows(NoSuchElementException.class, () -> {
            ListUtil.getMostFrequentElement(emptyList);
        });
    }
}