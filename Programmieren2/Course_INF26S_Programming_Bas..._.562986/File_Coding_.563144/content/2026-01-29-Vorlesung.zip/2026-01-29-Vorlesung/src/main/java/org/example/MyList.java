package org.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;

class MyList<T> {
    private final List<T> elements;

    public MyList(Collection<T> elements){
        this.elements = new ArrayList<>(elements);
    }

    public boolean contains(T element){
        return elements.contains(element);
    }

    public boolean contains(Predicate<T> criteria){
        for (T element:elements) {
            if (criteria.test(element)) {
                return true;
            }
        }
        return false;
    }
}
