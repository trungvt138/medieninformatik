package org.example;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

final class ListUtil {

    static List<String> createLinkedList() {
        // Line Coverage: Diese Zeile wird einfach ausgeführt. Keine Verzweigungen.
        return new LinkedList<>(List.of("This", "will", "be", "tested", "with", "JUnit"));
    }

    /**
     * Ermittelt das häufigste Element. Bei Gleichstand gewinnt das Kleinere.
     */
    static Integer getMostFrequentElement(List<Integer> integerList) {

        // ACHTUNG: Coverage-Lücke bei NullPointer!
        // Wir haben hier KEIN "if (integerList == null)".
        // Wenn null übergeben wird, stürzt es hier ab.
        // Da es kein 'if' gibt, zählt das Tool dies nicht als fehlende Branch-Coverage.

        // --- Schritt 1: Frequenzen zählen ---
        Map<Integer, Long> elementToFrequency = integerList.stream()
                .collect(Collectors.groupingBy(
                        Function.identity(),
                        Collectors.counting()
                ));

        // --- Schritt 2: Das häufigste Element finden ---
        return new TreeMap<>(elementToFrequency) // TreeMap sortiert Keys aufsteigend (löst das "lowest one"-Problem)
                .entrySet().stream()
                .max(Map.Entry.comparingByValue()) // Gibt ein Optional<Entry> zurück

                // --- HIER ENTSCHEIDET SICH DIE 100% COVERAGE ---

                // Branch A (Happy Path): Das Optional ist gefüllt.
                // Wird durch deine Listen [4,4,3...] abgedeckt.
                .map(Map.Entry::getKey)

                // Branch B (Der "versteckte" Zweig): Das Optional ist leer.
                // Das passiert NUR, wenn die Eingangsliste leer war.
                // Ohne einen Test mit leerer Liste wird diese Zeile NIE ausgeführt.
                // Ergebnis: Keine 100% Line Coverage & keine 100% Branch Coverage.
                .orElseThrow(() -> new NoSuchElementException("Provided List was empty!"));
    }
}