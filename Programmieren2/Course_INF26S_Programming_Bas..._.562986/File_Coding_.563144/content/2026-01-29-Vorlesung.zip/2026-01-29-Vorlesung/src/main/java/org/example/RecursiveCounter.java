package org.example;

@FunctionalInterface
public interface RecursiveCounter {
    // Signatur angepasst: Wir brauchen Text UND das gesuchte Zeichen
    int countRecursively(String text, char searchChar);
}
