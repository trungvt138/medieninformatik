package org.example;



final class MyRecursiveCounter implements RecursiveCounter {

    /**
     * <h6>--- ENGLISH ---</h6>
     * Counts recursively how often a specific character appears in a string.
     *
     * <ul>
     * <li>The implementation must be recursive.</li>
     * <li>You are not allowed to use loops such as {@code for}, {@code while}, {@code forEach}, or {@code map}.
     * However, you may use methods from the JDK that internally use loops.</li>
     * <li>The comparison is case-sensitive (e.g., 'a' is not equal to 'A').</li>
     * <li>Optional: Use the helper method {@link MyRecursiveCounter#countHelper(String, char, int)}.</li>
     * </ul>
     *
     * <b>Bonus Task:</b>
     * Extend the recursion to ignore case sensitivity.
     * <pre>countRecursively("Otto", 'o'); // 2</pre>
     * Tip: {@link Character#toLowerCase(char)} converts a character to lower case.
     *
     * <h6>--- DEUTSCH ---</h6>
     * Zählt rekursiv, wie oft ein bestimmtes Zeichen in einem String vorkommt.
     *
     * <ul>
     * <li>Die Implementierung muss mit Rekursion gelöst werden.</li>
     * <li>Du darfst keine Schleifen wie {@code for}, {@code while}, {@code forEach} oder {@code map} verwenden.
     * Es ist jedoch erlaubt, Methoden aus dem JDK zu verwenden, die intern Schleifen nutzen.</li>
     * <li>Der Vergleich beachtet Groß-/Kleinschreibung (z. B. ist 'a' ungleich 'A').</li>
     * <li>Optional: Verwende die Hilfsmethode {@link MyRecursiveCounter#countHelper(String, char, int)}.</li>
     * </ul>
     *
     * <b>Zusatzaufgabe:</b>
     * Erweitere die Rekursion, sodass Groß-/Kleinschreibung ignoriert wird.
     * <pre>countRecursively("Otto", 'o'); // 2</pre>
     * Tipp: {@link Character#toLowerCase(char)} wandelt einen Buchstaben in Kleinbuchstaben um.
     *
     * @param text       The text to be searched. | Der Text, der durchsucht wird.
     * @param searchChar The character to count. | Das Zeichen, das gezählt werden soll.
     * @return The number of occurrences of {@code searchChar} in {@code text}. | Die Anzahl der Vorkommen von {@code searchChar} in {@code text}.
     */

    @Override
    public int countRecursively(String text, char searchChar) {
        return countHelper(text, searchChar, 0);
    }

    // Helper method | Hilfsmethode
    // Diese Methode erledigt die eigentliche Arbeit mit dem Index
    private int countHelper(String text, char searchChar, int index) {
        if (index == text.length()){
            return 0;
        }

        char charInText = Character.toLowerCase(text.charAt(index));
        char charToSearch = Character.toLowerCase(searchChar);

        int match = 0;
        if (charInText == charToSearch){
            match = 1;
        }

        int restResult = countHelper(text, searchChar, index + 1);

        return match + restResult;

    }


    // Example | Beispiel
    static void main(String[] args) {
        RecursiveCounter check = new MyRecursiveCounter();


        // Sucht nach 't' in Otto
        System.out.println("t in Otto: " + check.countRecursively("Otto", 't'));
        // Sucht nach 'n' in anna
        System.out.println("n in anna: " + check.countRecursively("anna", 'n'));
        // Sucht nach 'e' in lagerregal
        System.out.println("e in lagerregal: " + check.countRecursively("lagerregal", 'e'));
        // Sucht nach '1' in 121
        System.out.println("1 in 121: " + check.countRecursively("121", '1'));
        // Leerer String
        System.out.println("x in (leer): " + check.countRecursively("", 'x'));
        // Sucht nach 'a' in a
        System.out.println("a in a: " + check.countRecursively("a", 'a'));


        System.out.println("Zusatzaufgabe:");
        System.out.println("o in Otto: " + check.countRecursively("Otto", 'o'));

    }


}