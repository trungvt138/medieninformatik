package UnitTests;

import java.util.Arrays;

/**
 * Aufgabe 02-A:
 * Schreibe einen Unit Test mit 100 % Testabdeckung für folgende Klasse.
 * Denk an die Edge-Cases!
 *
 * Viel Erfolg :)
 **/

public class ArrayCleaner {
    private int[] arr;

    public ArrayCleaner() {
        this.arr = new int[]{1,1,2,3,5,8,13,21,34,55};
    }

    public int getFromIdx(int idx) {
        if (idx >= arr.length) {
            idx = getArraySize() - 1;
        }
        return arr[idx];
    }

    public int getArraySize(){
        return arr.length;
    }

    public void clean(){
        arr = Arrays.stream(arr)
                .distinct()
                .filter(elem -> elem < 10)
                .toArray();
    }

    public int[] getArray(){
        return arr;
    }
}
