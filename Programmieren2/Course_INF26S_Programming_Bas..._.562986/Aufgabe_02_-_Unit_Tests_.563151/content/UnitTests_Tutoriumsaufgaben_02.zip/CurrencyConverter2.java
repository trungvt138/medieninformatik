package UnitTests;

import java.util.HashMap;
import java.util.Map;

/**
 * Aufgabe 02-B:
 * Schreibe einen Unit Test mit 100 % Testabdeckung für folgende App. Teste auch mögliche Edge-Cases.
 * (Hier wurde nur die Klasse aus der Übung etwas simplifiziert.
 * An den Tests ändert sich kaum etwas.)
 *
 * Viel Erfolg :)
 **/

class CurrencyConverter2 {
    private record CurrencyPair(Currency from, Currency to) {
        public static CurrencyPair of(Currency from, Currency to) {
            return new CurrencyPair(from, to);
        }
    }
    private final Map<CurrencyPair, Double> conversions = new HashMap<>();

    public CurrencyConverter2() {
        initConversionRates();
    }
    private void initConversionRates() {
        conversions.put(CurrencyPair.of(Currency.EURO, Currency.DOLLAR), 1.06304);
        conversions.put(CurrencyPair.of(Currency.DOLLAR, Currency.EURO), 0.94056);
    }

    double convert(Money fromMoney, Currency toCurrency) {
        return convert(fromMoney.currency(), toCurrency, fromMoney.value());
    }
    double convert(Currency fromCurrency, Currency toCurrency, double amount) {
        if (amount < 0) {
            throw new ArithmeticException("Negative amount cannot be converted.");
        }
        return amount * getConversionRate(fromCurrency, toCurrency);
    }

    double getConversionRate(Currency fromCurrency, Currency toCurrency) {
        var currencyPair = CurrencyPair.of(fromCurrency, toCurrency);
        var currencyPairExists = conversions.containsKey(currencyPair);
        if (!currencyPairExists) {
            throw new IllegalArgumentException(currencyPair.toString());
        }
        return conversions.get(currencyPair);
    }
}

//------------------------------------------------------------------//

enum Currency {
    EURO, DOLLAR, INVALID
}

record Money(double value, Currency currency) {
}