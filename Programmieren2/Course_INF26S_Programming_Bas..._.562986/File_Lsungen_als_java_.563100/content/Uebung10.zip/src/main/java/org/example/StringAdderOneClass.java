package org.example;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class StringAdderOneClass {

    private static final int TEN_TIMES = 10;

    static List<String> compute() throws InterruptedException {
        // var sharedList = new LinkedList<String>();  Does not work!
        var sharedList = Collections.synchronizedList(new LinkedList<String>());

        // Verwendung einer einzigen Klasse 'StringAdder' statt 'AAdder' und 'BAdder'.
        // Der String ("a" oder "b") wird als Parameter übergeben, um Code-Duplizierung zu vermeiden.
        var aThread = new Thread(new StringAdder(sharedList, "a", TEN_TIMES));
        var bThread = new Thread(new StringAdder(sharedList, "b", TEN_TIMES));

        aThread.start();
        bThread.start();

        aThread.join();
        bThread.join();

        return sharedList;
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println(compute());
    }
}