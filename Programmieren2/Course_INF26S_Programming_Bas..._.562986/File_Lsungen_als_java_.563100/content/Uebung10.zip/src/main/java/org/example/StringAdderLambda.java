package org.example;

import java.time.Duration;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class StringAdderLambda {
    static List<String> compute(int limit) throws InterruptedException {
        // var sharedList = new LinkedList<String>(); // works with synchronized block later, but better here:
        var sharedList = Collections.synchronizedList(new LinkedList<String>());

        // Erzeugt Threads direkt mit einer Helper-Methode, die ein Runnable (Lambda) zurückgibt.
        var aThread = new Thread(stringAdder(sharedList, "a", limit));
        var bThread = new Thread(stringAdder(sharedList, "b", limit));

        aThread.start();
        bThread.start();

        aThread.join();
        bThread.join();

        return sharedList;
    }

    // Erzeugt ein Runnable mittels Lambda-Ausdruck.
    private static Runnable stringAdder(Collection<String> sharedList, String string, int limit) {
        return () -> {
            for (int i = 0; i < limit; i++) {
                // Zugriff auf die Variable 'sharedList' aus dem äußeren Scope (Closure).
                // Bad Smell: Der Parameter 'sharedList' wird hier modifiziert (Seiteneffekt).
                sharedList.add(string);
                ThreadUtil.sleep(Duration.ofMillis(10));
            }
        };
    }
}