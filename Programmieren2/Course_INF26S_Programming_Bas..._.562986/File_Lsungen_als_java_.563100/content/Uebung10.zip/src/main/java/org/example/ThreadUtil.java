package org.example;

import java.time.Duration;

final class ThreadUtil { // Hilfsklasse, um Thread-Operationen zu kapseln
    public static void sleep(Duration duration) { // Die Methode nutzt java.time.Duration als Parameter anstatt Millisekunden direkt
        try {
            Thread.sleep(duration.toMillis()); // Intern wird Thread.sleep verwendet; Duration muss in Millisekunden (long) konvertiert werden
        } catch (InterruptedException e) { // Die Checked Exception wird hier abgefangen, damit der aufrufende Code sie nicht behandeln muss
            throw new RuntimeException(e); // Die InterruptedException wird in eine Unchecked Exception (RuntimeException) umgewandelt
        }
    }

    public static void main(String[] args) throws InterruptedException {
        ThreadUtil.sleep(Duration.ofSeconds(1)); // Beispielaufruf: Es ist kein try-catch Block mehr erforderlich
    }
}