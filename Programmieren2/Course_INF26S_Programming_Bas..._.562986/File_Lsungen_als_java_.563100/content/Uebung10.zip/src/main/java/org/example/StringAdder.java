package org.example;

import java.time.Duration;
import java.util.Collection;

// Diese Klasse ersetzt AAdder und BAdder durch eine generische Implementierung.
class StringAdder implements Runnable {
    private final Collection<String> strings; // Referenz auf die geteilte Liste (mutable shared list)
    private final String string;              // Das einzufügende Element ("a" oder "b")
    private final int limit;

    StringAdder(Collection<String> strings, String string, int limit) {
        this.strings = strings;
        this.string = string;
        this.limit = limit;
    }

    @Override
    public void run() {
        for (int i = 0; i < limit; i++) {
            // Hier könnte alternativ 'synchronized(strings)' stehen, wenn die Liste selbst nicht thread-safe wäre.
            // Bad Smell: Parameter werden modifiziert.
            strings.add(string);
            ThreadUtil.sleep(Duration.ofMillis(10));
        }
    }
}