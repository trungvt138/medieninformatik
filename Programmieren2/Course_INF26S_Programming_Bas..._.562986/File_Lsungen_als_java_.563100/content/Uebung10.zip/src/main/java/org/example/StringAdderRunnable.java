package org.example;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class StringAdderRunnable {
    static List<String> compute(int limit) throws InterruptedException {
        // var sharedList = new LinkedList<String>(); // Funktioniert nicht! Normale LinkedList ist nicht thread-safe.

        // Lösung: Verwendung einer synchronisierten Liste, um gleichzeitige Zugriffe zu managen.
        var sharedList = Collections.synchronizedList(new LinkedList<String>());

        // Erzeugen der Threads mit den spezifischen Runnable-Implementierungen (A und B).
        // Beide erhalten Referenzen auf dieselbe Liste (shared mutable state).
        var aThread = new Thread(new AAdder(sharedList, limit));
        var bThread = new Thread(new BAdder(sharedList, limit));

        // Starten der Threads, damit sie parallel arbeiten.
        aThread.start();
        bThread.start();

        // Warten, bis beide Threads ihre Arbeit beendet haben (Synchronisation des Haupt-Threads).
        // Ohne join() würde die Methode eine leere oder unvollständige Liste zurückgeben.
        aThread.join();
        bThread.join();

        return sharedList;
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println(compute(10));
    }
}