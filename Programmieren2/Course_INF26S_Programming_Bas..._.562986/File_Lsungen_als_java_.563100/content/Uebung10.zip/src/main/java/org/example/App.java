package org.example;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

final class App {
    private static final int NUMBER_OF_DRONES = 100;

    public static void main(String[] args) throws InterruptedException {
        // Verwendung von Virtual Threads (Project Loom), um effizient 100 parallele Threads zu verwalten.
        // Der try-with-resources Block stellt sicher, dass der Executor am Ende geschlossen wird.
        try (ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor()) {
            ChargingStation centralOne = new ChargingStation(); // Dies ist die geteilte Ressource (Shared Object)

            for (int id = 1; id <= NUMBER_OF_DRONES; id++) {
                // Startet 100 Drohnen-Tasks, die alle auf dieselbe Ladestation zugreifen.
                executor.submit(new Drone(id, centralOne));
            }
            // Wartet quasi unendlich, damit die Simulation weiterläuft.
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.SECONDS);
        }
    }
}