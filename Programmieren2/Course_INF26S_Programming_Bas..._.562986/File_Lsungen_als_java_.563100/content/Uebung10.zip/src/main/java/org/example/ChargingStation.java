package org.example;

class ChargingStation {
    // Dies ist der "Shared Mutable State". Ohne Synchronisation können hier Inkonsistenzen auftreten.
    private int numberOfLandedDrones = 0;

    // Liest den Status.
    boolean isOccupied() {
        return numberOfLandedDrones != 0;
    }

    // Ändert den Status (Schreibzugriff).
    void land() {
        numberOfLandedDrones++;
        checkNumberOfLandedDrones(); // Überprüft Invarianten (darf max 1 sein).
    }

    // Ändert den Status (Schreibzugriff).
    void takeOff() {
        numberOfLandedDrones--;
        checkNumberOfLandedDrones();
    }

    // Validierungsmethode, die bei Race Conditions (z.B. 2 Drohnen landen gleichzeitig) das Programm beendet.
    private void checkNumberOfLandedDrones() {
        if (numberOfLandedDrones < 0 || numberOfLandedDrones > 1) {
            System.err.printf("numberOfLandedDrones must be between 0 and 1 but was %d%n", numberOfLandedDrones);
            System.exit(404);
        }
    }

}