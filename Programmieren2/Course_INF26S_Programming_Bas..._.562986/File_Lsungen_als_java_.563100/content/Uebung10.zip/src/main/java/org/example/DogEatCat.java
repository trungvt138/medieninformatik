package org.example;

import java.time.Duration;

class DogEatCat {
    private static final int ONE_SECOND = 1000; // Konstante ist im Lösungscode vorhanden, wird aber hier zugunsten von Duration nicht direkt genutzt

    public static void main(String[] args) {
        // Aufgabe: Starte drei separate Threads, die jeweils ihr spezifisches Wort ausgeben
        new Thread(() -> println("Dog")).start(); // Thread 1: Gibt "Dog " aus
        new Thread(() -> println("Eat")).start(); // Thread 2: Gibt "Eat " aus
        new Thread(() -> println("Cat")).start(); // Thread 3: Gibt "Cat " aus
    }

    private static void println(String message) {
        while (true) { // Aufgabe verlangt Ausgabe "für immer" (Endlosschleife)
            System.out.print(message);
            System.out.print(" "); // Fügt das Leerzeichen hinzu, wie in der Aufgabe ("Dog ", "Eat ", "Cat ") gefordert

            // Aufgabe: Warte "jede Sekunde". Nutzt die Hilfsmethode aus der vorigen Aufgabe,
            // um die Checked Exception zu umgehen.
            ThreadUtil.sleep(Duration.ofSeconds(1));

            // Hinweis aus der Lösung: Die Java-Konsole (System.out) ist thread-safe.
            // Es ist kein manuelles Synchronisieren nötig, auch wenn alle Threads gleichzeitig schreiben.
        }
    }
}