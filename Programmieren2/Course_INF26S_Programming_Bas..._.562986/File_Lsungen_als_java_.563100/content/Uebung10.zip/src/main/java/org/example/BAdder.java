package org.example;

import java.time.Duration;
import java.util.Collection;

class BAdder implements Runnable {
    private final int limit;
    private final Collection<String> strings;

    public BAdder(Collection<String> strings, int limit) {
        this.strings = strings;
        this.limit = limit;
    }

    @Override
    public void run() {
        for (int i = 0; i < limit; i++) {
            strings.add("b"); // Fügt "b" statt "a" hinzu.
            ThreadUtil.sleep(Duration.ofMillis(10));
        }
    }
}