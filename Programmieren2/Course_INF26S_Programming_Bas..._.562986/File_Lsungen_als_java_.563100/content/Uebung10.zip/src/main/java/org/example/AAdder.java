package org.example;

import java.time.Duration;
import java.util.Collection;

class AAdder implements Runnable {
    private final int limit;
    private final Collection<String> strings;

    public AAdder(Collection<String> strings, int limit) {
        this.strings = strings;
        this.limit = limit;
    }

    @Override
    public void run() {
        // Schleife läuft 'limit' mal durch.
        for (int i = 0; i < limit; i++) {
            // Fügt "a" zur geteilten Liste hinzu. Dies ist ein schreibender Zugriff auf geteilten Speicher.
            strings.add("a");
            // Künstliche Verzögerung um 10ms, wie in der Aufgabe gefordert.
            ThreadUtil.sleep(Duration.ofMillis(10));
        }
        // Problem: run() ist void, kann also kein Ergebnis zurückgeben. Das Ergebnis liegt in der geteilten Liste (Seiteneffekt).
    }
}