package org.example;

class Drone implements Runnable {
    private final int id;
    private final ChargingStation chargingStation; // Referenz auf das geteilte Monitor-Objekt
    private int battery = 100;

    Drone(int id, ChargingStation chargingStation) {
        this.id = id;
        this.chargingStation = chargingStation;
    }

    void fly() {
        battery -= 10;
        if (battery <= 10) {
            emergencyLand();
        } else if (battery <= 30) {
            tryLand();
        }
    }

    // WICHTIGSTE METHODE DER LÖSUNG:
    void tryLand() {
        // Hier wird das ChargingStation-Objekt als Monitor-Lock verwendet.
        // Das verhindert, dass mehrere Drohnen gleichzeitig den "Check-Then-Act"-Block betreten.
        synchronized (chargingStation) {
            // Kritischer Abschnitt beginnt hier.
            // Atomare Operation: Prüfen (isOccupied) UND Handeln (land) müssen zusammenhängend passieren.
            if (!chargingStation.isOccupied()) {
                chargingStation.land(); // Sicher, da wir den Lock halten.
                recharge();             // Aufladen passiert, während die Station blockiert ist.
                chargingStation.takeOff(); // Freigabe der logischen Ressource.
            }
        } // Lock wird hier freigegeben.
    }

    private void emergencyLand() {
        battery = 0;
    }

    void recharge() {
        battery = 100;
    }

    @Override
    public void run() {
        while (battery > 0) {
            fly();
        }
    }

    @Override
    public String toString() {
        return "%s (%d)".formatted(id, battery);
    }
}