package org.example;

import java.util.ArrayList;
import java.util.List;

class SynchronizedArrayList2<T> {
    // Hier wird die normale, nicht thread-sichere ArrayList verwendet.
    // Der Schutz muss manuell im Code erfolgen.
    private final List<T> elements = new ArrayList<>();

    public boolean add(T element) {
        // Lösungsvariante 2: Kritischen Abschnitt manuell schützen.
        // Wir verwenden das 'elements'-Objekt als Monitor (Mutex).
        // Nur ein Thread kann gleichzeitig diesen Block betreten, was Race Conditions beim Schreiben verhindert.
        synchronized (elements) {
            return elements.add(element);
        }
    }

    // Das 'synchronized' im Methodenkopf sperrt 'this', während der innere Block 'elements' sperrt.
    // Wichtig ist vor allem der Block synchronzied(elements), damit er zum Lock in der add-Methode passt.
    public synchronized int size() {
        // Auch lesende Zugriffe müssen synchronisiert werden (auf dasselbe Objekt wie beim Schreiben),
        // um sicherzustellen, dass man nicht die Größe liest, während ein anderer Thread gerade schreibt (Visibility).
        synchronized (elements) {
            return elements.size();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        var list = new SynchronizedArrayList2<Integer>();

        // Testszenario: Paralleles Schreiben in die Liste durch zwei Threads.
        var t1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) list.add(i);
        });
        var t2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) list.add(i);
        });

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        // Ausgabe des Ergebnisses. Erwartet wird 2000.
        // Dies bestätigt, dass der 'synchronized(elements)'-Block Race Conditions verhindert hat.
        System.out.println("Final Size: " + list.size());
    }
}