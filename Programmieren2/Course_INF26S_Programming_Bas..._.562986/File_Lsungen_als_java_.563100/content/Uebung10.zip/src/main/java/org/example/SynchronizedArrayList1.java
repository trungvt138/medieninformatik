package org.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class SynchronizedArrayList1<T> {
    // Lösungsvariante 1: Verwendung der Java-eigenen Wrapper-Methode.
    // Collections.synchronizedList gibt eine thread-sichere Sicht auf die Liste zurück.
    // Alle Methodenaufrufe auf 'elements' sind nun intern synchronisiert.
    private final List<T> elements = Collections.synchronizedList(new ArrayList<>());

    public boolean add(T element) {
        // Kein explizites 'synchronized' nötig, da die Liste 'elements' das intern regelt.
        return elements.add(element);
    }

    public int size() {
        // Auch hier ist keine manuelle Synchronisation erforderlich.
        return elements.size();
    }

    public static void main(String[] args) throws InterruptedException {
        var list = new SynchronizedArrayList1<Integer>();

        // Wir starten zwei Threads, die parallel jeweils 1000 Elemente hinzufügen.
        var t1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) list.add(i);
        });
        var t2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) list.add(i);
        });

        t1.start();
        t2.start();

        t1.join(); // Warten auf Thread 1
        t2.join(); // Warten auf Thread 2

        // Wenn die Liste thread-safe ist, muss die Größe exakt 2000 betragen.
        // Ohne Synchronisation wäre der Wert wahrscheinlich kleiner (Race Condition).
        System.out.println("Final Size: " + list.size());
    }
}