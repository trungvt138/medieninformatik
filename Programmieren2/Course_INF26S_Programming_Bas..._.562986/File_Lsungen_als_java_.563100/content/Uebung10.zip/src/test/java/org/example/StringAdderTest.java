package org.example;

import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class StringAdderTest {

    // Konstante für die Anzahl der Wiederholungen pro Thread
    private static final int TEN_TIMES = 10;

    /**
     * Testet die erste Variante mit separaten Klassen (AAdder, BAdder).
     */
    @Test
    void testComputeRunnableVariant() throws InterruptedException {
        var expected = generateExpectedList(TEN_TIMES);
        var actual = StringAdderRunnable.compute(TEN_TIMES);

        assertEqualsIgnoreOrder(expected, actual);
    }

    /**
     * Testet die DRY-Variante (StringAdderOneClass).
     * Hinweis: StringAdderOneClass hat '10' fest eincodiert, daher nutzen wir hier TEN_TIMES.
     */
    @Test
    void testComputeOneClassVariant() throws InterruptedException {
        var expected = generateExpectedList(TEN_TIMES);

        // Diese Methode nimmt keine Argumente, da sie intern '10' verwendet.
        var actual = StringAdderOneClass.compute();

        assertEqualsIgnoreOrder(expected, actual);
    }

    /**
     * Testet die Lambda-Variante.
     */
    @Test
    void testComputeLambdaVariant() throws InterruptedException {
        var expected = generateExpectedList(TEN_TIMES);
        var actual = StringAdderLambda.compute(TEN_TIMES);

        assertEqualsIgnoreOrder(expected, actual);
    }

    // Hilfsmethode zum Erzeugen der erwarteten Liste (10x "a", 10x "b")
    private List<String> generateExpectedList(int count) {
        return Stream.of(
                Stream.generate(() -> "a").limit(count),
                Stream.generate(() -> "b").limit(count)
        ).flatMap(e -> e).toList();
    }

    // Da Threads nicht deterministisch laufen, ist die Reihenfolge zufällig.
    // Wir sortieren beide Listen, um den Inhalt (Anzahl und Art der Elemente) zu vergleichen.
    private static <T extends Comparable<T>> void assertEqualsIgnoreOrder(Collection<T> expected, Collection<T> actual) {
        assertEquals(sorted(expected), sorted(actual), "Die Listen enthalten nicht die gleichen Elemente.");
    }

    // Sortiert eine Collection und gibt sie als Liste zurück.
    private static <T extends Comparable<T>> List<T> sorted(Collection<T> collection) {
        return collection.stream().sorted().toList();
    }
}