package org.example.joke;

class JokeJsonJacksonParser implements JokeJsonParser {

    @Override
    public Joke parse(String json) {
        return null; // TODO
    }
}