package org.example.solution;

import java.util.HashMap;
import java.util.Map;

// Implementierung der Aufgabe "JokeFetcher: StringParser": Parsen von JSON nur mit String-Methoden.
class JokeJsonStringParser implements JokeJsonParser {

    @Override
    public Joke parse(String json) {
        // Schritt 1: Extrahiere alle Attribute als Map (Key-Value)
        var attributes = parseKeyValues(json);

        // Schritt 2: Erstelle das Joke-Objekt aus der Map.
        // Da die Struktur laut Aufgabe als fix angenommen werden darf, greifen wir direkt auf die Keys zu.
        return new Joke(
                Integer.parseInt(attributes.get("id")),
                attributes.get("type"),
                attributes.get("setup"),
                attributes.get("punchline")
        );
    }

    private static Map<String, String> parseKeyValues(String json) {
        Map<String, String> result = new HashMap<>(); // key, value
        // Bereinigung des JSON-Strings von Klammern und Anführungszeichen, um das Splitten zu vereinfachen
        var cleanedJson = removeUnnecessaryCharacters(json);

        // Zerlegen des Strings am Komma, um einzelne Paare (z.B. type:programming) zu erhalten
        var keyValuePairs = cleanedJson.split(",");

        for (String pair : keyValuePairs) {
            // Trennen von Key und Value am Doppelpunkt
            var keyValue = pair.split(":");
            // Speichern in der Map für den einfachen Zugriff im parse-Schritt
            result.put(keyValue[0], keyValue[1]);
        }
        return result;
    }

    private static String removeUnnecessaryCharacters(String json) {
        // Entfernt Syntax-Zeichen, die beim manuellen Splitten stören würden
        return json
                .replace("\"", "")
                .replace("{", "")
                .replace("}", "");
    }
}