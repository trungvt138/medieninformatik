package org.example.solution;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

class JokeFetcher {

    private static final String JOKE_API_URL = "https://official-joke-api.appspot.com/jokes/random";

    private final HttpClient httpClient;
    private final JokeJsonParser jokeJsonParser;

    // Dependency Injection für Parser und HttpClient (wichtig für Testbarkeit/Mocking laut Aufgabe)
    JokeFetcher(JokeJsonParser jokeJsonParser, HttpClient httpClient) {
        this.jokeJsonParser = jokeJsonParser;
        this.httpClient = httpClient;
    }

    Collection<Joke> fetchRandomJokes(int limit) {
        // Validierung: Limit muss positiv sein
        if (limit < 0) {
            throw new IllegalArgumentException("Limit must be a positive integer");
        }
        // Startet 'limit' Anfragen parallel und sammelt die Futures (nicht blockierend)
        List<CompletableFuture<Joke>> jokeResponses = sendRandomJokeRequests(limit);

        // Wartet auf alle Ergebnisse und gibt sie als Collection zurück
        return joinAll(jokeResponses);
    }

    private List<CompletableFuture<Joke>> sendRandomJokeRequests(int limit) {
        // Erzeugt einen Stream von 0 bis limit
        return IntStream
                .range(0, limit)
                // Startet für jeden Index einen asynchronen Request.
                // Wichtig: mapToObj erzeugt eine Liste von laufenden Futures, wartet aber nicht auf das Ergebnis.
                .mapToObj(_ -> sendAsyncRandomJokeRequestWith(httpClient))
                .toList();

        // Alternative Implementierung ohne Streams (wie im Lösungskommentar angedeutet):
        // List<CompletableFuture<Joke>> result = new ArrayList<>();
        // for (int i = 0; i < limit; i++) {
        //     CompletableFuture<Joke> jokeCompletableFuture = sendAsyncRandomJokeRequestWith(httpClient);
        //     result.add(jokeCompletableFuture);
        // }
        // return result;
    }

    private CompletableFuture<Joke> sendAsyncRandomJokeRequestWith(HttpClient client) {
        // Kern der Nebenläufigkeit: sendAsync sendet den Request, ohne den Thread zu blockieren.
        return client.sendAsync(request(JOKE_API_URL), HttpResponse.BodyHandlers.ofString())
                // Verarbeitet die Antwort, sobald sie verfügbar ist (Chaining)
                .thenApply(HttpResponse::body)
                // Parst den JSON-String in ein Joke-Objekt (nutzt die injizierte Parser-Strategie)
                .thenApply(jokeJsonParser::parse);
    }

    private static HttpRequest request(String url) {
        // Baut den HTTP-Request mit einem Timeout
        return HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .build();
    }

    private static <T> List<T> joinAll(List<CompletableFuture<T>> futures) {
        // Wandelt die Liste von Futures in eine Liste von Ergebnissen um.
        return futures.stream()
                // .join() wartet blockierend auf das Ergebnis jedes Futures.
                // Da dies erst am Ende passiert (nachdem alle Requests gestartet wurden), laufen die Requests parallel.
                .map(CompletableFuture::join)
                .toList();
    }

    public static void main(String[] args) {
        Instant start = Instant.now();
        try (var client = HttpClient.newHttpClient()) {
            var jokeFetcher = new JokeFetcher(new JokeJsonStringParser(), client);
            // Ruft 5 Witze parallel ab und gibt sie aus
            jokeFetcher.fetchRandomJokes(5).forEach(System.out::println);
        }
        Instant end = Instant.now();
        // Zeitmessung, um die Parallelität zu verifizieren (sollte deutlich schneller als 5x Roundtrip sein)
        System.out.println(Duration.between(start, end).toMillis() + " ms");
    }


}