package org.example;

import java.time.Duration;
import java.time.Instant;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

class ConcurrentCurrencyConverter {
    private static final Random RANDOM = new Random();

    // Simuliert einen API-Call für den Wechselkurs (vorgegeben)
    // Die Methode blockiert den Thread für eine zufällige Zeit zwischen 0.5 und 2.5 Sekunden.
    private static double getExchangeRate(String currency) {
        try {
            int millis = RANDOM.nextInt(2000) + 500;
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Simulierte Wechselkurse
        return switch (currency) {
            case "USD" -> 1.08;
            case "GBP" -> 0.85;
            case "JPY" -> 158.0;
            default -> throw new IllegalArgumentException("Unbekannte Währung");
        };
    }

    public static void convertAmount(double euroAmount) {
        // Startzeitpunkt festhalten, um später die Dauer für jeden einzelnen Task und die Gesamtzeit zu berechnen.
        Instant start = Instant.now();

        // Startet die asynchrone Berechnung für jede Währung.
        // Durch den Aufruf der Hilfsmethode werden hier drei parallele Tasks erzeugt, die nicht aufeinander warten.
        CompletableFuture<Void> usdFuture = newCompletableFuture(euroAmount, "USD", start);
        CompletableFuture<Void> gbpFuture = newCompletableFuture(euroAmount, "GBP", start);
        CompletableFuture<Void> jpyFuture = newCompletableFuture(euroAmount, "JPY", start);

        // Wichtig für die Aufgabe: Wir müssen warten, bis ALLE Umrechnungen fertig sind, bevor das Programm endet.
        // allOf kombiniert die drei Futures. join() blockiert den Main-Thread, bis alle Teilergebnisse da sind.
        CompletableFuture.allOf(usdFuture, gbpFuture, jpyFuture).join();

        // Berechnung und Ausgabe der Gesamtzeit erst NACHDEM alle parallelen Tasks abgeschlossen sind.
        Duration totalTime = Duration.between(start, Instant.now());
        System.out.printf("Alle Umrechnungen abgeschlossen (%.1f s)", totalTime.toMillis() / 1000.0);
    }

    // Hilfsmethode zur Erstellung der Pipeline für eine Währung
    private static CompletableFuture<Void> newCompletableFuture(double euroAmount, String targetCurrency, Instant start) {
        // supplyAsync: Führt getExchangeRate in einem separaten Thread (ForkJoinPool) aus -> Ermöglicht Parallelität.
        // thenAccept: Definiert, was passiert, sobald das Ergebnis (rate) verfügbar ist.
        // Erfüllt die Anforderung: "Gib jedes Ergebnis... aus, sobald es verfügbar ist".
        return CompletableFuture.supplyAsync(() -> getExchangeRate(targetCurrency))
                .thenAccept(rate -> printConversion(euroAmount, rate, targetCurrency, start));
    }

    private static void printConversion(double euroAmount, double exchangeRate, String targetCurrency, Instant start) {
        double convertedAmount = euroAmount * exchangeRate;
        // Berechnet die Zeitdifferenz vom Start bis genau zu dem Moment, wo DIESE Konvertierung fertig ist.
        Duration duration = Duration.between(start, Instant.now());
        // Ausgabeformat gemäß Aufgabenstellung: Währung, Betrag, Ergebnis und Zeitdauer.
        System.out.printf("%s: %.2f EUR = %.2f %s (%.1f s)%n", targetCurrency, euroAmount, convertedAmount, targetCurrency, duration.toMillis() / 1000.0);
    }

    static void main(String[] args) {
        convertAmount(42);
    }
}