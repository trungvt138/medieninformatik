package org.example;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.stream.Stream;

class ParallelStreamExample {
    public static void main(String[] args) {
        // 1. Erstelle eine Liste mit den vorgegebenen Namen (Paul, Vladimir, Jessica, Duncan, Chani, Leto)
        List<String> names = List.of("Paul", "Vladimir", "Jessica", "Duncan", "Chani", "Leto");

        // Startzeit für die serielle Ausführung erfassen (Teil der Aufgabe zur Laufzeitmessung)
        Instant start = Instant.now();

        // 1. Variante: Serieller Stream (Standardverhalten ohne .parallel())
        // Führt Filterung und Umwandlung nacheinander im Main-Thread aus.
        List<String> resultSerial = newTransformStream(names).toList();

        Instant end = Instant.now();
        // Ausgabe der Ergebnisse und der berechneten Dauer für die serielle Variante
        printResults("Serial: ", resultSerial, start, end);

        // Reset der Startzeit für den zweiten Durchlauf
        start = Instant.now();

        // 2. Variante: Paralleler Stream
        // Durch Aufruf von .parallel() wird der Stream auf mehrere Threads verteilt.
        // Dies verkürzt die Gesamtlaufzeit erheblich, da die "Schlafenszeiten" gleichzeitig ablaufen.
        List<String> resultParallel = newTransformStream(names).parallel().toList();

        /*
            Mit der Intermediate-Methode parallel() kann man einen vorhandenen seriellen Stream in einen parallelen Stream umwandeln.
            Beachte: Die Methode newTransformStream gibt immer einen neuen Stream zurück, weil ein und derselbe Stream nicht wiederverwendet werden kann.
            Sobald die terminale Methode toList() aufgerufen wird, ist der Stream nicht mehr verwendbar.
        */

        end = Instant.now();
        // Ausgabe der Ergebnisse und der Dauer für die parallele Variante (erwartet: ca. 100ms + Overhead)
        printResults("Parallel: ", resultParallel, start, end);
    }

    // Lagert die Stream-Logik aus, um DRY (Don't Repeat Yourself) zu wahren, da die Logik für seriell und parallel identisch ist.
    private static Stream<String> newTransformStream(List<String> names) {
        return names.stream()
                // Schritt 1: Nur Namen bearbeiten, deren Länge >= 5 ist
                .filter(name -> name.length() >= 5)
                // Schritt 2 & 3: Umwandlung in Großbuchstaben UND Warten vor der Umwandlung
                .map(name -> {
                    // Schritt 3: Schlafe vor jeder Umwandlung für 100 ms (simuliert teure Rechenoperation)
                    sleep(Duration.ofMillis(100));
                    // Schritt 2: Wandle Namen in Großbuchstaben um
                    return name.toUpperCase();
                });
    }

    private static void sleep(Duration duration) {
        try {
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void printResults(String method, List<String> result, Instant start, Instant end) {
        // Schritt 4: Ausgabe aller umgewandelten Namen
        System.out.println(method + result);
        // Schritt 5: Berechnung und Ausgabe der Laufzeit in Millisekunden
        System.out.println("Duration: " + Duration.between(start, end).toMillis() + " ms");
    }
}