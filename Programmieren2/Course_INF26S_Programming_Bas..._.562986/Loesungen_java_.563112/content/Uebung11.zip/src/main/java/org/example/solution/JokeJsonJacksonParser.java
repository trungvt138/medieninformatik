package org.example.solution;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

// Implementierung der Aufgabe "JokeFetcher: JacksonParser": Parsen mit externer Bibliothek.
class JokeJsonJacksonParser implements JokeJsonParser {

    @Override
    public Joke parse(String json) {
        try {
            // Nutzung von Jackson's ObjectMapper: Mapping erfolgt automatisch auf die Felder der Joke-Klasse.
            // Dies ersetzt die manuelle String-Manipulation aus der vorherigen Aufgabe.
            return new ObjectMapper().readValue(json, Joke.class);
        } catch (JsonProcessingException e) {
            // Exception-Handling, falls das JSON nicht dem erwarteten Format entspricht
            throw new RuntimeException(e);
        }
    }
}