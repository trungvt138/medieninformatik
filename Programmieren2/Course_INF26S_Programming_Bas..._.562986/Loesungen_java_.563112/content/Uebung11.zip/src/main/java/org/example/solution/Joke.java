package org.example.solution;

record Joke(int id, String type, String setup, String punchline) {}