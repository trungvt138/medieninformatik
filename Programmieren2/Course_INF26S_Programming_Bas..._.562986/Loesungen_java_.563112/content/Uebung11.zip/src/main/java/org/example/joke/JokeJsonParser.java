package org.example.joke;

interface JokeJsonParser {

    Joke parse(String json);
}