package org.example;

import java.util.Collection;
import java.util.List;

class Reduce {
    static int reduceSerial(int startValue, Collection<Integer> numbers) {
        // Serielle Ausführung: Der Startwert (10) wird initial gesetzt und dann werden die Zahlen aufaddiert.
        // Berechnungsweg: 10 (Start) + 10 + 20 + 30 + 40 = 110.
        return numbers.stream().reduce(startValue, (a, b) -> a + b);
        // return numbers.stream().reduce(startValue, Integer::sum);
    }

    static int reduceParallel(int startValue, Collection<Integer> numbers) {
        // Parallel-Stream: Hier wirkt der startValue als "Identity" (neutrales Element) für jeden Split/Thread.
        // Problem: 10 ist mathematisch nicht das neutrale Element der Addition (das wäre 0).
        // Deshalb wird die 10 in jedem parallelen Teilschritt erneut hinzuaddiert.
        // Berechnung: (10+10) + (10+20) + (10+30) + (10+40) = 140.
        return numbers.parallelStream().reduce(startValue, (a, b) -> a + b);
        // return numbers.stream().reduce(startValue, Integer::sum);
    }

    public static void main(String[] args) {
        // Aufgabenstellung: Berechne 10 + Summe aus [10, 20, 30, 40]
        var numbers = List.of(10, 20, 30, 40);

        // Gibt das erwartete Ergebnis 110 aus.
        System.out.println(reduceSerial(10, numbers)); // 110

        // Zeigt den Seiteneffekt bei falscher Wahl der Identity im Parallel-Betrieb: Ergebnis ist 140.
        System.out.println(reduceParallel(10, numbers)); // 140
    }
}