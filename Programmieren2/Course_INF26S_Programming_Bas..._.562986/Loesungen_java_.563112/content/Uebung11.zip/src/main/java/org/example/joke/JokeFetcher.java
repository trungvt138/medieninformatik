package org.example.joke;

import java.net.http.HttpClient;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.LinkedList;
import java.util.concurrent.CompletableFuture;

class JokeFetcher {

    private static final String JOKE_API_URL = "https://official-joke-api.appspot.com/jokes/random";

    private final HttpClient httpClient;
    private final JokeJsonParser jokeJsonParser;

    JokeFetcher(JokeJsonParser jokeJsonParser, HttpClient httpClient) {
        this.jokeJsonParser = jokeJsonParser;
        this.httpClient = httpClient;
    }

    /**
     * Requests a certain number of random jokes from a joke API.
     * All requests are made <b>asynchronous (in parallel)</b>.
     * The jokes are parsed from JSON to {@link Joke}.
     *
     * @param limit a positive number of jokes to be fetched.
     * @return a collection with fetched and parsed {@link Joke} objects.
     * @throws IllegalArgumentException if limit is below zero.
     * @see HttpClient#sendAsync
     * @see CompletableFuture
     */
    Collection<Joke> fetchRandomJokes(int limit) {
        return new LinkedList<>(); // TODO
    }


    public static void main(String[] args) {
        Instant start = Instant.now();
        try (var client = HttpClient.newHttpClient()) {
            var jokeFetcher = new JokeFetcher(new JokeJsonStringParser(), client);
            jokeFetcher.fetchRandomJokes(5).forEach(System.out::println);
        }
        Instant end = Instant.now();
        System.out.println(Duration.between(start, end).toMillis() + " ms");
    }
}