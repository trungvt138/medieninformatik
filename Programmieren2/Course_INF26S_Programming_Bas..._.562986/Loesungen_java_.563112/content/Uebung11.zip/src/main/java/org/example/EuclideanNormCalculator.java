package org.example;

import java.time.Duration;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

class EuclideanNormCalculator {
    public static void main(String[] args) {
        // Erstellt ein CompletableFuture, um die Berechnung asynchron in einem separaten Thread zu starten
        CompletableFuture<Double> euclideanNormCalculation = CompletableFuture.supplyAsync(() -> {
            // Simuliert eine lange Berechnungsdauer: Das Ergebnis soll erst nach 2 Sekunden verfügbar sein
            sleep(Duration.ofSeconds(2));
            // Die gegebene Collection mit den Beispielwerten [1, 2, 3, 4, 5.5]
            Collection<Number> numbers = List.of(1, 2, 3, 4, 5.5);
            // Führt die eigentliche Berechnung der euklidischen Norm durch
            return euclideanNorm(numbers);
        });

        // Überprüft kontinuierlich, ob das Future fertig ist, um währenddessen Statusausgaben zu machen
        while (!euclideanNormCalculation.isDone()) {
            // Gibt alle 100 ms einen Punkt "." auf der Konsole aus, solange gerechnet wird
            System.out.println(".");
            sleep(Duration.ofMillis(100));
        }

        // Wartet auf das Endergebnis des Futures und holt den Wert (join blockiert, bis fertig)
        double result = euclideanNormCalculation.join();
        // Gibt das finale Ergebnis auf der Konsole aus
        System.out.println(result);
    }

    private static void sleep(Duration duration) {
        try {
            // Hilfsmethode für Thread.sleep, um Checked Exceptions zu behandeln
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static double euclideanNorm(Collection<Number> numbers) {
        // Berechnung: Summe der Quadrate aller Zahlen (x*x) mittels Stream API
        double sum = numbers.stream().mapToDouble(number -> number.doubleValue() * number.doubleValue()).sum();
        // Zieht die Wurzel aus der Summe (Math-Bibliothek), um die euklidische Norm zu erhalten
        return Math.sqrt(sum);
    }
}