package org.example.joke;

class JokeJsonStringParser implements JokeJsonParser {

    @Override
    public Joke parse(String json) throws RuntimeException {
        return null; // TODO
    }
}