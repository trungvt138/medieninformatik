package org.example.solution;

interface JokeJsonParser {

    Joke parse(String json);
}