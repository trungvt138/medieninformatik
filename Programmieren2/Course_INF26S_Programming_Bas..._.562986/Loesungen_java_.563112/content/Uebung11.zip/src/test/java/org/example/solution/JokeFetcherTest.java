package org.example.solution;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class JokeFetcherTest {

    private static final int STATUS_CODE_SUCCESS = 200;

    @Mock
    private HttpClient mockClient;

    private JokeFetcher jokeFetcher;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        jokeFetcher = new JokeFetcher(testInternalJokeJsonParser(), mockClient);
    }

    @Test
    void fetchRealRandomJokes() {
        int limit = 2;

        try (var client = HttpClient.newBuilder().build()) {
            var realJokeFetcher = new JokeFetcher(testInternalJokeJsonParser(), client);
            Collection<Joke> actual = realJokeFetcher.fetchRandomJokes(limit);
            assertEquals(actual.size(), limit);
        }
    }

    @Test
    void fetchNegativeLimit() {
        assertThrows(IllegalArgumentException.class, () -> jokeFetcher.fetchRandomJokes(-1));
    }

    @Test
    void fetchRandomJokesSuccess1() {
        // Arrange
        String json = """
            {\
            "type":"general",\
            "setup":"Why did the scarecrow win an award?",\
            "punchline":"Because he was outstanding in his field.",\
            "id":1\
            }\
            """;
        setupMockResponse(json, STATUS_CODE_SUCCESS);

        // Act
        Collection<Joke> actual = jokeFetcher.fetchRandomJokes(1);

        // Assert
        assertHasExactlyOneJoke(actual);
        var joke = actual.iterator().next();
        assertEquals(1, joke.id());
        assertEquals("general", joke.type());
        assertEquals("Why did the scarecrow win an award?", joke.setup());
        assertEquals("Because he was outstanding in his field.", joke.punchline());
    }

    @Test
    void fetchRandomJokesSuccess2() {
        // Arrange
        String json = """
            {\
            "type":"programming",\
            "setup":"I was gonna tell you a joke about UDP...",\
            "punchline":"...but you might not get it.",\
            "id":72\
            }\
            """;
        setupMockResponse(json, STATUS_CODE_SUCCESS);

        // Act
        Collection<Joke> actual = jokeFetcher.fetchRandomJokes(1);

        // Assert
        assertHasExactlyOneJoke(actual);
        var joke = actual.iterator().next();
        assertEquals(72, joke.id());
        assertEquals("programming", joke.type());
        assertEquals("I was gonna tell you a joke about UDP...", joke.setup());
        assertEquals("...but you might not get it.", joke.punchline());
    }

    @Test
    void checkIfRequestsAreAsync() {
        // Arrange
        String json = """
            {\
            "type":"programming",\
            "setup":"A SQL query walks into a bar, walks up to two tables and asks...",\
            "punchline":"'Can I join you?'",\
            "id":24\
            }\
            """;
        setupMockResponse(json, STATUS_CODE_SUCCESS, Duration.ofMillis(100));

        // Act
        Instant start = Instant.now();
        final int expectedNumberOfJokes = 10;
        Collection<Joke> actualJokes = jokeFetcher.fetchRandomJokes(expectedNumberOfJokes);
        Instant end = Instant.now();
        Duration actualElapsedTime = Duration.between(start, end);

        // Assert
        assertEquals(expectedNumberOfJokes, actualJokes.size());
        assertTrue(actualElapsedTime.toMillis() < Duration.ofSeconds(1).toMillis(),
            "The execution time should be well below one second if the requests were made in parallel, but it was: " + actualElapsedTime.toMillis() + " ms");
    }

    private static void assertHasExactlyOneJoke(Collection<Joke> actual) {
        assertEquals(1, actual.size(), "Expect one joke, but got " + actual.size());
    }

    private void setupMockResponse(String json, int statusCode) {
        setupMockResponse(json, statusCode, Duration.ZERO);
    }

    private void setupMockResponse(String jsonResponse, int statusCode, Duration duration) {
        when(mockClient.sendAsync(any(HttpRequest.class), any(HttpResponse.BodyHandler.class)))
            .thenAnswer(invocation -> {
                HttpRequest request = invocation.getArgument(0);
                URI uri = request.uri();
                final String expectedApiUrl = "https://official-joke-api.appspot.com/jokes/random";
                assertEquals(expectedApiUrl, uri.toString());

                return CompletableFuture.supplyAsync(() -> {
                    HttpResponse<String> mockResponse = mock(HttpResponse.class);
                    when(mockResponse.statusCode()).thenReturn(statusCode);
                    when(mockResponse.body()).thenReturn(jsonResponse);
                    sleep(duration); // emulate a specific time
                    return mockResponse;
                });
            });
    }

    private static void sleep(Duration duration) {
        if (duration.isZero()) {
            return;
        }
        try {
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static JokeJsonParser testInternalJokeJsonParser() {
        return json -> {
            try {
                return new ObjectMapper().readValue(json, Joke.class);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        };
    }
}