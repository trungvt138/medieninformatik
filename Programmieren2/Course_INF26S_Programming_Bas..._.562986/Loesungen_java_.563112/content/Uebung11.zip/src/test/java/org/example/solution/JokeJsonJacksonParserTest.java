package org.example.solution;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class JokeJsonJacksonParserTest {

    @Test
    void parseValidJson() {
        String json = """ 
            {\
            "type":"general",\
            "setup":"Why did the scarecrow win an award?",\
            "punchline":"Because he was outstanding in his field.",\
            "id":1\
            }\
            """;
        JokeJsonParser parser = new JokeJsonJacksonParser();

        Joke joke = parser.parse(json);

        assertEquals(1, joke.id());
        assertEquals("general", joke.type());
        assertEquals("Why did the scarecrow win an award?", joke.setup());
        assertEquals("Because he was outstanding in his field.", joke.punchline());
    }
}