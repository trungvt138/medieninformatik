package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class PlaystoreTestOhneMockito {

    // 1. Dies ist der "Manuelle Mock" (Test Double).
    // Es ist eine private, innere Klasse, die das PlaystoreDatabase-Interface implementiert.
    // Ihr Zweck ist es, eine *vorhersehbare, gefälschte* Datenbank für unsere Tests bereitzustellen.
    private static class PlaystoreDatabaseMock implements PlaystoreDatabase {
        @Override
        public List<PlaystoreGame> findGamesByName(String name) throws IOException {
            var games = new ArrayList<>(List.of(
                    new PlaystoreGame("Dead Space", 4),
                    new PlaystoreGame("Baldurs Gate 3", 5),
                    new PlaystoreGame("Space Invaders", 2),
                    new PlaystoreGame("Jagged Alliance 3", 5),
                    new PlaystoreGame("Aliens: Dark Descent", 4),
                    new PlaystoreGame("Disco Elysium", 5)
            ));
            return games.stream()
                    .filter(game -> game.name().toLowerCase().contains(name.toLowerCase()))
                    .toList();
        }
    }

    // Die "System Under Test" (SUT) – die Klasse, die wir tatsächlich testen wollen.
    private Playstore playstore;

    // 2. Die @BeforeEach-Methode (Setup)
    // Diese Methode wird *vor jedem einzelnen @Test* ausgeführt.
    // Sie stellt sicher, dass jeder Test mit einer "sauberen", neuen Instanz von Playstore beginnt.
    @BeforeEach
    void setup() {
        // Hier passiert die *Dependency Injection*:
        // Wir erstellen eine neue Playstore-Instanz und übergeben ihr
        // unseren manuellen Mock (PlaystoreDatabaseMock) anstelle einer echten Datenbank.
        playstore = new Playstore(new PlaystoreDatabaseMock());
    }

    // 3. "Happy Path"-Tests (Keine, ein oder mehrere Ergebnisse)
    // Diese Tests überprüfen das erwartete Verhalten, wenn alles normal funktioniert.
    @Test
    void findNoGames() {
        // Testet, ob eine Suche, die nichts findet, korrekt eine leere Liste zurückgibt.
        var actual = playstore.searchGame("no game");
        assertEquals(List.of(), actual); // JUnit-Assertion
        assertThat(playstore.searchGame("no game")).isEmpty(); // Google Truth-Assertion
    }

    @Test
    void findOneGame() {
        // Testet, ob eine Suche, die genau ein Ergebnis hat, dieses korrekt zurückgibt.
        var expected = new ArrayList<>(List.of(
                new PlaystoreGame("Aliens: Dark Descent", 4)
        ));
        var actual = playstore.searchGame("Alien");
        assertEquals(expected, actual);
    }

    @Test
    void findMultipleGames() {
        // Testet, ob eine Suche, die mehrere Ergebnisse hat, diese korrekt zurückgibt.
        var expected = new ArrayList<>(List.of(
                new PlaystoreGame("Dead Space", 4),
                new PlaystoreGame("Space Invaders", 2)
        ));
        var actual = playstore.searchGame("space");
        assertEquals(expected, actual);
    }

    // 4. Testen der Fehlerbehandlung (Exception Handling)
    // Dies ist ein sehr wichtiger Test. Er prüft, wie die Playstore-Klasse
    // auf einen Fehler (IOException) von der Datenbank-Schicht reagiert.
    @Test
    void findGamesThrowsIOException() {
        // Arrange: Erzeuge einen *neuen, speziellen Mock* nur für diesen Test.
        // Wir verwenden hier eine "anonyme innere Klasse", um einen Mock zu erstellen,
        // der *sofort* eine IOException wirft, wenn er aufgerufen wird.
        var database = new PlaystoreDatabase() {
            @Override
            public List<PlaystoreGame> findGamesByName(String name) throws IOException {
                throw new IOException("No games found");
            }
        };
        // Injiziere diesen "Fehler-Mock" in eine neue Playstore-Instanz.
        playstore = new Playstore(database);

        // Act: Rufe die Methode auf.
        var actual = playstore.searchGame("anything");

        // Assert: Überprüfe, ob die Playstore-Klasse die Exception (wie in ihrer
        // Implementierung definiert) abgefangen und eine leere Liste zurückgegeben hat.
        assertEquals(List.of(), actual);
    }

    // 5. Testen der Eingabevalidierung (Robustheit)
    @Test
    void findNullThrowsException() {
        // Überprüft, ob die Übergabe von 'null' zu einer NullPointerException führt.
        // 'assertThrows' ist die JUnit 5-Methode, um zu bestätigen, dass eine
        // bestimmte Exception durch den Lambda-Ausdruck ausgelöst wird.
        assertThrows(NullPointerException.class, () -> playstore.searchGame(null));
    }
}