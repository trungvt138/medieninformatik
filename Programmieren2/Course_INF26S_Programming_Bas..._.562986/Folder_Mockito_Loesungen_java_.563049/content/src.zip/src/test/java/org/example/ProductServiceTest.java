package org.example;

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ProductServiceTest {
    @Test // Markiert diese Methode als JUnit-Testfall.
    void getProductDetails() {

        // Aufgabe 1: Erstelle ein Mock-Objekt von ProductService.
        // (Hinweis: Der modernere Stil wäre: mock(ProductService.class))
        ProductService productServiceMock = mock();

        // Aufgabe 2.2: Simuliere das Verhalten für "alle anderen IDs".
        // WENN die Methode 'getProductDetails' auf dem Mock mit *irgendeinem String* (anyString()) aufgerufen wird...
        // ...DANN gib "Product not found." zurück.
        // Dies dient als allgemeine "Fallback"-Regel.
        when(productServiceMock.getProductDetails(anyString())).thenReturn("Product not found.");

        // Aufgabe 2.1: Simuliere das Verhalten für die ID "123".
        // WENN die Methode 'getProductDetails' mit *exakt dem String "123"* aufgerufen wird...
        // ...DANN gib "Product found." zurück.
        // WICHTIG: Mockito priorisiert spezifische Matcher (wie "123")
        // über allgemeinen Matchern (wie anyString()).
        when(productServiceMock.getProductDetails("123")).thenReturn("Product found.");

        // Aufgabe 3 (Testfall 1): Rufe die Methode mit der spezifischen ID "123" auf.
        String found = productServiceMock.getProductDetails("123");

        // Überprüfung: Wir erwarten "Product found.", da die spezifische Regel (für "123") greifen muss.
        //assertThat(found).isEqualTo(); //Google Truth
        assertEquals("Product found.", found); // JUnit 5-Assertion

        // Aufgabe 3 (Testfall 2): Rufe die Methode mit einer anderen ID ("00000") auf.
        String notFound = productServiceMock.getProductDetails("00000");

        // Überprüfung: "00000" passt nicht zur spezifischen Regel ("123"),
        // daher muss die allgemeine 'anyString()'-Regel greifen.
        //assertThat(notFound).isEqualTo("Product not found."); //Google Truth
        assertEquals("Product not found.", notFound); // JUnit 5-Assertion
    }
}