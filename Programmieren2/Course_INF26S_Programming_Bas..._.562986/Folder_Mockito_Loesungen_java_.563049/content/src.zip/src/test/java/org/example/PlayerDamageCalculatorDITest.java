package org.example;

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class PlayerDamageCalculatorDITest {
    @Test
        // (Der Name 'calculateAreaOfSquare' ist irreführend, der Test testet 'randomDamage')
    void calculateAreaOfSquare() {

        // Arrange (Vorbereiten)

        // Das ist der entscheidende Teil:
        // Da RandomGenerator ein @FunctionalInterface ist, können wir ein Lambda verwenden,
        // um eine "On-the-fly"-Implementierung (einen Stub/Mock) zu erstellen.
        //
        // '_ -> 1' bedeutet:
        // Erstelle eine Implementierung von RandomGenerator.
        // Ignoriere die Eingabe (der Unterstrich '_' steht für das 'max'-Argument).
        // Gib *immer* (konstant) den Wert 1 zurück.
        //
        // Dieses Lambda (unser Test-Stub) wird dann in den Konstruktor
        // von PlayerDamageCalculatorDI "injiziert".
        PlayerDamageCalculatorDI playerDamageCalculatorDI = new PlayerDamageCalculatorDI(_ -> 1);

        // Act (Ausführen)
        // Wir rufen die Methode auf dem Rechner auf.
        // Dieser ruft intern 'randomGenerator.randomNumber(max)' auf.
        // Dank DI ist 'randomGenerator' unser Lambda, das '1' zurückgibt.
        int actual = playerDamageCalculatorDI.randomDamage(1_000_000_000); // max-Wert ist egal

        // Assert (Überprüfen)
        // Wir überprüfen, ob das Ergebnis exakt dem Wert entspricht,
        // den unser Lambda-Stub zurückgegeben hat.
        assertEquals(1, actual); // JUnit
        assertThat(actual).isEqualTo(1); // Truth
    }
}