package org.example;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic; // Importiert die Klasse, die benötigt wird, um statische Methoden zu mocken.
import static com.google.common.truth.Truth.assertThat;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mockStatic; // Importiert die statische Factory-Methode 'mockStatic'.
import static org.mockito.Mockito.when;

class PlayerDamageCalculatorTest {

    // Der Testfall (obwohl 'calculateAreaOfSquare' ein irreführender Name ist)
    // testet 'randomDamage'.
    @Test
    void calculateAreaOfSquare() {

        // 1. STATISCHEN MOCK ERSTELLEN
        // Statische Mocks *müssen* in einem try-with-resources-Block deklariert werden.
        // Das stellt sicher, dass der Mock nur innerhalb dieses Blocks aktiv ist
        // und danach automatisch "geschlossen" wird, damit er andere Tests nicht beeinflusst.
        try (MockedStatic<RandomUtil> staticMock = mockStatic(RandomUtil.class)) {

            // 2. ARRANGE (Vorbereitung / Stubbing)
            // Wir definieren das Verhalten des statischen Mocks.
            // WENN 'RandomUtil.randomNumber' mit *irgendeiner Ganzzahl* (anyInt()) aufgerufen wird...
            // ... DANN gib immer den Wert 1 zurück.
            when(RandomUtil.randomNumber(anyInt())).thenReturn(1);

            // (Dies ist die alternative, oft bevorzugte Syntax, um dasselbe zu tun)
            // staticMock.when(() -> RandomUtil.randomNumber(anyInt())).thenReturn(1);

            // Erstellen der Klasse, die wir testen wollen (System Under Test).
            PlayerDamageCalculator playerDamageCalculator = new PlayerDamageCalculator();

            // 3. ACT (Ausführung)
            // Wir rufen die Methode auf dem SUT auf.
            // Intern ruft 'randomDamage' jetzt 'RandomUtil.randomNumber' auf.
            // Mockito fängt diesen statischen Aufruf ab und gibt unsere definierte '1' zurück,
            // anstatt die echte Methode in RandomUtil auszuführen.
            int actual = playerDamageCalculator.randomDamage(1_000_000_000); // Der 'max'-Wert ist egal (wegen anyInt)

            // 4. ASSERT (Überprüfung)
            // Wir prüfen, ob das Ergebnis 'actual' tatsächlich der '1' entspricht,
            // die wir vom Mock erwartet haben.
            assertThat(actual).isEqualTo(1);

        } // Am Ende des try-Blocks wird der statische Mock automatisch deaktiviert.
    }
}