package org.example;

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class UserServiceTest {

    // Aufgabe 1
    @Test
    void storeUserIsCalled() {
        // Erstellt einen Mock (Attrappe) der UserService-Klasse.
        // Dieser Mock hat keine echte Logik, er zeichnet nur auf, was mit ihm gemacht wird.
        UserService userServiceMock = mock(UserService.class);

        // Ruft die 'storeUser'-Methode auf dem Mock auf.
        // Der Mock führt die echte Methode nicht aus, er merkt sich nur:
        // "Die Methode 'storeUser' wurde mit einem User-Objekt aufgerufen".
        userServiceMock.storeUser(new User("Bob"));

        // Überprüft (verify), ob auf dem 'userServiceMock' die Methode 'storeUser'
        // mit irgendeinem (any()) Argument aufgerufen wurde.
        // Der Test schlägt fehl, wenn 'storeUser' nicht aufgerufen worden wäre.
        verify(userServiceMock).storeUser(any());
    }

    // Aufgabe 2
    @Test
    void getUserAndNameOfUserIsCalled() {
        // Erstellt eine ECHTE Instanz von UserService (kein Mock).
        // Wir testen die echte Logik dieser Klasse.
        UserService userService = new UserService();

        // Erstellt einen Mock der User-Klasse.
        // Diesen Mock übergeben wir an den echten Service.
        User userMock = mock(User.class);

        // Die ECHTE 'storeUser'-Methode wird aufgerufen und erhält den MOCK 'userMock'.
        userService.storeUser(userMock);

        // Schritt 1: Überprüfen, ob der User gespeichert wurde (Assertion).
        // Wir prüfen mit 'assertThat', ob die 'getStoredUser'-Methode
        // genau das 'userMock'-Objekt zurückgibt, das wir hineingegeben haben.
        //assertThat(userService.getStoredUser()).isEqualTo(userMock); //Google Truth
        assertEquals(userMock, userService.getStoredUser());

        // Schritt 2: Überprüfen, ob 'name()' aufgerufen wurde (Verification).
        // Wir überprüfen (verify) den 'userMock' (nicht den Service!).
        // Wir wollen wissen: Hat der echte 'userService' (in seiner 'storeUser'-Methode)
        // die 'name()'-Methode auf unserem 'userMock' aufgerufen?
        // (Die echte Implementierung tut dies für System.out.println).
        verify(userMock).name();
    }
}