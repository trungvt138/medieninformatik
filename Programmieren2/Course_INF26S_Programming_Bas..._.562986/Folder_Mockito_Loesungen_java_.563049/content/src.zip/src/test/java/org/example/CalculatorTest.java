package org.example; // Definiert das Paket, zu dem diese Testklasse gehört.

import org.junit.jupiter.api.Test;
import static com.google.common.truth.Truth.assertThat; // Importiert statisch die assertThat-Methode von Google Truth für flüssige Assertions.
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CalculatorTest {
    @Test
    void add() {
        //Calculator calculatorMock = mock(); // Eine alternative (weniger typsichere) Art, einen Mock zu erstellen.
        Calculator calculatorMock = mock(Calculator.class); // Erstellt ein Mock-Objekt (eine Attrappe) basierend auf der Calculator-Klasse.

        when(calculatorMock.add(anyInt(), anyInt())).thenReturn(10);
        // Definiert das Verhalten des Mocks: Wenn die 'add'-Methode mit
        // beliebigen (anyInt) zwei Ganzzahlen aufgerufen wird
        // dann soll sie (thenReturn) den Wert 10 zurückgeben.

        //Lösung aus der PDF mit Google Truth
        //assertThat(calculatorMock.add(4, 6)).isEqualTo(10);

        // Verwendet die Standard-Assertion von JUnit.
        // Die Signatur ist: assertEquals(erwarteterWert, tatsächlicherWert);
        assertEquals(10, calculatorMock.add(4, 6));

        // Führt den eigentlichen Test durch:
        // 1. Ruft calculatorMock.add(4, 6) auf. (Dies passt zu anyInt(), anyInt() und gibt laut Mock-Definition 10 zurück).
        // 2. assertThat(...) nimmt das Ergebnis (10).
        // 3. .isEqualTo(10) überprüft, ob das Ergebnis gleich 10 ist. Der Test ist erfolgreich.
    }
}