package org.example;

import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.Collection;
import java.util.List;
import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*; // Importiert alle statischen Mockito-Methoden (mock, when, verify etc.)

class PlaystoreTest {
    @Test
    void findOneGame() throws IOException { // Muss 'throws IOException' deklarieren, da die Hilfsmethode dies (theoretisch) könnte
        // Arrange
        // Definiert das erwartete Testergebnis
        List<PlaystoreGame> expectedGames = List.of(new PlaystoreGame("Zelda", 10));

        // Verwendet die Hilfsmethode (siehe unten), um einen Mock zu erstellen,
        // der 'expectedGames' zurückgibt, wenn "Zelda" gesucht wird.
        PlaystoreDatabase mockedDatabase = mockedDatabaseWith("Zelda", expectedGames);

        // Erstellt die zu testende Klasse (SUT) und injiziert den Mock.
        Playstore playstore = new Playstore(mockedDatabase);
        // Act
        // Ruft die Methode auf dem SUT auf. Diese ruft intern den Mock auf.
        Collection<PlaystoreGame> actualGames = playstore.searchGame("Zelda");
        // Assert
        // Unnötiges verify, da der Aufruf von findGamesByName indirekt durch searchGame
        // mitgetestet wird.
        // verify prüft, ob eine Methode auf dem Mock aufgerufen wurde (Behavior Verification).
        // Wie im Kommentar steht: Dies ist oft unnötig, wenn man das *Ergebnis* (actualGames)
        // prüft, da das Ergebnis nur korrekt sein kann, wenn der Mock aufgerufen wurde.
        //verify(mockedDatabase).findGamesByName("Zelda"); // unnötig

        // Prüft, ob das tatsächliche Ergebnis dem erwarteten entspricht (State Verification).
        assertEquals(expectedGames, actualGames); // JUnit
        assertThat(actualGames).isEqualTo(expectedGames); // Truth
    }

    @Test
    void findMultipleGames() {
        // Arrange + Beispiel mit Hilfsmethode
        // Definiert das erwartete Ergebnis (eine Liste mit zwei Spielen).
        var expectedGames = List.of(
                new PlaystoreGame("Zelda: Breath of the Wild", 9),
                new PlaystoreGame("Zelda: A Link to a Past", 10));

        // Erstellt das SUT und den konfigurierten Mock in einer Zeile.
        var playstore = new Playstore(mockedDatabaseWith("Zelda", expectedGames));
        // Act
        var actualGames = playstore.searchGame("Zelda");
        // Assert
        // Überprüft, ob die zurückgegebene Liste (actualGames) dem erwarteten Ergebnis entspricht.
        assertEquals(expectedGames, actualGames); // JUnit
        assertThat(actualGames).isEqualTo(expectedGames); // Truth
    }

    @Test
    void returnEmptyCollectionWhenNoGameWasFound() {
        // Arrange + Beispiel mit Hilfsmethode
        // Definiert das erwartete Ergebnis (eine leere Liste).
        List<PlaystoreGame> expectedGames = List.of();

        // Konfiguriert den Mock so, dass er eine leere Liste zurückgibt.
        var playstore = new Playstore(mockedDatabaseWith("Zelda", expectedGames));
        // Act
        var actualGames = playstore.searchGame("Zelda");
        // Assert
        assertEquals(expectedGames, actualGames); // JUnit
        assertThat(actualGames).isEmpty(); // Truth (präzisere Assertion für Leere)
    }

    @Test
    void returnEmptyCollectionWhenExceptionIsThrown() throws IOException {
        // Arrange
        // 1. Erstellt einen "rohen" Mock des Datenbank-Interfaces.
        PlaystoreDatabase mockedDatabase = mock();

        // 2. Definiert das Verhalten des Mocks:
        // WENN 'findGamesByName("Zelda")' aufgerufen wird, DANN WIRF (thenThrow) eine IOException.
        // Dies testet den 'catch'-Block in der 'Playstore.searchGame'-Methode.
        when(mockedDatabase.findGamesByName("Zelda")).thenThrow(new IOException("Should be caught."));

        // 3. Injiziert den "Fehler-Mock" in das SUT.
        var playstore = new Playstore(mockedDatabase);
        // Act
        // Ruft die Methode auf. Das SUT sollte die Exception intern fangen.
        var actualGames = playstore.searchGame("Zelda");
        // Assert
        // Überprüft, ob das SUT (wie im 'catch'-Block definiert) eine leere Liste zurückgibt.
        assertEquals(List.of(), actualGames); // JUnit
        assertThat(actualGames).isEmpty(); // Truth
    }

    /**
     * Helper Method: (Dies ist ein sehr nützliches Muster für saubere Tests)
     * Returns a mocked {@link PlaystoreDatabase} that returns the given list of games when the given name is searched.
     */
    // Diese private Methode ist eine "Factory", die konfigurierte Mocks erstellt.
    // Sie reduziert Codeduplizierung (DRY - Don't Repeat Yourself) in den Tests darüber.
    private static PlaystoreDatabase mockedDatabaseWith(String searchedName, List<PlaystoreGame> gamesToReturn) {
        // Erstellt den Mock.
        PlaystoreDatabase databaseMock = mock();
        try {
            // Definiert das Standardverhalten (Stubbing) für diesen Mock.
            when(databaseMock.findGamesByName(searchedName)).thenReturn(gamesToReturn);
        } catch (IOException e) {
            // Dieser try/catch ist nur wegen der 'throws IOException'-Signatur im Interface nötig.
            // Beim reinen Definieren (when) eines Mocks wird die Exception nie geworfen.
            throw new RuntimeException("Should never happen.");
        }
        // Gibt den fertig konfigurierten Mock zurück.
        return databaseMock;
    }
}