package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertThrows; // Importiert die JUnit 5-Methode, um das Werfen von Exceptions zu überprüfen.
import static org.mockito.AdditionalMatchers.gt; // Importiert den "greater than" (größer als) Matcher für die Bonusaufgabe.
import static org.mockito.ArgumentMatchers.anyString; // Importiert einen Matcher, der auf jeden beliebigen String passt.
import static org.mockito.ArgumentMatchers.eq; // Importiert einen Matcher, der auf einen exakten Wert prüft.
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class PaymentServiceTest {

    // Dieser Test erfüllt die Hauptaufgabe (Exception bei exakt 1001).
    @Test
    void processPaymentThrowsException() {
        // Aufgabe 1: Erstelle ein Mock-Objekt von PaymentService.
        PaymentService paymentServiceMock = mock();
        double forbiddenAmount = 1001; // Der spezifische Wert, der die Ausnahme auslösen soll.

        // Aufgabe 2: Simuliere das Verhalten.
        when(paymentServiceMock.processPayment(
                anyString(), // Wir akzeptieren JEDE String-Eingabe für das erste Argument.
                eq(forbiddenAmount) // Das zweite Argument muss *exakt gleich* (eq) 1001.0 sein.
        )).thenThrow(new PaymentException("Maximum limit is 1000.")); // WENN die Bedingungen zutreffen, wirf diese Exception.

        // Aufgabe 3: Prüfe, ob die Exception geworfen wird.
        // assertThrows überprüft, ob der Code-Block (der Lambda-Ausdruck)...
        // ...die erwartete 'PaymentException.class' wirft.
        assertThrows(PaymentException.class, () -> paymentServiceMock.processPayment("123", forbiddenAmount));
    }

    // Dieser Test erfüllt die Bonusaufgabe (Exception bei > 1000).
    @Test
    void shouldThrowPaymentExceptionForAmountsGreaterThan1000_Bonus() {
        PaymentService paymentServiceMock = mock();

        // Bonusaufgabe: Definiere das Verhalten für Beträge > 1000.
        when(paymentServiceMock.processPayment(
                anyString(), // Akzeptiere jeden String.
                gt(1000.0) // Das zweite Argument muss *größer als* (greater than) 1000.0 sein.
        )).thenThrow(new PaymentException("Maximum limit is 1000."));

        // (Alternative Implementierung, die dasselbe tut)
        // when(paymentServiceMock.processPayment(anyString(), doubleThat(d -> d > 1000))).thenThrow(new PaymentException("Maximum limit is 1000."));

        int forbiddenAmount = 1001; // Ein Beispielwert, der die 'gt(1000.0)'-Bedingung erfüllt.

        // Test: Prüfe, ob die Exception geworfen wird, da 1001 > 1000 ist.
        assertThrows(PaymentException.class, () -> paymentServiceMock.processPayment("123", forbiddenAmount));
    }
}