package org.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify; // Importiert die 'verify'-Methode für die Überprüfung von Aufrufen.

class OrderServiceTest {

    // Dieser Test erfüllt die ERSTE Aufgabe (siehe Kommentare in OrderService).
    // Hier wird das Verhalten des Mock-Objekts selbst getestet (ob es aufgerufen wurde).
    @Test
    void placeOrder() {
        // Erstellt einen Mock des OrderService.
        // Wir testen *nicht* die echte Logik, sondern nur die Interaktion *mit* dem Mock.
        OrderService orderServiceMock = mock();

        // Erstellt das spezifische Objekt, dessen Übergabe wir prüfen wollen.
        var coffee = new Order("Kaffee", 42);

        // Ruft die Methode auf dem Mock auf.
        orderServiceMock.placeOrder(coffee);

        // Überprüft (verify), ob auf dem 'orderServiceMock' die Methode 'placeOrder' ...
        // ... mit *exakt* dem 'coffee'-Objekt aufgerufen wurde.
        verify(orderServiceMock).placeOrder(coffee);
    }

    // Dieser Test erfüllt die ZWEITE Aufgabe (siehe Kommentare in OrderService).
    // Hier wird ein Mock (notificationServiceMock) verwendet, um das korrekte Verhalten
    // einer *echten* Klasse (orderService) zu testen.
    @Test
    void placeOrder2() {
        // Aufgabe 2.1: Erstelle einen Mock der *Abhängigkeit* (NotificationService).
        NotificationService notificationServiceMock = mock();

        // Aufgabe 2.2: Erstelle eine *echte* Instanz von OrderService (kein Mock!).
        // Injiziere (übergebe) den Mock über den Konstruktor.
        OrderService orderService = new OrderService(notificationServiceMock);

        String muffin = "Muffin";

        // Aufgabe 2.3: Rufe die Methode auf dem *echten* OrderService auf.
        orderService.placeOrder2(muffin);

        // Aufgabe 2.3 (Überprüfung):
        // Wir überprüfen (verify) den *Mock* (notificationServiceMock), nicht den orderService.
        // Wir wollen wissen: Hat der echte 'orderService' (in seiner placeOrder2-Logik) ...
        // ... die 'sendNotification'-Methode auf unserem Mock mit der exakt erwarteten Nachricht aufgerufen?
        verify(notificationServiceMock).sendNotification("Order placed for " + muffin);
    }
}