package org.example;

class PaymentService {
    /**
     * Erstelle ein Mock-Objekt von PaymentService.
     * Simuliere, dass die Methode processPayment() eine PaymentException auslöst, wenn der Betrag gleich 1001 ist.
     * Schreibe einen Test, der prüft, ob die Exception korrekt geworfen wird.
     *
     * Bonusaufgabe:
     * Schreibe den Test so um, dass der Mock eine Exception wirft, sobald ein Betrag größer als 1000 übergeben wird.
     * Tipp: Schau in die Dokumentation von Mockito.
     */
    boolean processPayment(String creditCardNumber, double amount) throws PaymentException {
        return true;
    }
}
