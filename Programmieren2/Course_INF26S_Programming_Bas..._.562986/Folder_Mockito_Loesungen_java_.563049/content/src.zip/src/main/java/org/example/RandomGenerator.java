package org.example;

// @FunctionalInterface signalisiert, dass dieses Interface genau eine abstrakte Methode hat.
// Dies ist wichtig, da es uns später erlaubt, die Implementierung
// im Test durch ein einfaches Lambda (_ -> 1) zu ersetzen.
@FunctionalInterface
interface RandomGenerator {
    // Definiert die "Rolle" oder den "Vertrag", den eine Implementierung erfüllen muss.
    // Jede Klasse, die 'RandomGenerator' implementiert, *muss* diese Methode bereitstellen.
    int randomNumber(int max);
}