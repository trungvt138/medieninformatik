package org.example;

record User(String name) {}
