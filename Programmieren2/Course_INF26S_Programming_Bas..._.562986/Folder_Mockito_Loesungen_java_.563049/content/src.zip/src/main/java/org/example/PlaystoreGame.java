package org.example;

record PlaystoreGame(String name, int rating) {
}
