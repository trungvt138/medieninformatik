package org.example;

// Diese Klasse benötigt eine Funktionalität (Zufallszahlen),
// aber sie verlässt sich nicht auf eine *statische* Hilfsklasse.
class PlayerDamageCalculatorDI {

    // 1. Die Abhängigkeit wird als privates Feld deklariert.
    // WICHTIG: Der Typ ist das *Interface* (RandomGenerator),
    // nicht die *Implementierung* (RandomUtilDI).
    private final RandomGenerator randomGenerator;

    // 2. Dependency Injection (DI) über den Konstruktor.
    // Die Klasse erstellt ihre Abhängigkeit nicht selbst (kein 'new RandomUtilDI()'),
    // sondern bekommt sie von außen "injiziert" (übergeben).
    PlayerDamageCalculatorDI(RandomGenerator randomGenerator) {
        this.randomGenerator = randomGenerator;
    }

    // Die Geschäftslogik.
    int randomDamage(int max) {
        // 3. Die Klasse ruft die Methode auf dem *Interface* auf,
        // völlig ahnungslos, ob es sich um die "echte" Implementierung
        // oder einen Test-Mock handelt.
        return randomGenerator.randomNumber(max);
    }
}