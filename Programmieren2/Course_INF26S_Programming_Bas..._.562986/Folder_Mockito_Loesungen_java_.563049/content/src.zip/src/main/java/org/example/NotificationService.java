package org.example;

class NotificationService {
    void sendNotification(String message) {
        System.out.println("Notification sent: " + message);
    }
}