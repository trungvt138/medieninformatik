package org.example;

import java.io.IOException;
import java.util.List;

interface PlaystoreDatabase {
    List<PlaystoreGame> findGamesByName(String name) throws IOException;
}