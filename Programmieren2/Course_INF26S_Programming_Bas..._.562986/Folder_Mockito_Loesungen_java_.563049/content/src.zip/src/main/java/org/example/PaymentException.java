package org.example;

class PaymentException extends RuntimeException {
    PaymentException(String message) {
        super(message);
    }
}
