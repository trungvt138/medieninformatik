package org.example;

import java.util.Random;

// Dies ist die "echte" Implementierung des RandomGenerator-Interfaces,
// die in der fertigen Anwendung (Produktion) verwendet würde.
class RandomUtilDI implements RandomGenerator {

    // Ein fester Seed, um reproduzierbare "zufällige" Zahlen zu erzeugen.
    private static final int SEED = 42;

    // Die Implementierung der vertraglich vereinbarten Methode aus dem Interface.
    @Override // (Das @Override-Tag fehlt, ist aber implizit vorhanden)
    public int randomNumber(int max) {
        // Die "echte" Logik.
        return new Random(SEED).nextInt(max);
    }
}