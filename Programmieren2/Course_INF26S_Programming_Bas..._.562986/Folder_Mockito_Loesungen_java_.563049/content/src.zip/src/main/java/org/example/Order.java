package org.example;

record Order(String product, int quantity) {}
