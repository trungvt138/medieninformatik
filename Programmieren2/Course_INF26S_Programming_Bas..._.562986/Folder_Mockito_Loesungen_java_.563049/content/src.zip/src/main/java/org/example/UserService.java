package org.example;

class UserService {
    private User storedUser;
    /**
     * Erstelle ein Mock-Objekt von UserService.
     * Schreibe einen Test, der prüft, ob die Methode storeUser aufgerufen wurde,
     * egal welche Argumente übergeben werden.
     */
    void storeUser(User user) {
        if (user != null) {
            storedUser = user;
            System.out.println("Stored user " + user.name());
        }
    }
    /**
     * Aufgabe 1: Erstelle ein Mock-Objekt von User und speichere ihn in ein ungemockten UserService.
     * Aufgabe 2: Schreibe einen Test, der prüft, ob der gemockte User im UserService gespeichert wurde und
     * ob die Methode name() von dem gemockten User aufgerufen wurde.
     */
    User getStoredUser() {
        return storedUser;
    }
}