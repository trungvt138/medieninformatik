package org.example;

class Calculator {
    int add(int a, int b) {
        return a + b;
    }
}