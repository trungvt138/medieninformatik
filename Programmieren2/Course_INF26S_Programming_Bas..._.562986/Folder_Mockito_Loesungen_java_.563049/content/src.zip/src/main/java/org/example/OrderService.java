package org.example;

/*
 * (AUFGABE 1)
 * Erstelle ein Mock-Objekt von OrderService.
 * Simuliere einen Test, bei dem eine Bestellung aufgegeben wird.
 * Prüfe, ob der placeOrder mit einem bestimmten Order-Object aufgerufen wurde.
 * (Wird in OrderServiceTest.placeOrder() umgesetzt)
 */

/*
 * (AUFGABE 2)
 * Verwende Mockito, um ein Mock-Objekt von NotificationService zu erstellen.
 * Übergebe dieses Mock-Objekt über den Konstruktor von OrderService (Dependency Injection).
 * Schreibe einen Test, der die Methode placeOrder (gemeint ist placeOrder2) aufruft und überprüft,
 * ob die sendNotification-Methode des NotificationService mit der korrekten Nachricht aufgerufen wurde.
 * (Wird in OrderServiceTest.placeOrder2() umgesetzt)
 */
class OrderService {
    // Definiert eine Abhängigkeit zu einem anderen Dienst (NotificationService).
    private NotificationService notificationService;

    // Konstruktor für "Dependency Injection" (DI).
    // Anstatt dass OrderService seinen eigenen NotificationService erstellt,
    // wird ihm dieser von außen "injiziert" (übergeben).
    // Dies ist entscheidend, um im Test einen Mock übergeben zu können.
    OrderService(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    // Methode für Aufgabe 1.
    void placeOrder(Order order) {
        // Die Logik hier ist für den Test in 'placeOrder()' irrelevant,
        // da dort der OrderService selbst gemockt wird.
    }

    // Methode für Aufgabe 2.
    // Diese Methode *verwendet* die injizierte Abhängigkeit.
    void placeOrder2(String product) {
        System.out.println("Order placed for: " + product);

        // Ruft die Methode auf der Abhängigkeit auf.
        // Im Test 'placeOrder2()' ist 'notificationService' der Mock,
        // dessen Aufruf wir mit verify() überprüfen.
        notificationService.sendNotification("Order placed for " + product);
    }
}