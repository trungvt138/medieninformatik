package org.example;

import java.util.Random;

// Eine Hilfsklasse (Utility-Klasse), die statische Methoden zur Verfügung stellt.
class RandomUtil {
    // Ein fester "Seed" (Startwert) für den Zufallsgenerator.
    // Dies sorgt dafür, dass die "echte" Methode (wenn sie nicht gemockt wird)
    // immer dieselbe "zufällige" Zahlenfolge liefert, was auch Tests erleichtert.
    private static final int SEED = 42;

    /**
     * Gibt eine "zufällige" Zahl zwischen 0 (inklusiv) und max (exklusiv) zurück.
     * @param max Die Obergrenze (exklusiv).
     * @return Eine Ganzzahl.
     */
    static int randomNumber(int max) {
        // Die "echte" Implementierung, die im Test durch einen Mock ersetzt wird.
        return new Random(SEED).nextInt(max);
    }
}