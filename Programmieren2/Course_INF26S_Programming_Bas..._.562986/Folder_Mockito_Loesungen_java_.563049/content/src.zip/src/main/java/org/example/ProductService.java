package org.example;

class ProductService {
    /**
     * Erstelle ein Mock-Objekt von ProductService.
     * Simuliere verschiedene Rückgabewerte für die Methode getProductDetails(String productId):
     * 1. Wenn die Produkt-ID „123“ ist, gebe "Product found." zurück.
     * 2. Für alle anderen IDs gebe "Product not found." zurück.
     * 3. Schreibe entsprechende Testfälle.
     */
    String getProductDetails(String productId) {
        return "ProductDetails";
    }
}
