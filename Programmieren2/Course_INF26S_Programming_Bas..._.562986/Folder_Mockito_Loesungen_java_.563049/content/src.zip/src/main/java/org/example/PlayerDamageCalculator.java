package org.example;

class PlayerDamageCalculator {
    /* Aufgabe 1:
     * Verwende Mockito, um die statische Methode RandomUtil.randomNumber zu mocken.
     * Schreibe einen Test für die Klasse PlayerDamageCalculator, der sicherstellt, dass die statische Methode
     * RandomUtil.randomNumber aufgerufen wird und konstant 1 im Unit Test zurückgibt.
     * (also keine Zufallszahl, da Zufallszahlen ungünstig als Erwartungswerte für Testfälle sind).
     *
     * Hinweis: Nutze mockStatic
     *
     * @param max: the maximum possible random number that may be generated (exclusive).
     * @return a random number between 0 (inclusive) and max (exclusive).
     */

    /* Aufgabe 2:
     * Überlege dir, wie du die Klasse PlayerDamageCalculator ohne Mockito testen kannst.
     * Überarbeite die Klassen PlayerDamageCalculator / RandomUtil entsprechend.
     * Eventuell benötigst du zusätzliche Klassen oder Interfaces? #hint
     * Schreibe einen passenden Unit Test für PlayerDamageCalculator.
     * Die Methode randomNumber soll weiterhin konstant 1 im Unit Test zurückgeben.
     * (also keine Zufallszahl, da Zufallszahlen ungünstig als Erwartungswerte für Testfälle sind).
     *
     * Hinweis: Nutze KEIN mockStatic
     *
     * @param max: the maximum possible random number that may be generated (exclusive).
     * @return a random number between 0 (inclusive) and max (exclusive).
     */
    int randomDamage(int max) {
        return RandomUtil.randomNumber(max);
    }

}
