package refactoring.temperatureConverter_v2;

class TemperatureConverter {

    private static final int TO_FAHRENHEIT = 1;
    private static final int TO_CELSIUS = 2;

    public static float convert(String conversionIdentifier, float temperatureValue) {
        int conversionId = Integer.parseInt(conversionIdentifier);
        return switch (conversionId) {
            case TO_FAHRENHEIT -> convertToFahrenheit(temperatureValue);
            case TO_CELSIUS -> convertToCelsius(temperatureValue);
            default -> temperatureValue;
        };
    }

    private static float convertToFahrenheit(float celsius) {
        return (celsius * (1.8f)) + 32f;
    }

    private static float convertToCelsius(float fahrenheit) {
        return (fahrenheit - 32f) * (5f) / 9f;
    }
}