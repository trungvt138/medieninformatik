package refactoring.temperatureConverter_v2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class TemperatureConverterTest {

    private static final double TOLERANCE = 0.00001;

    private static final String FAHRENHEIT = "1";
    private static final String CELSIUS = "2";

    @Test
    void convertToFahrenheit() {
        var actual = TemperatureConverter.convert(FAHRENHEIT, 0);

        assertEquals(32, actual, TOLERANCE);
    }

    @Test
    void convertToFahrenheitWithNegativeDecimals() {
        var actual = TemperatureConverter.convert(FAHRENHEIT, -0.33f);

        assertEquals(31.406, actual, TOLERANCE);
    }

    @Test
    void convertToCelsius() {
        var actual = TemperatureConverter.convert(CELSIUS, 32);

        assertEquals(0, actual, TOLERANCE);
    }

    @Test
    void convertToCelsiusWithNegativeDecimals() {
        var actual = TemperatureConverter.convert(CELSIUS, -31.01f);

        assertEquals(-35.00556, actual, TOLERANCE);
    }

    @Test
    void convertToUnknownUnit() {
        var actual = TemperatureConverter.convert("3", 42);

        assertEquals(42, actual, TOLERANCE);
    }

    @Test
    void convertWithUnparsableUnit() {
        assertThrows(NumberFormatException.class, () -> TemperatureConverter.convert("a3b", 42));
    }
}