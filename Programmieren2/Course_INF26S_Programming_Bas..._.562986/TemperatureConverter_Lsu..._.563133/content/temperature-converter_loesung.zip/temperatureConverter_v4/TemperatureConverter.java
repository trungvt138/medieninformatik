package refactoring.temperatureConverter_v4;

class TemperatureConverter {

    public static float convertToFahrenheit(float celsius) {
        return (celsius * (1.8f)) + 32f;
    }

    public static float convertToCelsius(float fahrenheit) {
        return (fahrenheit - 32f) * (5f) / 9f;
    }
}