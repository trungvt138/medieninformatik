package refactoring.temperatureConverter_v3;

enum ConversionType {
    TO_FAHRENHEIT, TO_CELSIUS
}