package refactoring.temperatureConverter_v3;

class TemperatureConverter {

    public static float convert(ConversionType conversionType, float temperatureValue) {
        return switch (conversionType) {
            case TO_FAHRENHEIT -> convertToFahrenheit(temperatureValue);
            case TO_CELSIUS -> convertToCelsius(temperatureValue);
        };
    }

    private static float convertToFahrenheit(float celsius) {
        return (celsius * (1.8f)) + 32f;
    }

    private static float convertToCelsius(float fahrenheit) {
        return (fahrenheit - 32f) * (5f) / 9f;
    }
}