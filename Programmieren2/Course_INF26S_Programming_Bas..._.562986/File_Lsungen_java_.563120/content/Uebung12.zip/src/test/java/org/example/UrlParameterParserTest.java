package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Map;

class UrlParameterParserTest {

    @Test
    void testUrlWithMultipleParameters() {
        // Arrange
        // Standardfall: Eine URL mit Parameter-Teil nach dem '?' und Trennung durch '&'
        String url = "http://example.com/page?param1=value1&param2=value2";

        // Act
        Map<String, String> parameters = UrlParameterParser.parse(url);

        // Assert
        // WICHTIG: Prüft, ob beide Parameter korrekt als Key-Value-Paare extrahiert wurden
        assertEquals(2, parameters.size());
        assertEquals("value1", parameters.get("param1"));
        assertEquals("value2", parameters.get("param2"));
        // Hinweis: Es können beliebig viele Parameter sein.
    }

    @Test
    void testUrlWithNoParameters() {
        // Arrange
        // Grenzfall: URL ohne '?' und ohne Parameter
        String url = "http://example.com/page";

        // Act
        Map<String, String> parameters = UrlParameterParser.parse(url);

        // Assert
        // Die Map muss leer sein, da der Regex für den Query-Teil nicht greift
        assertTrue(parameters.isEmpty());
    }

    @Test
    void testUrlWithSpecialCharacters() {
        // Arrange
        // Testet Sonderzeichen wie '%20' (Leerzeichen). Der Parser dekodiert diese nicht explizit,
        // sondern übernimmt sie als String-Literal, solange sie kein '&' oder '=' enthalten.
        String url = "http://example.com/page?p1=special%20value&p2=another%20value";

        // Act
        Map<String, String> parameters = UrlParameterParser.parse(url);

        // Assert
        assertEquals(2, parameters.size());
        assertEquals("special%20value", parameters.get("p1"));
        assertEquals("another%20value", parameters.get("p2"));
    }

    @Test
    void testUrlWithIncompleteParameters() {
        // Arrange
        // WICHTIG: Testet leere Werte (Key vorhanden, aber nichts nach dem '=')
        String url = "http://example.com/page?something=value1&different=";

        // Act
        Map<String, String> parameters = UrlParameterParser.parse(url);

        // Assert
        assertEquals(2, parameters.size());
        assertEquals("value1", parameters.get("something"));
        // Der Regex muss hier einen leeren String matchen, keinen Null-Wert oder Fehler werfen
        assertEquals("", parameters.get("different"));
    }

    @Test
    void testUrlWithInvalidFormat() {
        // Arrange
        // Ungültiges Format: Parameter ohne Wertzuweisung (kein '=')
        String url = "http://example.com/page?param1";

        // Act
        Map<String, String> parameters = UrlParameterParser.parse(url);

        // Assert
        // WICHTIG: Da der Regex zwingend ein '=' erwartet, wird dieser Teil ignoriert
        // und die Map bleibt leer.
        assertTrue(parameters.isEmpty());
    }
}