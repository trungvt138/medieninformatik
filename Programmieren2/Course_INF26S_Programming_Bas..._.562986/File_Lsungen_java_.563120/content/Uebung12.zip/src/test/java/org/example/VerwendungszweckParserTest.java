package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VerwendungszweckParserTest {
    private VerwendungszweckParser parser;

    @BeforeEach
    void setUp() {
        // Initialisierung vor jedem Testlauf
        parser = new VerwendungszweckParser();
    }

    @Test
    void parseValidVerwendungszweckWithSoSe() {
        // Arrange: Gültiger String für Sommersemester (ID 1)
        String input = "202412345678 Musk, Elon";
        // Act: Methode aufrufen
        Verwendungszweck actual = parser.parse(input);
        // Assert: Überprüfen, ob alle Teile korrekt extrahiert wurden
        assertEquals(2024, actual.year());
        assertEquals(Semester.SOSE, actual.semester()); // Prüft Enum-Konvertierung ID 1 -> SOSE
        assertEquals("2345678", actual.matriculationId());
        assertEquals("Elon", actual.firstName());
        assertEquals("Musk", actual.lastName());
    }

    @Test
    void parseValidVerwendungszweckWithWiSe() {
        // Arrange: Gültiger String für Wintersemester (ID 2)
        String input = "202328765432 Theoden, Eowyn";
        // Act
        Verwendungszweck actual = parser.parse(input);
        // Assert: Prüft Enum-Konvertierung ID 2 -> WISE
        assertEquals(2023, actual.year());
        assertEquals(Semester.WISE, actual.semester());
        assertEquals("8765432", actual.matriculationId());
        assertEquals("Eowyn", actual.firstName());
        assertEquals("Theoden", actual.lastName());
    }

    @Test
    void parseValidVerwendungszweckWithSpecialName() {
        // Arrange: Testet Namen mit Leerzeichen/Bindestrichen ("von Lauch")
        // WICHTIG: Das Regex "([^,]+)" akzeptiert Leerzeichen innerhalb des Namens
        String input = "202228765432 von Lauch, Lurch-Ludwig";
        // Act
        Verwendungszweck actual = parser.parse(input);
        // Assert
        assertEquals(2022, actual.year());
        assertEquals(Semester.WISE, actual.semester());
        assertEquals("8765432", actual.matriculationId());
        assertEquals("Lurch-Ludwig", actual.firstName());
        assertEquals("von Lauch", actual.lastName());
    }

    @Test
    void invalidVerwendungszweckIsNull() {
        // WICHTIG: Prüft den Null-Check am Anfang der parse-Methode
        assertThrows(IllegalArgumentException.class, () -> parser.parse(null));
    }

    @Test
    void invalidEmptyVerwendungszweck() {
        // Arrange
        String emptyString = "";
        // Act and Assert: Prüft den Empty-Check
        assertThrows(IllegalArgumentException.class, () -> parser.parse(emptyString));
    }

    @Test
    void invalidName() {
        // Arrange: Formatfehler - Zu viele Kommas oder falsche Trennung ("Breitner, Paul, Hans")
        // Das Regex erwartet genau ein Komma als Trenner zwischen Nach- und Vorname
        String invalidName = "202412345678 Breitner, Paul, Hans";
        // Act and Assert: matcher.matches() wird false liefern -> Exception
        assertThrows(IllegalArgumentException.class, () -> parser.parse(invalidName));
    }

    @Test
    void invalidNumberWithLetters() {
        // Arrange: Buchstaben im Zahlenteil ("abcd...")
        // Das Regex (\\d{4}) und (\\d{7}) erzwingt Ziffern, daher schlägt das Matching fehl
        String numberWithLetters = "abcd12345678 Mustermann, Max";
        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> parser.parse(numberWithLetters));
    }

    @Test
    void invalidNumberTooShort() {
        // Arrange: Gesamtlänge der Zahlenkette zu kurz (fehlt Matrikelnummer-Teil)
        String numberTooShort = "2024123456 Mustermann, Max";
        // Act and Assert: Regex matched nicht, da exakte Längen (4, 1, 7) gefordert sind
        assertThrows(IllegalArgumentException.class, () -> parser.parse(numberTooShort));
    }

    @Test
    void invalidNumberTooLong() {
        // Arrange: Zahlenteil zu lang
        String numberTooLong = "2024123456789 Mustermann, Max";
        // Act and Assert
        assertThrows(IllegalArgumentException.class, () -> parser.parse(numberTooLong));
    }

    @Test
    void invalidSemesterId() {
        // Arrange: ID ist "3" - Das Regex matched zwar (da "3" eine Ziffer \\d ist)...
        String invalidSemesterId = "202432345678 Mustermann, Max";
        // Act and Assert: ...aber Semester.of(3) wirft die Exception in der Logik danach
        assertThrows(IllegalArgumentException.class, () -> parser.parse(invalidSemesterId));
    }
}