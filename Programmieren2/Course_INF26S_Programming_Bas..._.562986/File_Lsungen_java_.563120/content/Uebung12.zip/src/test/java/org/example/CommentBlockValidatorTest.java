package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CommentBlockValidatorTest {
    private CommentBlockValidator validator;
    @BeforeEach
    void setup() {
        validator = new CommentBlockValidator();
    }
    @Test
    void nomalText() {
        // Basis-Fall: Keine Kommentare sind auch valide (Count bleibt 0).
        assertTrue(validator.checkComments("ohne Blub"));
    }
    @Test
    void multipleComments() {
        // Sequenzielle Kommentare: Öffnen und Schließen nacheinander funktioniert.
        assertTrue(validator.checkComments("/* Blub 1 */ Text /* Blub 2 */ and /* Blub 3 */"));
    }
    @Test
    void inceptionComments() {
        // WICHTIG: Testet die Verschachtelung (Nesting).
        // Anders als Regex kann dieser Parser zählen, wie viele Ebenen offen sind.
        assertTrue(validator.checkComments("Dies ist /* ein /* Inception */ Blub */ !"));
    }
    @Test
    void startWithClosingCommentIsIgnored() {
        // Spezielles Verhalten: Schließende Kommentare ohne vorheriges Öffnen werden ignoriert
        // (Count geht nicht unter 0), anstatt den Test fehlschlagen zu lassen.
        assertTrue(validator.checkComments("Dies */ ist /* ein Blub */."));
    }
    @Test
    void moreOpeningsThanClosings() {
        // Fehlerfall: Am Ende ist der Zähler > 0 (nicht alle geschlossenen).
        assertFalse(validator.checkComments("/* Blub 1 /* ungeschlossener Blub */"));
    }
    @Test
    void moreClosingsThanOpenings() {
        // Fehlerfall: Hier wird zwar ignoriert (siehe startWithClosing...), aber logisch
        // passt die Struktur am Ende nicht, wenn man strikt prüft oder Zählfehler auftreten.
        // Konkret hier: /* (1) -> */ (0) -> /* (1). Ergebnis 1 => false.
        assertFalse(validator.checkComments("/* Blub 1 ungeschlossener /* Blub */"));
    }
    @Test
    void miniComment() {
        // WICHTIG: Testet minimale Länge und Token-Erkennung direkt nebeneinander.
        assertTrue(validator.checkComments("/**/ blub"));
        assertTrue(validator.checkComments("/***/ blub"));
    }
    @Test
    void starSlashSlashStar() {
        // Testet Überlappung: *//* -> */ (ignoriert da Count 0) dann /* (offen).
        // Ergebnis Count 1 -> False.
        assertFalse(validator.checkComments("*//* blub"));
    }
    @Test
    void twoClosingCommentsSurroundedByStars() {
        // Komplexer Fall für die Loop-Logik.
        assertTrue(validator.checkComments("*/***/** blub"));
    }
    @Test
    void starSlashStar() {
        // WICHTIG: * / * -> */ wird als erstes erkannt und konsumiert.
        // Der letzte * bleibt übrig. Valid.
        assertTrue(validator.checkComments("*/* blub"));
        assertTrue(validator.checkComments("*/*/*/*/ blub"));
    }
    @Test
    void slashStarSlash() {
        // WICHTIG: Vermeidung von Wiederverwendung.
        // /*/ -> /* wird erkannt. Der Pointer springt weiter. Das letzte / bleibt allein.
        // Block bleibt offen -> False.
        assertFalse(validator.checkComments("/*/ blub"));
        assertFalse(validator.checkComments("/*/*/*/* blub"));
    }
}