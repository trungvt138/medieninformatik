package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BracketsValidatorTest {
    private BracketsValidator validator;
    @BeforeEach
    void setUp() {
        validator = new BracketsValidator();
    }
    @Test
    void noBrackets() {
        // WICHTIG: Strings ohne Klammern gelten als valide, da keine Regeln verletzt werden.
        assertTrue(validator.isValid("abc"));
    }
    @Test
    void oneOpeningOneClosing() {
        // Basisfall: Ein einfaches Paar.
        assertTrue(validator.isValid("()"));
    }
    @Test
    void twoOpeningTwoClosing() {
        // Verschachtelung: Die innere Klammer wird zuerst geschlossen (LIFO-Prinzip des Stacks).
        assertTrue(validator.isValid("({})"));
    }
    @Test
    void threeOpeningThreeClosing() {
        // Komplexe Verschachtelung verschiedener Typen.
        assertTrue(validator.isValid("([{}])"));
    }
    @Test
    void threeOpeningThreeClosingSameBrackets() {
        assertTrue(validator.isValid("((()))"));
    }
    @Test
    void threeOpeningThreeClosingSameBracketsWithCharacters() {
        // WICHTIG: Andere Zeichen zwischen den Klammern müssen ignoriert werden.
        assertTrue(validator.isValid("a(b(c(d)e)f)g"));
    }
    @Test
    void threeOpeningThreeClosingWithCharacters() {
        assertTrue(validator.isValid("a(b[c{d}e]f)g"));
    }
    @Test
    void fourOpeningFourClosing() {
        assertTrue(validator.isValid("([{[]}])"));
    }
    @Test
    void fourOpeningFourClosingNotNested() {
        // Sequenzielle Klammern: Stack wird gefüllt, geleert, gefüllt, geleert.
        assertTrue(validator.isValid("[]{}()"));
    }
    @Test
    void fourOpeningFourClosingNotNestedWithCharacters() {
        assertTrue(validator.isValid("a[b]c{d}e(f)g"));
    }
    @Test
    void threeOpeningThreeClosingNotNestedWithCharacters() {
        assertTrue(validator.isValid("a[b]c{d}e(f)g"));
    }
    @Test
    void oneOpeningNoClosing() {
        // Fehlerfall: Am Ende ist der Stack nicht leer (offene Klammer übrig).
        assertFalse(validator.isValid("("));
    }
    @Test
    void oneOpeningNoClosingWithCharacters() {
        assertFalse(validator.isValid("abc(def"));
    }
    @Test
    void noOpeningOneClosing() {
        // Fehlerfall: Stack ist leer, wenn eine schließende Klammer kommt.
        assertFalse(validator.isValid("]"));
    }
    @Test
    void noOpeningOneClosingWithCharacters() {
        assertFalse(validator.isValid("abc]def"));
    }
    @Test
    void oneOpeningTwoClosingSameBrackets() {
        assertFalse(validator.isValid("[]]"));
    }
    @Test
    void oneOpeningTwoClosing() {
        assertFalse(validator.isValid("[}]"));
    }
    @Test
    void oneOpeningTwoClosingNonNested() {
        assertFalse(validator.isValid("[]}"));
    }
    @Test
    void oneOpeningTwoClosingWithCharacters() {
        assertFalse(validator.isValid("a[b]c}d"));
    }
    @Test
    void twoOpeningOneClosing() {
        assertFalse(validator.isValid("{[}"));
    }
    @Test
    void twoOpeningOneClosingSameBrackets() {
        assertFalse(validator.isValid("{{}"));
    }
    @Test
    void twoOpeningOneClosingNonNested() {
        assertFalse(validator.isValid("{}["));
    }
    @Test
    void twoOpeningOneClosingWithCharacters() {
        assertFalse(validator.isValid("a{b[c}d"));
    }
    @Test
    void twoOpeningTwoClosingWrongOrder() {
        // WICHTIG: Regex kann hier nicht helfen. Der Stack prüft die korrekte Reihenfolge der Verschachtelung.
        // '(' erwartet ')', aber '}' wurde gefunden.
        assertFalse(validator.isValid("({)}"));
    }
    @Test
    void twoOpeningTwoClosingWrongOrderWithCharacters() {
        assertFalse(validator.isValid("a(b{c)d}e"));
    }
    @Test
    void threeOpeningTwoClosing() {
        assertFalse(validator.isValid("({[})"));
    }
    @Test
    void threeOpeningThreeClosingWrongOrder() {
        assertFalse(validator.isValid("({[])}"));
    }
    @Test
    void threeOpeningThreeClosingWrongOrderWithCharacters() {
        assertFalse(validator.isValid("a(b{c[d]e)f}g"));
    }
    @Test
    void threeOpeningFourClosing() {
        assertFalse(validator.isValid("[{[]}])"));
    }
    @Test
    void threeOpeningFourClosingMixedNested() {
        assertFalse(validator.isValid("[{}[]])"));
    }
}