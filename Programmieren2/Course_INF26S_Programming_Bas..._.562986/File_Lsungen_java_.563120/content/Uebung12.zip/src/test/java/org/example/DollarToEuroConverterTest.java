package org.example;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DollarToEuroConverterTest {
    private final DollarToEuroConverter converter = new DollarToEuroConverter();

    @Test
    void testConvertDollarsToEurosWithValidCurrencies() {
        // Arrange: Liste mit gültigen US-Dollar Strings (Format: $Tausender,Hunderter.Cent)
        var dollars = List.of("$1,234.56", "$2,345.67");

        // Act
        var result = converter.convertDollarsToEuros(dollars);

        // Assert
        // WICHTIG: Erwartet wird das Euro-Format:
        // 1. Tausender-Punkt statt Komma
        // 2. Dezimal-Komma statt Punkt
        // 3. Euro-Zeichen am Ende
        assertEquals(List.of("1.234,56 €", "2.345,67 €"), result);
    }

    @Test
    void testConvertDollarsToEurosWithEmptyInput() {
        // Testet Grenzfall: Leere Eingabeliste soll leere Ergebnisliste liefern
        List<String> dollars = List.of();
        var actual = converter.convertDollarsToEuros(dollars);
        assertEquals(List.of(), actual);
    }

    @Test
    void testConvertDollarsToEurosWithMixedValidityCurrencies() {
        // WICHTIG: Die Methode soll robust sein.
        // "invalid" entspricht nicht dem Regex und muss ignoriert/gefiltert werden.
        // Nur die gültigen Dollar-Werte landen im Ergebnis.
        var dollars = List.of("$1,000.00", "invalid", "$2,500.50");
        var actual = converter.convertDollarsToEuros(dollars);
        assertEquals(List.of("1.000,00 €", "2.500,50 €"), actual);
    }

    @Test
    void testConvertDollarsToEurosWithInvalidNumbers() {
        // Testet verschiedene Formate, die vom Regex abgelehnt werden müssen:
        var dollars = List.of(
                "$2.a00,50",  // Ungültig: Buchstaben enthalten
                "2,500.50",   // Ungültig: Fehlendes $-Zeichen am Anfang
                "$2.500,50",  // Ungültig: Falsche Trennzeichen (Punkt bei Tausendern im US-Format falsch)
                "$2,500,50",  // Ungültig: Komma als Dezimaltrenner im US-Format falsch
                "$2.500.50",  // Ungültig: Zwei Punkte
                "$2.500.",    // Ungültig: Fehlende Cents nach dem Punkt
                "$2.500.0");  // Ungültig: Nur eine Dezimalstelle (Regex verlangt 2)

        var actual = converter.convertDollarsToEuros(dollars);

        // Da alle Eingaben ungültig waren, muss die Liste leer sein
        assertEquals(List.of(), actual);
    }
}