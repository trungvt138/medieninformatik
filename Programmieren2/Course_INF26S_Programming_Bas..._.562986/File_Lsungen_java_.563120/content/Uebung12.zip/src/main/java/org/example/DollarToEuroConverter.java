package org.example;

import java.util.ArrayList;
import java.util.Collection;

public class DollarToEuroConverter {

    Collection<String> convertDollarsToEuros(Collection<String> dollars) {
        var euros = new ArrayList<String>();
        for (String usCurrency : dollars) {
            try {
                // WICHTIG: Zuerst prüfen, ob das Format stimmt (Validierung)
                if (isValidUsCurrency(usCurrency)) {
                    // Wenn gültig: Konvertieren und zur Ergebnisliste hinzufügen
                    String euro = convertToEu(usCurrency);
                    euros.add(euro);
                }
                // Ungültige Einträge werden einfach übersprungen (nicht zur Liste hinzugefügt)
            } catch (Exception e) {
                // Ignore: Fehlerbehandlung durch Ignorieren, damit der Loop weiterläuft
            }
        }
        return euros;
    }

    private static boolean isValidUsCurrency(String dollar) {
        // WICHTIG: Regex zur Validierung des Dollar-Formats
        // ^        -> Start des Strings
        // \\$      -> Ein echtes Dollarzeichen (muss maskiert werden)
        // [\\d,]+  -> Mindestens eine Ziffer oder Komma (für Tausender-Trennzeichen)
        // \\.      -> Ein echtes Punkt-Zeichen (Dezimaltrenner)
        // \\d{2}   -> Genau zwei Ziffern (Cents)
        // $        -> Ende des Strings
        return dollar.matches("^\\$[\\d,]+\\.\\d{2}$");
    }

    private static String convertToEu(String dollar) {
        // Logik zum Tauschen der Trennzeichen und Ersetzen des Währungssymbols
        String noDollarSignWithPeriodAndCommaSwapped = dollar
                .replace("$", "")      // 1. Entfernt das Dollarzeichen
                .replace(".", ",")     // 2. Ersetzt den Dezimal-Punkt durch ein Komma (nun sind alle Trenner Kommas)
                .replaceFirst(",", "."); // 3. Ersetzt das ERSTE Komma (Tausender) durch einen Punkt.
        // Hinweis: Diese Logik setzt voraus, dass ein Tausendertrenner existiert.

        // Hängt das Euro-Zeichen am Ende an
        return noDollarSignWithPeriodAndCommaSwapped + " €";
    }
}