package org.example;

// WICHTIG: Record dient als reiner Datencontainer für das geparste Ergebnis.
// Records erstellen automatisch Konstruktor, Getter (z.B. year()) und toString/equals/hashCode.
public record Verwendungszweck(
        int year,
        Semester semester,
        String matriculationId,
        String firstName,
        String lastName) {}