package org.example;

final class StringUtil {

    /**
     * Lösung 1: Iterativer Ansatz
     * Diese Methode geht den String Zeichen für Zeichen durch und sammelt nur die Buchstaben ein.
     */
    static String extractLetters(String input) {
        // Wir verwenden StringBuilder statt normaler Strings (String Konkatenation mit +),
        // da Strings in Java "immutable" (unveränderlich) sind.
        // In einer Schleife immer neue String-Objekte zu erzeugen, wäre speicherineffizient.
        StringBuilder lettersOnly = new StringBuilder();

        // Wir iterieren durch den gesamten Eingabestring von Anfang bis Ende.
        for (int i = 0; i < input.length(); i++) {

            // Zugriff auf das Zeichen (char) an der aktuellen Position i.
            char c = input.charAt(i);

            // Hier passiert die eigentliche Prüfung:
            // Die Methode Character.isLetter(c) gibt 'true' zurück, wenn es sich um einen
            // Buchstaben (a-z, A-Z, etc.) handelt, und 'false' bei Zahlen oder Sonderzeichen.
            if (Character.isLetter(c)) {
                // Wenn es ein Buchstabe ist, hängen wir ihn an unseren StringBuilder an.
                lettersOnly.append(c);
            }
        }

        // Am Ende wandeln wir den StringBuilder zurück in einen normalen String.
        return lettersOnly.toString();
    }

    /**
     * Lösung 2: Regex Ansatz (Alternative)
     * Diese Methode ist deutlich kürzer, da sie Reguläre Ausdrücke (Regex) verwendet,
     * um alle unerwünschten Zeichen zu entfernen.
     */
    static String extractLettersRegex(String input) {
        // Die Methode replaceAll sucht nach einem Muster und ersetzt Treffer durch einen anderen String.
        // Das Muster "[^a-zA-Z]" erklärt sich so:
        // [ ... ] definiert eine Gruppe von Zeichen.
        // ^ am Anfang bedeutet "NICHT" (Negation).
        // a-zA-Z bedeutet alle Klein- und Großbuchstaben.
        //
        // Zusammengefasst: "Finde alles, was KEIN Buchstabe ist, und ersetze es durch
        // einen leeren String (lösche es)."
        return input.replaceAll("[^a-zA-Z]", "");
    }

    /**
     * Main-Methode zum Ausführen und Testen der Logik.
     */
    public static void main(String[] args) {
        // Test-Eingabe laut Aufgabenstellung: "?a $2c^{*}d$, e;"
        // Ziel: Alle Sonderzeichen und Zahlen entfernen, sodass nur "abcde" übrig bleibt.
        String input = "?a b$2c^{*}d$, e;";

        System.out.println("Ursprüngliche Eingabe: " + input);
        System.out.println("--------------------------------------------------");

        // Test der iterativen Lösung (mit StringBuilder und Schleife)
        String resultIterative = extractLetters(input);
        System.out.println("Ergebnis (Iterativ):   " + resultIterative);

        // Test der Regex Lösung (kurz und bündig)
        String resultRegex = extractLettersRegex(input);
        System.out.println("Ergebnis (Regex):      " + resultRegex);

        System.out.println("--------------------------------------------------");

        // Kurzer Check, ob beide Methoden das Gleiche liefern
        if (resultIterative.equals("abcde") && resultRegex.equals("abcde")) {
            System.out.println("Test erfolgreich: Beide Methoden liefern 'abcde'.");
        } else {
            System.out.println("Fehler: Das Ergebnis stimmt nicht überein.");
        }
    }
}