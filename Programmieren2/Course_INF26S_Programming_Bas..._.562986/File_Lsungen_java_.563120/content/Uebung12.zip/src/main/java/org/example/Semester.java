package org.example;

enum Semester {
    // Definition der Konstanten mit zugehöriger ID, wie in der Aufgabe gefordert (1 = SoSe, 2 = WiSe)
    SOSE(1),
    WISE(2);

    private final int id;

    Semester(int id) {
        this.id = id;
    }

    // WICHTIG: Statische Methode zur Umwandlung der ID (aus dem String) in das Enum
    static Semester of(int id) {
        // Iteriert durch alle verfügbaren Semester-Werte
        for (var semester : Semester.values()) {
            if (semester.id == id) {
                return semester;
            }
        }
        // WICHTIG: Fehlerbehandlung, falls eine unbekannte ID (z.B. 3) übergeben wird
        throw new IllegalArgumentException("Ungültige Semester-ID: " + id);
    }

    @Override
    public String toString() {
        return "%s{id=%d}".formatted(this.name(), this.id);
    }
}