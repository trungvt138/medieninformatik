package org.example;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class VerwendungszweckParser {
    Verwendungszweck parse(String input) {
        // Validierung: Eingabe darf nicht null oder leer sein
        if (input == null || input.isEmpty()) {
            throw new IllegalArgumentException("Input cannot be null or empty");
        }

        // WICHTIG: Der reguläre Ausdruck zerlegt den Input in Gruppen.
        // (\\d{4})   -> Gruppe 1: Das Jahr (exakt 4 Ziffern)
        // (\\d)      -> Gruppe 2: Die Semester-ID (exakt 1 Ziffer)
        // (\\d{7})   -> Gruppe 3: Die Matrikelnummer (exakt 7 Ziffern)
        // ([^,]+)    -> Gruppe 4: Nachname (Alles bis zum Komma)
        // ,          -> Literal: Ein Komma und ein Leerzeichen als Trenner
        // ([^,]+)    -> Gruppe 5: Vorname (Alles, was danach kommt, darf kein Komma enthalten)
        Matcher matcher = Pattern.compile("(\\d{4})(\\d)(\\d{7}) ([^,]+), ([^,]+)").matcher(input);

        // Prüft, ob der gesamte String dem Muster entspricht
        if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid input format");
        }

        // WICHTIG: Extraktion und Konvertierung der Regex-Gruppen
        // Gruppe 1 parsen (Jahr)
        int year = Integer.parseInt(matcher.group(1));

        // Gruppe 2 parsen (Semester-ID) und via Semester.of() in Enum umwandeln
        // Wirft IllegalArgumentException, wenn ID nicht 1 oder 2 ist
        int semesterId = Integer.parseInt(matcher.group(2));
        Semester semester = Semester.of(semesterId);

        // Gruppe 3: Matrikelnummer als String extrahieren
        String matriculationId = matcher.group(3);

        // Gruppe 4: Nachname extrahieren
        String lastName = matcher.group(4);

        // Gruppe 5: Vorname extrahieren
        String firstName = matcher.group(5);

        // Erstellen und Zurückgeben des Ergebnis-Objekts
        return new Verwendungszweck(year, semester, matriculationId, firstName, lastName);
    }
}