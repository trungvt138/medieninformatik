package org.example;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.*;

class UrlParameterParser {

    static Map<String, String> parse(String url) {
        Map<String, String> parameters = new HashMap<>();

        // WICHTIG: Schritt 1 - Isolieren des Query-Strings
        // Regex Erklärung:
        // \\?  -> Sucht nach dem literalen Fragezeichen (Start der Parameter)
        // (.*) -> Gruppe 1: Fängt alles ein (Punkt = beliebiges Zeichen, Stern = 0 oder mehr)
        // $    -> Bis zum Ende des Strings
        Pattern queryPattern = Pattern.compile("\\?(.*)$");
        Matcher queryMatcher = queryPattern.matcher(url);

        // Prüfen, ob überhaupt ein Fragezeichen in der URL enthalten ist
        if (queryMatcher.find()) {
            // Extrahiert den Teil NACH dem Fragezeichen (z.B. "a=1&b=2")
            String query = queryMatcher.group(1);

            // WICHTIG: Schritt 2 - Parsen der Key-Value Paare
            // Regex Erklärung:
            // ([^&=]+) -> Gruppe 1 (Key): Ein oder mehr Zeichen, die NICHT '&' oder '=' sind.
            // =        -> Das Trennzeichen zwischen Key und Value.
            // ([^&]*)  -> Gruppe 2 (Value): Null oder mehr Zeichen, die NICHT '&' sind.
            //             (Stern erlaubt leere Werte wie bei "key=").
            Pattern paramPattern = Pattern.compile("([^&=]+)=([^&]*)");
            Matcher paramMatcher = paramPattern.matcher(query);

            // Schleife läuft so lange, wie das Muster im String gefunden wird.
            // find() sucht hier iterativ nach dem nächsten Treffer (Parameter-Paar).
            while (paramMatcher.find()) {
                // Holt den Key aus der ersten Klammer-Gruppe des Regex
                String key = paramMatcher.group(1);
                // Holt den Value aus der zweiten Klammer-Gruppe des Regex
                String value = paramMatcher.group(2);

                // Speichert das Paar in der Map
                parameters.put(key, value);
            }
        }

        return parameters;
    }
}