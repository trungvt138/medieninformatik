package org.example;

class CommentBlockValidator {
    private static final char SLASH = '/';
    private static final char STAR = '*';
    private String input;

    boolean checkComments(String input) {
        this.input = input;
        int commentCount = 0; // Zähler für die Verschachtelungstiefe
        int index = 0;

        // Iteriert Zeichen für Zeichen durch den String (mit Lookahead)
        while (hasNextChar(index)) {
            if (isOpeningComment(index)) {
                commentCount++;
                // WICHTIG: Überspringe das nächste Zeichen.
                // Wenn wir '/' bei index i finden und '*' bei i+1, haben wir ein Token.
                // Wir müssen i erhöhen, damit im nächsten Schleifendurchlauf das '*'
                // nicht nochmal als Startzeichen für ein neues Token gewertet wird.
                // Das verhindert, dass "/*/" doppelt gewertet wird.
                index++;
            } else if (isClosingComment(index)) {
                // Logik für schließende Klammern */
                commentCount = decrementIfOpeningExists(commentCount);
                // Auch hier: Zeichen überspringen, um Token zu konsumieren.
                index++;
            }
            // Normales Weiterschreiten zum nächsten Zeichen
            index++;
        }
        // WICHTIG: Nur wenn der Zähler am Ende exakt 0 ist, sind alle Blöcke geschlossen.
        return commentCount == 0;
    }

    private boolean hasNextChar(int index) {
        // Prüft, ob noch mindestens ein weiteres Zeichen für ein Paar existiert
        return (index + 1) < input.length();
    }

    private boolean isOpeningComment(int index) {
        // Prüft auf /*
        return currentChar(index) == SLASH && nextChar(index) == STAR;
    }

    private boolean isClosingComment(int index) {
        // Prüft auf */
        return currentChar(index) == STAR && nextChar(index) == SLASH;
    }

    private char currentChar(int index) {
        return input.charAt(index);
    }

    private char nextChar(int index) {
        return input.charAt(index + 1);
    }

    private static int decrementIfOpeningExists(int commentCount) {
        // WICHTIG: Verhindert negative Zähler.
        // Wenn ein */ kommt, ohne dass ein /* offen ist (count 0),
        // wird es ignoriert statt den Zähler auf -1 zu setzen.
        if (commentCount > 0) {
            return commentCount - 1;
        }
        return commentCount;
    }
}