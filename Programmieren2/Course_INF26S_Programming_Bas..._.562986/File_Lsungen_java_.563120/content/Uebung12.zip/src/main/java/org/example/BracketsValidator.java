package org.example;

import java.util.*;

class BracketsValidator {
    // Mapping definiert, welche öffnende Klammer (Key) zu welcher schließenden (Value) gehört.
    private static final Map<Character, Character> VALID_BRACKETS = Map.of(
            '(', ')',
            '{', '}',
            '[', ']');

    boolean isValid(String input) {
        // WICHTIG: Verwendung eines Deque (Double Ended Queue) als Stack.
        // LinkedList implementiert Deque und ersetzt die alte 'Stack'-Klasse.
        Deque<Character> stack = new LinkedList<>();

        for (char character : input.toCharArray()) {
            if (isOpeningBracket(character)) {
                char openingBracket = character;
                // WICHTIG: push() legt das Element oben auf den Stapel (zuletzt geöffnet).
                stack.push(openingBracket);
            } else if (isClosingBracket(character)) {
                // Wenn eine schließende Klammer kommt, muss der Stack etwas enthalten.
                // Wenn er leer ist, gibt es keine passende öffnende Klammer -> ungültig.
                if (noOpeningBracketExists(stack)) {
                    return false;
                }
                char closingBracket = character;
                // WICHTIG: pop() entfernt das oberste (zuletzt hinzugefügte) Element.
                char lastAddedOpeningBracket = stack.pop();

                // Prüfung: Passt die gerade geschlossene Klammer zu der zuletzt geöffneten?
                if (!matches(lastAddedOpeningBracket, closingBracket)) {
                    return false;
                }
            }
            // Hinweis: Zeichen, die keine Klammern sind, werden durch if/else if ignoriert.
        }
        // WICHTIG: Am Ende muss der Stack leer sein. Ist er es nicht, wurden Klammern nicht geschlossen.
        return stack.isEmpty();
    }

    private boolean isOpeningBracket(char character) {
        // Prüft, ob das Zeichen ein Key in der Map ist (also '(', '{' oder '[').
        return VALID_BRACKETS.containsKey(character);
    }

    private boolean isClosingBracket(char character) {
        // Prüft, ob das Zeichen ein Value in der Map ist (also ')', '}' oder ']').
        return VALID_BRACKETS.containsValue(character);
    }

    private static boolean noOpeningBracketExists(Collection<Character> stack) {
        return stack.isEmpty();
    }

    private boolean matches(char openingBracket, char actualClosingBracket) {
        // Holt die erwartete schließende Klammer für die gegebene öffnende Klammer.
        char expectedClosingBracket = VALID_BRACKETS.get(openingBracket);
        // Vergleicht Erwartung mit Realität.
        return Objects.equals(expectedClosingBracket, actualClosingBracket);
    }
}