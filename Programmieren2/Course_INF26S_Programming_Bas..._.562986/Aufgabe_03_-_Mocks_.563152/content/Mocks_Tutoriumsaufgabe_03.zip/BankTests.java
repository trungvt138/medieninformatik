package Mocks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


class BankTests {

    Account account1;
    Account account2;

    @BeforeEach
    void setUp() {
        account1 = new Account(1, "test", 100);
        account2 = new Account(2, "test", 100);
    }

    @Test
    void transferTestWithMock() {
        Bank bank = new BankMock();
        assertTrue(bank.transfer(account1, account2, 100));
    }

    @Test
    void transferBalanceTestWithMock() {
        Bank bank = new BankMock();
        bank.transfer(account1, account2, 100);
        assertEquals(account1.getBalance(), 0f, 0.0001);
    }
}