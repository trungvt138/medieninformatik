package Mocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class Bank {

    private List<Account> accounts = new ArrayList<Account>();

    //Fügt nur 1000 Zufällige Konten in das Bank objekt bei Erstellung hinzu :)
    public Bank() {
        for (int i = 0; i < 1000; i++) {
            Account newAccount;
            do {
                newAccount = new Account(new Random().nextInt(2000), "anyOwner", new Random().nextFloat(5000));
            } while (AccountExists(newAccount));
            accounts.add(newAccount);
        }
    }

    public boolean AccountExists(Account account) {
        if (accounts.isEmpty()) return false;
        for (Account acc : accounts){
            if (acc.getId() == account.getId()){
                return true;
            }
        }
        return false;
    }

    public boolean transfer(Account sender, Account recipient, int amount) {
        if (AccountExists(sender) && AccountExists(recipient)) {
            try {
                sender.send(amount, recipient);
                return true;
            } catch (Exception e) {
                throw new RuntimeException("Something went wrong with the transfer operation", e);
            }
        }
        return false;
    }
}
