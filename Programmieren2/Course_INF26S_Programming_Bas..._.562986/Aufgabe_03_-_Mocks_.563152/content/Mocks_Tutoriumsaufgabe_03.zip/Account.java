package Mocks;

public class Account {
    public Account(int id, String owner, float balance) {
        this.id = id;
        this.owner = owner;
        this.balance = balance;
    }

    private final int id;
    private String owner;
    private float balance;
    private boolean sending = false;

    public int getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public float getBalance() {
        return balance;
    }

    public boolean isSending() {
        return sending;
    }

    public void send(float amount, Account recipient) throws Exception {
        if (getBalance() >= amount) {
            balance -= amount;
            sending = true;
            if (recipient.receive(amount,this)){
                sending = false;
                return;
            } else {
                balance += amount;
                throw new Exception("Recipient could not receive money!");
            }
        }
        throw new Exception("Not Enough Balance to send!");
    }

    public boolean receive(float amount, Account sender) {
        if (sender.isSending()) {
            this.balance += amount;
            System.out.println("Successfully sent " + amount + "$ from " + sender.getOwner() + " to " + getOwner());
            return true;
        }
        return false;
    }
}
