package de.hawhamburg.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

class PingServerIO {

    private static final int PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.printf("Server is listening on port %d ...%n", PORT);
            // Endlosschleife: Der Server soll dauerhaft laufen und immer wieder neue Clients akzeptieren.
            while (true) {
                acceptClient(serverSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void acceptClient(ServerSocket serverSocket) throws IOException {
        // Blockiert, bis ein Client verbindet.
        var clientSocket = serverSocket.accept();
        // WICHTIG: Java 21 Feature. Startet einen "Virtual Thread" für diesen Client.
        // Das erlaubt dem Haupt-Thread (main), sofort wieder zur while-Schleife zurückzukehren
        // und auf den nächsten Client zu warten (Parallelität).
        Thread.ofVirtual().start(() -> readClientMessage(clientSocket));
    }

    private static void readClientMessage(Socket clientSocket) {
        String message;
        // BufferedReader zum effizienten Lesen von Zeilen.
        try (BufferedReader clientReader = newClientReader(clientSocket)) {
            // Liest so lange Zeilen, bis der Client die Verbindung trennt (null).
            while ((message = clientReader.readLine()) != null)
                System.out.printf("%s: %s%n", currentTimestamp(), message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static BufferedReader newClientReader(Socket clientSocket) throws IOException {
        // InputStreamReader konvertiert Bytes in Zeichen (CharSet beachten!).
        return new BufferedReader(new InputStreamReader(clientSocket.getInputStream(), StandardCharsets.UTF_8));
    }

    private static String currentTimestamp() {
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return currentTime.format(formatter);
    }
}