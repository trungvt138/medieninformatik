package de.hawhamburg.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class PingClientNIO {

    private static final String IP_ADDRESS = "localhost";
    private static final int PORT = 12345;
    private static final int NUMBER_OF_PINGS = 5;

    public static void main(String[] args) {
        // Öffnen eines asynchronen Channels für den Client.
        try (AsynchronousSocketChannel server = AsynchronousSocketChannel.open()) {
            // connect() gibt ein Future zurück.
            Future<Void> serverConnection = server.connect(new InetSocketAddress(IP_ADDRESS, PORT));
            // .get() blockiert hier, bis die Verbindung wirklich steht.
            serverConnection.get();

            for (int pingCounter = 1; pingCounter <= NUMBER_OF_PINGS; pingCounter++) {
                String message = "ping %d%n".formatted(pingCounter);
                send(server, message);
                System.out.printf("Sent message to %s:%d%n", IP_ADDRESS, PORT);
                Thread.sleep(Duration.ofSeconds(1).toMillis());
            }
        } catch (IOException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    private static void send(AsynchronousSocketChannel server, String message) throws InterruptedException, ExecutionException {
        // Wrap erzeugt einen ByteBuffer aus dem String-Array.
        ByteBuffer buffer = ByteBuffer.wrap(message.getBytes(StandardCharsets.UTF_8));
        // write() passiert asynchron und gibt ein Future zurück. .get() wartet auf Abschluss.
        server.write(buffer).get();
    }
}