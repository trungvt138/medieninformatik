package de.hawhamburg.socket;

import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

class SimpleClient {

    private static final String IP_ADRESS = "127.0.0.1"; // Localhost
    private static final int PORT = 12345;

    public static void main(String[] args) {
        // Baut Verbindung zum Server auf (IP + Port).
        try (Socket socket = new Socket(IP_ADRESS, PORT);
             // Scanner erleichtert das zeichenweise Lesen vom InputStream des Sockets.
             Scanner scanner = new Scanner(socket.getInputStream())) {

            // Prüfen, ob eine Zeile gesendet wurde (blockiert ggf., bis Daten da sind).
            if (scanner.hasNextLine()) {
                System.out.printf("Received message: %s%n", scanner.nextLine());
            } else {
                System.out.println("No message received from the server.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}