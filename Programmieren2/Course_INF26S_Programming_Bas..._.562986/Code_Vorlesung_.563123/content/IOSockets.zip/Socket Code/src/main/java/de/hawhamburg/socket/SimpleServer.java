package de.hawhamburg.socket;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

class SimpleServer {

    private static final int PORT = 12345;

    public static void main(String[] args) {
        // Try-with-resources: Stellt sicher, dass der ServerSocket (und ClientSocket)
        // automatisch geschlossen werden, auch bei Fehlern.
        try (ServerSocket serverSocket = new ServerSocket(PORT);
             // serverSocket.accept() BLOCKIERT hier den Programmablauf, bis ein Client
             // eine Verbindung aufbaut. Es wird ein neuer Socket für diesen Client zurückgegeben.
             Socket clientSocket = serverSocket.accept();
             // Wrapper um den OutputStream, um bequem Text senden zu können.
             PrintWriter printWriter = newPrintWriter(clientSocket)) {

            // Schreibt Daten in den Puffer
            printWriter.println("Hallo Client!");
            // WICHTIG: flush() erzwingt das Senden der Daten aus dem Puffer an den Client.
            printWriter.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static PrintWriter newPrintWriter(Socket clientSocket) throws IOException {
        // BufferedOutputStream sorgt für Effizienz durch Pufferung der Bytes.
        return new PrintWriter(new BufferedOutputStream(clientSocket.getOutputStream()));
    }
}