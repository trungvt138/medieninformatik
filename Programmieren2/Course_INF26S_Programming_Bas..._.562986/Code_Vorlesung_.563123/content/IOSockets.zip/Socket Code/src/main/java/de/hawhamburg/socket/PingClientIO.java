package de.hawhamburg.socket;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.time.Duration;

class PingClientIO {

    private static final String IP_ADDRESS = "localhost";
    private static final int PORT = 12345;
    private static final int NUMBER_OF_PINGS = 5;

    public static void main(String[] args) {
        try (Socket server = new Socket(IP_ADDRESS, PORT)) {
            for (int pingCounter = 1; pingCounter <= NUMBER_OF_PINGS; pingCounter++) {
                var message = "ping %d%n".formatted(pingCounter);
                send(server, message);
                System.out.printf("Sent message to %s:%d%n", IP_ADDRESS, PORT);
                // Künstliche Pause von 1 Sekunde zwischen den Nachrichten
                Thread.sleep(Duration.ofSeconds(1).toMillis());
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void send(Socket server, String message) throws IOException {
        // Hier nutzen wir direkt den OutputStream (byteorientiert) statt PrintWriter.
        OutputStream outputStream = new BufferedOutputStream(server.getOutputStream());
        outputStream.write(message.getBytes());
        // Flush ist essenziell bei gepufferten Streams, damit Daten sofort rausgehen
        // und nicht erst, wenn der Puffer voll ist.
        outputStream.flush();
    }
}