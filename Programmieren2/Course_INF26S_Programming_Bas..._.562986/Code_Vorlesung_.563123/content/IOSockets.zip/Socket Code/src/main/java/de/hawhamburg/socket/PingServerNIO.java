package de.hawhamburg.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CountDownLatch;

class PingServerNIO {

    private static final int PORT = 12345;

    public static void main(String[] args) {
        // AsynchronousServerSocketChannel: Die nicht-blockierende Variante von ServerSocket.
        try (AsynchronousServerSocketChannel serverSocket = AsynchronousServerSocketChannel.open()) {
            serverSocket.bind(new InetSocketAddress(PORT));
            System.out.printf("Server is listening on port %d ...%n", PORT);

            // Startet das asynchrone Akzeptieren von Clients.
            acceptClientAsync(serverSocket);

            // Da acceptClientAsync NICHT blockiert, würde main sofort enden.
            // Wir müssen den Server künstlich am Leben halten.
            keepServerAlive();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void keepServerAlive() {
        // CountDownLatch blockiert diesen Thread, bis latch.countDown() aufgerufen wird (hier nie, also ewig).
        // Eine CPU-schonende Alternative zu while(true) {}.
        final CountDownLatch latch = new CountDownLatch(1);
        try {
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Thread.currentThread().interrupt();
        }
    }

    private static void acceptClientAsync(AsynchronousServerSocketChannel serverSocket) {
        // accept() kehrt SOFORT zurück. Wenn ein Client kommt, wird die 'completed' Methode
        // des übergebenen CompletionHandlers aufgerufen (Callback).
        serverSocket.accept(null, new CompletionHandler<AsynchronousSocketChannel, Void>() {
            @Override
            public void completed(AsynchronousSocketChannel clientSocket, Void attachment) {
                // Bereitmachen für den NÄCHSTEN Client (Loop-Effekt durch Rekursion im Callback).
                acceptNewClientAsync();
                // Den aktuellen Client bedienen.
                readClientMessage(clientSocket);
            }

            private void acceptNewClientAsync() {
                serverSocket.accept(null, this);
            }

            @Override
            public void failed(Throwable e, Void attachment) {
                e.printStackTrace();
            }
        });
    }

    private static void readClientMessage(AsynchronousSocketChannel clientSocket) {
        try {
            // Buffer in NIO: Container für Daten. Allocate reserviert Speicher.
            ByteBuffer buffer = ByteBuffer.allocate(6); // Klein gewählt für Demo

            // Asynchrones Lesen in den Buffer.
            clientSocket.read(buffer, buffer, new CompletionHandler<>() {
                @Override
                public void completed(Integer bytesRead, ByteBuffer buffer) {
                    if (clientHasClosedConnection(bytesRead)) {
                        close(clientSocket);
                    } else {
                        // Flip: Umschalten von "Schreiben in Buffer" zu "Lesen aus Buffer".
                        buffer.flip();
                        String message = StandardCharsets.UTF_8.decode(buffer).toString().trim();
                        System.out.printf("%s: %s%n", currentTimestamp(), message);

                        // Clear: Buffer leeren/zurücksetzen für den nächsten Schreibvorgang des Channels.
                        buffer.clear();

                        // Rekursiver Aufruf: Lies die nächste Nachricht dieses Clients.
                        clientSocket.read(buffer, buffer, this);
                    }
                }

                private static boolean clientHasClosedConnection(Integer bytesRead) {
                    return bytesRead == -1;
                }

                @Override
                public void failed(Throwable e, ByteBuffer buffer) {
                    close(clientSocket);
                }
            });
        } catch (Exception e) {
            close(clientSocket);
        }
    }

    private static void close(AsynchronousSocketChannel clientSocket) {
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String currentTimestamp() {
        LocalTime currentTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return currentTime.format(formatter);
    }
}