package de.hawhamburg.weather;

import java.time.YearMonth;

record WeatherEntry(
    YearMonth date,
    String city,
    double temperature,
    double precipitation,
    double sunshine) {
}