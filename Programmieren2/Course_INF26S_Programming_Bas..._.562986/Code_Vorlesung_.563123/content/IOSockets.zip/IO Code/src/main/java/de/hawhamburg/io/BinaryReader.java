package de.hawhamburg.io;

import java.io.FileInputStream;
import java.io.IOException;

class BinaryReader {

    public static void main(String[] args) {
        String filePath = "unicorn.jpg";

        int counter = 0;
        try (FileInputStream fis = new FileInputStream(filePath)) {
            int byteRead;
            while ((byteRead = fis.read()) != -1) {
                String binaryString = String.format("%8s", Integer.toBinaryString(byteRead & 0xFF)).replace(' ', '0');
                System.out.print(binaryString + " ");
                counter++;
                if (counter >= 100) return;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}