package de.hawhamburg.weather;

record WeatherStats(String city,
                    double minTemperature,
                    double maxTemperature,
                    double meanTemperature
) {}