package de.hawhamburg.weather;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.YearMonth;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class WeatherEntryParser {

    private static final Pattern WEATHER_PATTERN = Pattern.compile(
        "(\\d{4}-\\d{2}),([^,]+),([\\d\\.]+),([\\d\\.]+),([\\d\\.]+)"
    );

    static Collection<WeatherEntry> parseFile(String name) {
        Collection<WeatherEntry> result = new LinkedList<>();
        try {
            Path path = Paths.get(name);
            List<String> lines = Files.readAllLines(path);
            result = parseWeatherEntries(lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private static List<WeatherEntry> parseWeatherEntries(List<String> lines) {
        return lines.stream()
            .map(WeatherEntryParser::newWeatherEntry)
            .flatMap(Optional::stream)
            .toList();

//        List<WeatherEntry> result = new LinkedList<>();
//        for (String line : lines) {
//            newWeatherEntry(line).ifPresent(result::add);
//        }
//        return result;
    }

    private static Optional<WeatherEntry> newWeatherEntry(String line) {
        Matcher matcher = WEATHER_PATTERN.matcher(line);
        if (matcher.matches()) {
            YearMonth date = YearMonth.parse(matcher.group(1));
            String city = matcher.group(2);
            double temperature = Double.parseDouble(matcher.group(3));
            double precipitation = Double.parseDouble(matcher.group(4));
            double sunshine = Double.parseDouble(matcher.group(5));
            return Optional.of(new WeatherEntry(date, city, temperature, precipitation, sunshine));
        }
        return Optional.empty();
    }
}