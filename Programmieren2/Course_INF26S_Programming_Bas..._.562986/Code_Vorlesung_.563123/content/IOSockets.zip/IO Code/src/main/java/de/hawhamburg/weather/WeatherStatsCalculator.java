package de.hawhamburg.weather;

import java.util.*;
import java.util.stream.Collectors;

class WeatherStatsCalculator {

    public static void main(String[] args) {
        var calculator = new WeatherStatsCalculator(WeatherEntryParser.parseFile("WeatherData.txt"));
        System.out.println(calculator.formattedTemperatureStats());
    }

    private final Collection<WeatherEntry> data;

    WeatherStatsCalculator(Collection<WeatherEntry> data) {
        this.data = data;
    }

    String formattedTemperatureStats() {
        String result = "Temperature Stats" + System.lineSeparator();
        result += temperatureStats().stream()
            .sorted(Comparator.comparing(WeatherStats::city))
            .map(stats -> temperatureStatsFormatter(stats, Locale.ENGLISH))
            .collect(Collectors.joining());
        return result;

//        StringBuilder result = new StringBuilder();
//        result.append("Temperature Stats")
//              .append(System.lineSeparator());
//        for (WeatherStats weatherStats : temperatureStats()) {
//            result.append(temperatureStatsFormatter(weatherStats));
//        }
//        return result.toString();
    }

    private static String temperatureStatsFormatter(WeatherStats stats, Locale locale) {
        return String.format(locale, "%s: min=%.1f, max=%.1f, mean=%.1f%n",
            stats.city(), stats.minTemperature(), stats.maxTemperature(), stats.meanTemperature());
    }

    Collection<WeatherStats> temperatureStats() {
        return weatherEntriesByCity().entrySet().stream()
            .map(e -> {
                String city = e.getKey();
                Collection<WeatherEntry> weatherEntries = e.getValue();
                return new WeatherStats(city,
                    minTemperature(weatherEntries),
                    maxTemperature(weatherEntries),
                    meanTemperature(weatherEntries));
            })
            .collect(Collectors.toSet());

//        Set<WeatherStats> result = new HashSet<>();
//        for (var perCity : entriesByCity().entrySet()) {
//            String city = perCity.getKey();
//            Collection<WeatherEntry> entries = perCity.getValue();
//            result.add(new WeatherStats(city,
//                minTemperature(entries),
//                maxTemperature(entries),
//                meanTemperature(entries)));
//        }
//        return result;
    }

    private Map<String, List<WeatherEntry>> weatherEntriesByCity() {
        return data.stream().collect(Collectors.groupingBy(WeatherEntry::city, Collectors.toList()));

//        Map<String, List<WeatherEntry>> result = new HashMap<>();
//        for (WeatherEntry entry : data) {
//            result.computeIfAbsent(entry.city(), _ -> new LinkedList<>()).add(entry);
//        }
//        return result;
    }

    private static Double minTemperature(Collection<WeatherEntry> entries) {
        return entries.stream()
            .mapToDouble(WeatherEntry::temperature)
            .min().orElse(0.0);
    }

    private static Double maxTemperature(Collection<WeatherEntry> entries) {
        return entries.stream()
            .mapToDouble(WeatherEntry::temperature)
            .max().orElse(0.0);
    }

    private static double meanTemperature(Collection<WeatherEntry> entries) {
        return entries.stream()
            .mapToDouble(WeatherEntry::temperature)
            .average().orElse(0.0);
    }
}