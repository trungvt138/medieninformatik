package de.hawhamburg.altneu;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

class AltNeuConverter {

    public static void main(String[] args) {
        try {
            List<String> lines = Files.readAllLines(Paths.get("input.txt"));
            List<String> modifiedLines = lines.stream()
                .map(line -> line
                    .replace("alt", "neu")
                    .replace("Alte", "Neue")
                    .replace("alter", "neuer"))
                .toList();
            Files.write(Paths.get("output.txt"), modifiedLines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}