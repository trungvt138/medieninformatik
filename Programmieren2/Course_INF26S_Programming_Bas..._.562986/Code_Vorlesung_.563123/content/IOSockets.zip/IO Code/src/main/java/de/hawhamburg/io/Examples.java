package de.hawhamburg.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * Begleitcode zur Vorlesung IO und Sockets.
 * Enthält Beispiele für:
 * - Klassisches IO (java.io) vs. Modernes NIO (java.nio)
 * - Zeichenorientiertes vs. Byteorientiertes Lesen/Schreiben
 * - Sicherheitsaspekte (Path Traversal)
 */
class Examples {

    /**
     * Zeigt die klassische (blockierende) Vorgehensweise mit java.io.File.
     * Dies ist der "alte" Weg vor Java 7.
     *
     * Konzepte:
     * - java.io.File: Repräsentiert den Dateipfad (nicht den Inhalt).
     * - BufferedReader/FileReader: Zeichenorientiertes Lesen.
     * - try-with-resources: Sorgt dafür, dass der Reader automatisch geschlossen wird (AutoCloseable).
     * Dies verhindert Resource Leaks.
     */
    public static void java_io(String[] args) {
        File file = new File("ChuckNorrisFacts.txt");
        // Der BufferedReader wird im try-Block geöffnet und am Ende automatisch geschlossen.
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String fact;
            // readLine() blockiert den Thread, bis eine Zeile gelesen wurde oder null (EOF) kommt.
            while ((fact = reader.readLine()) != null) {
                System.out.println(fact);
            }
        } catch (IOException e) {
            // IO-Operationen erzwingen das Fangen von Checked Exceptions.
            System.err.println("Only Chuck Norris can open this file.");
        }
    }

    /**
     * Liest eine Datei komplett als Byte-Array in den Speicher.
     * Nutzung der Utility-Klasse java.nio.file.Files.
     *
     * Achtung:
     * - Geeignet für kleine Dateien (z.B. Bilder).
     * - Bei großen Dateien droht ein OutOfMemoryError, da alles im RAM gehalten wird.
     */
    public static void binaryRead(String[] args) {
        try {
            Path path = Paths.get("unicorn.jpg");
            // readAllBytes öffnet, liest und schließt die Datei in einem Rutsch.
            System.out.println(Arrays.toString(Files.readAllBytes(path)));
        } catch (IOException e) {
            System.err.println("Cannot read file: " + e.getMessage());
        }
    }

    /**
     * Zeichenorientiertes Lesen aller Zeilen in eine Liste.
     * Komfortable NIO-Methode, aber speicherintensiv bei großen Dateien.
     */
    public static void nioRead(String[] args) {
        try {
            Path path = Paths.get("ChuckNorrisFacts.txt");
            // Files.readAllLines liest die gesamte Datei in eine List<String>.
            // Das Encoding ist standardmäßig UTF-8.
            Files.readAllLines(path).forEach(line -> System.out.println(line));
        } catch (IOException e) {
            System.err.println("Only Chuck Norris can open this file.");
        }
    }

    /**
     * Effizientes, zeichenorientiertes Lesen mit Streams (java.util.stream.Stream).
     *
     * Vorteile:
     * - Lazy evaluation: Zeilen werden nur bei Bedarf gelesen.
     * - Speicherschonend: Die Datei muss nicht komplett in den RAM geladen werden.
     *
     * Wichtig:
     * - Der Stream muss explizit geschlossen werden (try-with-resources), da er an einer offenen Datei hängt.
     * - Anders als bei Collections schließen Streams IO-Ressourcen nicht automatisch.
     */
    public static void nioReadStream(String[] args) {
        try {
            Path path = Paths.get("ChuckNorrisFacts.txt");
            // try-with-resources ist hier Pflicht!
            try (Stream<String> lines = Files.lines(path)) {
                lines.forEach(System.out::println);
            }
        } catch (IOException e) {
            System.err.println("Only Chuck Norris can open this file.");
        }
    }

    /**
     * Schreiben von Textdateien mit NIO.
     * Verwendet StandardOpenOption zur Steuerung des Dateizugriffs (Erstellen, Anhängen).
     */
    public static void nioWrite(String[] args) {
        List<String> facts = List.of(
                "The universe is not expanding; it is running away from Chuck Norris.",
                "Chuck Norris only uses stunt doubles for crying scenes.",
                "Chuck Norris doesn't use the steering wheel to drive. The road forms where Chuck Norris wants to go.",
                "When Chuck Norris falls into the water, he doesn't get wet. The water becomes Chuck Norris."
        );
        try {
            Path path = Paths.get("ChuckNorrisFacts.txt");
            // Schreibt die Liste in die Datei.
            // CREATE: Erstellt Datei, falls nicht vorhanden.
            // APPEND: Fügt Daten am Ende an (statt Überschreiben).
            Files.write(path, facts, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Only Chuck Norris can write this file.");
        }
    }

    /**
     * Low-Level Byte-Schreiben mit FileChannel und ByteBuffer.
     * (Originalname im Code war 'nioByteorientedWirt', hier korrigiert zu 'Write')
     */
    public static void nioByteorientedWrite(String[] args) {
        Path filePath = Paths.get("output.txt");
        String data = "Hello, this is written using NIO!";

        // FileChannel: Eine offene Verbindung zur Datei. Unterstützt fortgeschrittene IO-Operationen.
        try (FileChannel channel = FileChannel.open(filePath, StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
            // Daten müssen in einen ByteBuffer verpackt werden.
            ByteBuffer buffer = ByteBuffer.wrap(data.getBytes());

            // Schreibt den Inhalt des Buffers in den Channel.
            int bytesWritten = channel.write(buffer);
            System.out.println("Bytes written to file: " + bytesWritten);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Low-Level Byte-Lesen mit expliziter Buffer-Kontrolle.
     * Zeigt den manuellen Umgang mit Buffer-Status (flip, clear).
     */
    public static void nioByteorientedRead(String[] args) {
        Path path = Paths.get("ChuckNorrisFacts.txt");

        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.READ)) {
            // Reserviert 1024 Bytes Speicher für den Puffer.
            ByteBuffer buffer = ByteBuffer.allocate(1024);

            // Liest Bytes vom Channel in den Buffer. Rückgabe -1 bedeutet EOF.
            while (channel.read(buffer) != -1) {
                // flip(): Bereitet den Buffer zum Lesen vor (setzt limit auf position, position auf 0).
                buffer.flip();

                // Verarbeitet die Bytes im Buffer.
                while (buffer.hasRemaining()) {
                    // getChar() liest 2 Bytes als UTF-16 Zeichen.
                    // Bei UTF-8 Textdateien kann das zu falscher Darstellung führen, da ASCII nur 1 Byte braucht.
                    // Korrekter wäre ein CharsetDecoder.
                    System.out.print(buffer.getChar());
                }

                // clear(): Setzt den Buffer zurück, damit er erneut gefüllt werden kann.
                buffer.clear();
            }

        } catch (IOException e) {
            System.err.println("Only Chuck Norris can open this file.");
        }
    }

    /**
     * Iteratives Schreiben von Zeilen auf Byte-Ebene mit FileChannel.
     */
    public static void nioByteWrite(String[] args) {
        List<String> lines = List.of(
                "Chuck Norris only uses stunt doubles for crying scenes.",
                "The universe is not expanding; it is running away from Chuck Norris.",
                "Chuck Norris doesn't use the steering wheel to drive. The road forms where Chuck Norris wants to go.",
                "When Chuck Norris falls into the water, he doesn't get wet. The water becomes Chuck Norris."
        );

        Path path = Paths.get("ChuckNorrisFacts.txt");

        try (FileChannel channel = FileChannel.open(path, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            for (String line : lines) {
                // String in Bytes konvertieren inkl. Zeilenumbruch.
                byte[] lineBytes = (line + System.lineSeparator()).getBytes();
                // ByteBuffer um das Array wickeln.
                ByteBuffer buffer = ByteBuffer.wrap(lineBytes);
                // Buffer in die Datei schreiben.
                channel.write(buffer);
            }
        } catch (IOException e) {
            System.err.println("Only Chuck Norris can write this file.");
        }
    }

    /**
     * Demonstriert und verhindert "Path Traversal Attacks" (Verzeichnis-Übersprung).
     *
     * Szenario:
     * Ein Angreifer versucht, durch Eingabe von "../" (Parent Directory) aus dem erlaubten
     * Verzeichnis (z.B. User Home) auszubrechen, um auf geschützte Dateien (z.B. Passwörter) zuzugreifen.
     *
     * Sicherheitsmechanismus (siehe Folie 16):
     * 1. Pfade zusammenfügen (resolve).
     * 2. Pfad normalisieren (normalize), um ".." und "." aufzulösen.
     * 3. Prüfen, ob der resultierende Pfad noch mit dem erlaubten Basis-Pfad beginnt (startsWith).
     */
    public static void pathTraversal(String[] args) {
        System.out.println("--- Path Traversal Check (Folie 16) ---");

        // Basis-Verzeichnis (z.B. User Home). Hier soll der User eigentlich bleiben.
        Path home = Paths.get(System.getProperty("user.home"));
        System.out.println("Base Directory (Home): " + home);

        // Simulierte bösartige Benutzereingabe.
        // "../.." versucht, zwei Ebenen nach oben zu navigieren (Path Traversal).
        Path inputPath = Paths.get("../../secret/passwords.txt");

        // Schritt 1 & 2: Pfad auflösen und normalisieren.
        // normalize() rechnet die ".." heraus.
        // Ohne normalize() würde der Pfad literal "../.." enthalten und die Prüfung erschweren.
        Path path = home.resolve(inputPath).normalize();
        System.out.println("Normalized Path: " + path);

        // Schritt 3: Sicherheitsüberprüfung.
        // Wenn der aufgelöste Pfad nicht mehr mit dem Basis-Verzeichnis beginnt,
        // hat der Pfad das erlaubte Verzeichnis verlassen.
        if (!path.startsWith(home)) {
            throw new SecurityException("Path traversal attack detected! Access denied to: " + path);
        }

        // Wenn wir hier ankommen, ist der Pfad sicher (er liegt innerhalb von home).
        System.out.println("Access granted to: " + path);
        System.out.println("---------------------------------------");
    }

    /**
     * Hauptmethode zum Testen aller Beispiele entsprechend der Vorlesungsfolien.
     * Die Methoden können je nach Bedarf ein- oder auskommentiert werden.
     */
    public static void main(String[] args) {

        // --- Block 1: Grundlagen IO & Streams ---

        // Folie 10: Einfaches Lesen von Bytes (z.B. Bilder)
        //binaryRead(args);

        // Folie 11: Klassisches java.io (BufferedReader, Legacy Code)
        //java_io(args);


        // --- Block 2: NIO Pfade & Sicherheit ---

        // Folie 16: Path Traversal Attack (Sicherheitsüberprüfung)
        // Hier wird die ausgelagerte Methode aufgerufen.
        pathTraversal(args);


        // --- Block 3: NIO Zeichenorientiert (Text) ---

        // Folie 17: Lesen aller Zeilen in den Speicher (bequem, aber speicherintensiv)
        // nioRead(args);

        // Folie 19: Effizientes Lesen mit Streams (Files.lines)
        // nioReadStream(args);

        // Folie 20: Schreiben einer Liste von Strings in eine Datei
        // nioWrite(args);


        // --- Block 4: NIO Byteorientiert (Channels & Buffers) ---

        // Folie 21: Low-Level Lesen mit FileChannel und Buffer
        // nioByteorientedRead(args);

        // (Ergänzung zu Folie 21/22): Einfaches Schreiben mit Channel
        // nioByteorientedWrite(args);

        // Folie 22: Iteratives Schreiben mit Channel und Buffer
        // nioByteWrite(args);
    }
}