package org.example;

import org.junit.jupiter.api.Test; // Importiert die Test-Annotation
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*; // Importiert Hilfsmethoden wie assertEquals

class CollectionUtilTest {

    // Testfall für die Wildcard-Variante (Kopieren).
    @Test
    void copyNumbersWildcards() {
        // 1. Arrange (Vorbereiten):
        List<Integer> integers = new ArrayList<>(List.of(1, 2, 3));
        List<Number> numbers = new ArrayList<>(List.of(1.1, 2, 3.3f));

        // 2. Act (Ausführen):
        CollectionUtil.copyNumbersWildcards(integers, numbers);

        // 3. Assert (Prüfen):
        List<Number> expected = List.of(1.1, 2, 3.3f, 1, 2, 3);
        assertEquals(expected, numbers);
    }

    // Testfall für die generische Variante (Kopieren).
    @Test
    void copyNumbersGeneric() {
        // 1. Arrange (Vorbereiten):
        // Beide Listen müssen exakt den gleichen Typ haben.
        List<Integer> integers1 = new ArrayList<>(List.of(1, 2, 3));
        List<Integer> integers2 = new ArrayList<>(List.of(4, 5, 6));

        // 2. Act (Ausführen):
        CollectionUtil.copyNumbersGeneric(integers1, integers2);

        // 3. Assert (Prüfen):
        List<Number> expected = List.of(4, 5, 6, 1, 2, 3);
        assertEquals(expected, integers2);
    }

    // Testfall für findMax mit Integern.
    // Integer implementiert in Java bereits das Interface Comparable<Integer>.
    // Daher funktioniert unsere generische Methode hier.
    @Test
    void findMaxInteger() {
        // Arrange: Eine einfache Liste von Zahlen.
        List<Integer> integers = List.of(1, 2, 3);

        // Act: Wir rufen die Stream-Variante auf.
        // T wird hier automatisch zu Integer.
        var actual = CollectionUtil.findMax(integers);

        // Assert: Wir erwarten 3 als größtes Element.
        assertEquals(3, actual);
    }

    // Testfall für findMaxWithoutStream mit Strings.
    // Auch String implementiert Comparable<String> (lexikographische Ordnung, also Alphabet).
    // "c" ist "größer" als "a".
    @Test
    void findMaxString() {
        // Arrange: Eine Liste von Buchstaben/Strings.
        List<String> strings = List.of("a", "b", "c");

        // Act: Wir rufen die klassische Schleifen-Variante auf.
        // T wird hier automatisch zu String.
        var actual = CollectionUtil.findMaxWithoutStream(strings);

        // Assert: Wir erwarten "c", da es im Alphabet am weitesten hinten steht.
        assertEquals("c", actual);
    }

    @Test
    void runAllWithOneRunnable() {
        int[] numberOfEvaluatedCallbacks = {0};
        Iterable<Runnable> runnables = List.of(() -> numberOfEvaluatedCallbacks[0]++); // not pure lambda
        CollectionUtil.runAll(runnables);
        assertEquals(1, numberOfEvaluatedCallbacks[0]);
    }
    @Test
    void runAllWithMultipleRunnables() {
        int[] numberOfEvaluatedCallbacks = {0};
        Runnable counter = () -> numberOfEvaluatedCallbacks[0]++; // not pure lambda
        Iterable<Runnable> runnables = List.of(counter, counter, counter);
        CollectionUtil.runAll(runnables);
        assertEquals(3, numberOfEvaluatedCallbacks[0]);
    }
}