package org.example;

import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Importiert alle statischen Assertions (assertEquals, assertTrue, assertThrows),
// damit wir sie direkt ohne "Assertions." davor aufrufen können.
import static org.junit.jupiter.api.Assertions.*;

class ShuffleUtilTest {

    // Test 1: Funktionalität & Datenintegrität
    // Wir prüfen: Sind nach dem Mischen noch alle Zahlen da? Hat sich die Anzahl geändert?
    @Test
    void shuffleIntegersPreservesElements() {
        // 1. Arrange (Vorbereitung)
        List<Integer> input = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        System.out.println(input);

        // 2. Act (Ausführung)
        Collection<Integer> result = ShuffleUtil.shuffleCollection(input);
        System.out.println(result);

        // 3. Assert (Überprüfung)

        // Prüfung A: Die Größe muss gleich geblieben sein (keine Elemente verloren oder verdoppelt).
        assertEquals(input.size(), result.size(), "Die Größe der Liste sollte sich nicht ändern");

        // Prüfung B: Alle Elemente der Ursprungsliste müssen im Ergebnis enthalten sein.
        // .containsAll() prüft, ob die Menge 'input' komplett in 'result' vorkommt.
        assertTrue(result.containsAll(input), "Es müssen alle ursprünglichen Elemente vorhanden sein");

        // Hinweis: Wir testen hier NICHT explizit, ob die Reihenfolge anders ist.
        // Warum? Zufall ist schwer zu testen. Es besteht eine (winzige) Chance,
        // dass der Zufall die gleiche Reihenfolge generiert. Ein Test, der dann fehlschlägt, wäre "flaky" (unzuverlässig).
    }

    // Test 2: Generics
    // Wir prüfen: Funktioniert die Methode auch mit Doubles, wie es '<T extends Number>' verspricht?
    @Test
    void shuffleWorksWithDoubles() {
        // 1. Arrange
        List<Double> input = List.of(1.5, 2.5, 3.5);

        // 2. Act
        Collection<Double> result = ShuffleUtil.shuffleCollection(input);

        // 3. Assert
        assertEquals(input.size(), result.size());
        assertTrue(result.containsAll(input));
    }

    // Test 3: Immutability (Unveränderbarkeit)
    // Wir prüfen: Wirft die Methode wirklich einen Fehler, wenn man versucht, das Ergebnis zu ändern?
    // Das ersetzt den manuellen try-catch-Block aus der main-Methode.
    @Test
    void resultIsImmutable() {
        // 1. Arrange
        List<Integer> input = List.of(1, 2, 3);
        Collection<Integer> result = ShuffleUtil.shuffleCollection(input);

        // 2. Act & Assert kombiniert
        // assertThrows prüft: "Wenn ich den Code im Lambda-Ausdruck () -> { ... } ausführe,
        // dann MUSS die angegebene Exception (UnsupportedOperationException.class) fliegen."
        assertThrows(UnsupportedOperationException.class, () -> {
            // Dieser Befehl ist verboten, da die Liste "unmodifiable" sein soll.
            result.add(99);
        });
    }
}