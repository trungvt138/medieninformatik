package org.example;

// Import für die Annotation @RepeatedTest aus JUnit 5.
import org.junit.jupiter.api.RepeatedTest;

// Import für Arrays-Hilfsmethoden (z.B. um ein Array in eine Liste zu wandeln).
import java.util.Arrays;

// Statischer Import der Assertions, damit wir direkt 'assertTrue' schreiben können statt 'Assertions.assertTrue'.
import static org.junit.jupiter.api.Assertions.*;

class RandomUtilTest {

    // @RepeatedTest(5) führt diesen Test 5-mal hintereinander aus.
    // Warum? Bei Zufallsfunktionen kann es sein, dass ein Fehler nur selten auftritt.
    // Durch mehrfache Ausführung erhöhen wir die Chance, Fehler zu finden.
    // Das ersetzt die normale @Test Annotation.
    @RepeatedTest(5)
    void randomElement() {

        // Vorbereitung der Testdaten (Arrange).
        // Wir erstellen ein Array von Integern (Objekt-Typ, nicht primitiv int, wegen Generics).
        // 'var' erlaubt dem Compiler, den Typ (Integer[]) selbst zu erkennen.
        var elements = new Integer[]{1, 2, 3, 4, 5};

        // Ausführung der zu testenden Methode (Act).
        // Wir rufen unsere statische Methode auf und übergeben das Array.
        // Der Compiler erkennt hier automatisch, dass T = Integer ist.
        var actual = RandomUtil.randomElement(elements);

        // Überprüfung des Ergebnisses (Assert).
        // Wir müssen prüfen: Ist das zurückgegebene Element ('actual') wirklich Teil des ursprünglichen Arrays?
        // Arrays.asList(elements) wandelt das Array temporär in eine Liste um.
        // .contains(actual) prüft, ob der Wert in dieser Liste enthalten ist.
        // assertTrue(...) lässt den Test bestehen, wenn das Ergebnis 'true' ist, sonst schlägt er fehl.
        assertTrue(Arrays.asList(elements).contains(actual));
    }
}