package org.example;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

// Die Klasse ist 'final', da es eine reine Hilfsklasse (Utility-Klasse) ist und nicht vererbt werden soll.
final class CollectionUtil {

    // Aufgabe Runnable: Implementierung der statischen, generischen Methode runAll.
    // 'static': Die Methode gehört zur Klasse, kein Objekt von CollectionUtil nötig.
    // 'Iterable': Wir nutzen das allgemeinste Interface für Sammlungen (List, Set, etc. erben davon).
    // '<? extends Runnable>': Bounded Wildcard. Akzeptiert eine Sammlung von Runnable oder Unterklassen davon.
    // Das erhöht die Flexibilität beim Aufruf (PECS-Prinzip: Wir lesen nur, also Producer).
    static void runAll(Iterable<? extends Runnable> runnables) {
        // Durchläuft jedes Element im Iterable.
        // 'Runnable::run': Methodenreferenz. Für jedes Element wird die Methode .run() aufgerufen.
        runnables.forEach(Runnable::run);

        // Alternativer Weg (auskommentiert) zur Verdeutlichung der Logik:
        // Hier wird explizit über das Iterable iteriert.
        // for (Runnable runnable : runnables) {
        //    runnable.run(); // Führt die eigentliche Logik des Runnables aus.
        // }
    }

    // Methode 1: Verwendung von Wildcards ('?').
    // Dies ist die flexiblere Variante (PECS-Prinzip: Producer Extends, Consumer Super).
    // 'source': Collection<? extends Number>
    //    - Bedeutet: Eine Liste von 'Number' ODER einer Unterklasse (z.B. Integer, Double).
    //    - Wir WOLLEN nur daraus lesen (Producer), daher ist es egal, welcher spezielle Zahlentyp drin ist.
    // 'target': Collection<? super Number>
    //    - Bedeutet: Eine Liste, die 'Number' aufnehmen kann (also List<Number> oder List<Object>).
    //    - Wir WOLLEN hineinschreiben (Consumer). Da wir 'Number'-Objekte (aus source) reinwerfen,
    //      muss die Ziel-Liste mindestens 'Number' akzeptieren können.
    static void copyNumbersWildcards(Collection<? extends Number> source, Collection<? super Number> target) {
        // Fügt alle Elemente aus der Quell-Liste der Ziel-Liste hinzu.
        // Das funktioniert, weil Java weiß: Alles was aus 'source' kommt, ist mindestens ein 'Number'.
        // Und 'target' ist garantiert eine Liste, die 'Number' speichern darf.
        target.addAll(source);
    }

    // Methode 2: Verwendung eines generischen Typ-Parameters <T>.
    // Dies ist die striktere Variante.
    // '<T extends Number>': Wir definieren einen konkreten Typ T für diesen Aufruf, der Number sein muss.
    // WICHTIG: 'source' UND 'target' müssen beide exakt denselben Typ 'Collection<T>' haben.
    static <T extends Number> void copyNumbersGeneric(Collection<T> source, Collection<T> target) {
        // Die Logik ist dieselbe, aber die Einschränkung an die Parameter ist härter.
        target.addAll(source);
    }

    // Aufgabe findMax: Maximum finden mit Streams (Moderne Variante).
    // '<T extends Comparable<T>>': Das ist ein rekursiver generischer Typ.
    // Es bedeutet: "Der Typ T muss mit sich selbst vergleichbar sein".
    // Das ist zwingend nötig, da wir nicht wissen, ob T ein Integer, String oder Auto ist.
    // Nur wenn T das Interface 'Comparable' implementiert, können wir sagen, was "größer" ist.
    static <T extends Comparable<T>> T findMax(List<T> comparables) {
        return comparables.stream() // Wandelt die Liste in einen Stream (Datenstrom) um.
                // .max(...) sucht das größte Element.
                // Comparable::compareTo ist eine Methodenreferenz. Sie sagt Java:
                // "Benutze die eingebaute Vergleichsfunktion des Objekts T, um zu entscheiden, wer größer ist."
                .max(Comparable::compareTo)
                // Alternativ als Lambda geschrieben: .max((a, b) -> a.compareTo(b))

                // Falls die Liste leer ist, gibt .max() ein "leeres" Ergebnis (Optional) zurück.
                // .orElseThrow() packt den Wert aus, wenn er da ist, oder wirft eine Exception, wenn die Liste leer war.
                .orElseThrow();
    }

    // Aufgabe findMax: Maximum finden "zu Fuß" (Klassische Variante ohne Streams).
    // Die Typsignatur ist identisch zu oben: T muss vergleichbar sein.
    static <T extends Comparable<T>> T findMaxWithoutStream(List<T> comparables) {
        // Schritt 1: Prüfen, ob die Liste leer ist.
        // Das müssen wir hier manuell machen, da wir keinen Stream haben, der das für uns regelt.
        if (comparables.isEmpty()) {
            throw new NoSuchElementException(); // Fehler werfen, da es kein Maximum in einer leeren Liste gibt.
        }

        // Schritt 2: Annahme treffen.
        // Wir nehmen an, das erste Element sei vorläufig das größte.
        T max = comparables.getFirst();

        // Schritt 3: Durch den Rest der Liste iterieren (Schleife).
        for (T element : comparables) {
            // Schritt 4: Vergleichen.
            // Da T ein Objekt ist, können wir nicht '>' (größer als) benutzen (das geht nur bei int, double etc.).
            // Wir nutzen .compareTo(). Die Regel ist:
            // ergebnis > 0 bedeutet: 'element' ist größer als 'max'.
            if (element.compareTo(max) > 0) {
                // Haben wir ein größeres Element gefunden, merken wir uns dieses als neues Maximum.
                max = element;
            }
        }
        // Am Ende der Schleife geben wir den Gewinner zurück.
        return max;
    }

    public static void main(String[] args) {
        // Vorbereitung: Wir erstellen eine Liste nur mit Integern (Unterklasse von Number).
        // WICHTIG: 'new ArrayList<>(...)' ist notwendig, damit die Liste veränderbar ist.
        // 'List.of' allein erzeugt eine unveränderliche Liste (Immutable), die wir später nicht füllen könnten.
        List<Integer> integers = new ArrayList<>(List.of(1, 2, 3));

        // Vorbereitung: Wir erstellen eine allgemeinere Liste für Numbers (kann Ints, Doubles etc. aufnehmen).
        List<Number> numbers = new ArrayList<>(List.of(1.1, 2, 3.3f));

        // Szenario A: Aufruf mit Wildcards
        // Hier kopieren wir von List<Integer> (source) nach List<Number> (target).
        // Das klappt, weil Integer "extends" Number ist und Number "super" Number ist.
        copyNumbersWildcards(integers, numbers);

        // Szenario B: Aufruf mit Generic Method
        // Hier versuchen wir dasselbe: copy List<Integer> to List<Number>.
        // DAS KOMPILIERT NICHT! (Daher auskommentiert oder Fehler im Code).
        // Grund: Der Compiler muss sich für EIN 'T' entscheiden.
        // - Wäre T = Integer, müsste 'target' auch List<Integer> sein (ist aber List<Number>).
        // - Wäre T = Number, müsste 'source' auch List<Number> sein (ist aber List<Integer>).
        // Da die Typen unterschiedlich sind, scheitert diese Methode.

        // copyNumbersGeneric(integers, numbers); // does not compile

        // Aufgabe Runnable: Verwendung von runAll.
        // Wir erstellen eine Liste von Objekten, die das Runnable-Interface implementieren.
        // Da Runnable ein "Functional Interface" ist (hat nur die Methode run()),
        // können wir Lambda-Ausdrücke () -> ... verwenden.
        Iterable<Runnable> runnables = List.of(
                () -> System.out.println("Hallo"), // Erstes Runnable: Druckt "Hallo"
                () -> System.out.println("Welt!")  // Zweites Runnable: Druckt "Welt!"
        );

        // Aufruf der statischen Methode runAll.
        // Übergabe der Liste. Die Methode iteriert nun intern und führt für jeden Eintrag .run() aus,
        // was die System.out.println Befehle auslöst.
        runAll(runnables);
    }
}