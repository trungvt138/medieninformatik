package org.example;

import java.util.*;

// Die Klasse ist 'final', typisch für Utility-Klassen, damit niemand davon erben kann.
final class ShuffleUtil {

    // Ein statischer Zufallsgenerator.
    // 'static': Wird einmalig für die ganze Klasse erstellt (spart Speicher im Vergleich zu 'pro Methodenaufruf').
    // 'final': Die Referenz auf das Random-Objekt ändert sich nicht mehr.
    private static final Random RANDOM = new Random();

    // Die Hauptmethode zum Mischen.
    // '<T extends Number>': Wir definieren einen Typ T. Dieser MUSS eine Zahl sein (Integer, Double, etc.).
    // 'Collection<T>': Wir nehmen eine beliebige Sammlung (Set, List, Queue) von Zahlen entgegen.
    static <T extends Number> Collection<T> shuffleCollection(Collection<T> collection) {

        // 1. Kopie erstellen & Typ umwandeln.
        // Der Input ist nur eine 'Collection' (hat keinen Index). Zum Mischen brauchen wir aber Positionen (0, 1, 2...).
        // Deshalb kopieren wir alles in eine 'LinkedList' (eine Implementierung von List).
        // Nebeneffekt: Das Original 'collection' bleibt unberührt (wichtig, da wir eine NEUE Collection zurückgeben sollen).
        List<T> result = new LinkedList<>(collection);

        // 2. Der Misch-Algorithmus (Fisher-Yates Shuffle).
        // Wir laufen von hinten (letztes Element) nach vorne durch die Liste.
        for (int i = result.size() - 1; i > 0; i--) {

            // Wähle einen zufälligen Index 'j'.
            // nextInt(bound) liefert eine Zahl von 0 bis bound-1.
            // Durch 'i + 1' erhalten wir eine Zufallszahl zwischen 0 und i (inklusive).
            // Das heißt: Wir tauschen das Element an Stelle 'i' mit irgendeinem davor (oder sich selbst).
            int j = RANDOM.nextInt(i + 1);

            // Führe den Tausch durch.
            swap(result, i, j);
        }

        // 3. Unveränderbar machen (Immutable).
        // Die Aufgabe verlangt eine immutable Collection.
        // Dieser Wrapper verhindert Schreibzugriffe (add, remove) von außen -> wirft UnsupportedOperationException.
        return Collections.unmodifiableList(result);
    }

    // Eine generische Hilfsmethode zum Tauschen von zwei Elementen in einer Liste.
    // Hier reicht '<T>' ohne 'extends Number', da Tauschen für alle Objekttypen gleich funktioniert.
    // 'private', da diese Methode nur intern von shuffleCollection genutzt wird.
    private static <T> void swap(List<T> list, int i, int j) {
        // Klassischer Dreieckstausch:
        // 1. Wert von i in temporärer Variable sichern.
        T temp = list.get(i);

        // 2. Wert von j an die Stelle von i schreiben.
        list.set(i, list.get(j));

        // 3. Den gesicherten Wert (temp) an die Stelle von j schreiben.
        list.set(j, temp);
    }


}