package org.example;

import java.util.Random; // Importiert die Klasse Random, um Zufallszahlen zu generieren.

// Die Klasse ist 'final', damit niemand davon erben kann.
// Das ist typisch für Utility-Klassen, die nur statische Hilfsmethoden enthalten.
final class RandomUtil {

    // Eine einzige, statische Instanz des Zufallsgenerators.
    // 'static': Diese Variable gehört zur Klasse, nicht zu einem Objekt. Sie wird wiederverwendet.
    // 'final': Die Variable RANDOM kann nicht neu zugewiesen werden.
    // 'private': Nur innerhalb dieser Klasse sichtbar.
    private static final Random RANDOM = new Random();

    // Definition einer generischen Methode.
    // '<T>': Das ist der Typparameter (Platzhalter). Er sagt dem Compiler: "Hier kommt gleich ein Typ, den wir T nennen".
    // 'T' (der zweite): Das ist der Rückgabetyp der Methode. Sie gibt ein Element vom Typ T zurück.
    // 'T[] elements': Der Parameter ist ein Array, das Elemente vom Typ T enthält.
    // Beispiel: Wenn T ein String ist, muss ein String-Array rein und ein String kommt raus.
    static <T> T randomElement(T[] elements) {

        // Erzeugt eine zufällige Ganzzahl (Integer).
        // nextInt(bound) liefert eine Zahl von 0 (inklusive) bis bound (exklusive).
        // Wir nutzen 'elements.length' als Grenze, damit der Index immer innerhalb des Arrays liegt (0 bis Länge-1).
        int randomIndex = RANDOM.nextInt(elements.length);

        // Zugriff auf das Array an der zufällig ermittelten Stelle.
        // Gibt das gefundene Element zurück an den Aufrufer.
        return elements[randomIndex];
    }
}