package refactoring.animalfarm_v2;

import refactoring.animalfarm_v2.animals.Animal;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

class FreelandOrganicHappyAnimalFarm {

    private final List<Animal> animals = new ArrayList<>();

    public boolean add(Animal animal) {
        return animals.add(animal);
    }

    public int numberOfDifferentAnimals() {
        var types = animals.stream().map(Animal::getType).toList();
        return new HashSet<>(types).size();
    }

    public double requiredSpaceInSquareMeters() {
        return animals.stream()
            .mapToDouble(Animal::requiredSpaceInSquareMeters)
            .sum();
    }

    public boolean containsWaterAnimals() {
        return animals.stream().anyMatch(Animal::isWaterAnimal);
    }

    public boolean containsLandAnimals() {
        return animals.stream().anyMatch(Animal::isLandAnimal);
    }
}