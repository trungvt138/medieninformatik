package refactoring.animalfarm_v2.animals;

public class Kangaroo implements Animal {

    @Override
    public double requiredSpaceInSquareMeters() {
        return 250;
    }

    @Override
    public boolean isLandAnimal() {
        return true;
    }
}