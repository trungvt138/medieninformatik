package refactoring.animalfarm_v2.animals;

public class Crocodile implements Animal {

    @Override
    public double requiredSpaceInSquareMeters() {
        return 100;
    }

    @Override
    public boolean isLandAnimal() {
        return false;
    }
}