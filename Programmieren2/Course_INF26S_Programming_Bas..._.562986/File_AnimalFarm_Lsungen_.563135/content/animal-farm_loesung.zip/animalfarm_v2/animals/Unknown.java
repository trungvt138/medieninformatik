package refactoring.animalfarm_v2.animals;

public class Unknown implements Animal {

    @Override
    public double requiredSpaceInSquareMeters() {
        return 1;
    }

    @Override
    public boolean isLandAnimal() {
        return true;
    }
}