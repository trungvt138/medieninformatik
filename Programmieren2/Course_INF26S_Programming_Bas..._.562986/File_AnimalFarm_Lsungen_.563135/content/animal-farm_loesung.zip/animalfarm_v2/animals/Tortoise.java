package refactoring.animalfarm_v2.animals;

public class Tortoise implements Animal {

    @Override
    public double requiredSpaceInSquareMeters() {
        return 10;
    }

    @Override
    public boolean isLandAnimal() {
        return false;
    }
}