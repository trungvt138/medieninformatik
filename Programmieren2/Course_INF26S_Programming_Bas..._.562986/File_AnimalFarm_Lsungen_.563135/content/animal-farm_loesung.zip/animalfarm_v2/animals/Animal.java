package refactoring.animalfarm_v2.animals;

public interface Animal {

    double requiredSpaceInSquareMeters();

    boolean isLandAnimal();

    default boolean isWaterAnimal() {
        return !isLandAnimal();
    }

    default String getType() {
        return this.getClass().getName();
    }
}