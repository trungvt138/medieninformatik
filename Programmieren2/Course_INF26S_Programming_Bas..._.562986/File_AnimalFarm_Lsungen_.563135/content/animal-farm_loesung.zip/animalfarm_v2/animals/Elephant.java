package refactoring.animalfarm_v2.animals;

public class Elephant implements Animal {

    @Override
    public double requiredSpaceInSquareMeters() {
        return 1000;
    }

    @Override
    public boolean isLandAnimal() {
        return true;
    }
}