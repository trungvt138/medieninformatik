package refactoring.animalfarm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

class FreelandOrganicHappyAnimalFarm {

    private final List<Integer> animalsIds = new ArrayList<>();

    public boolean add(int animalId) {
        return animalsIds.add(animalId);
    }

    public int numberOfDifferentAnimals() {
        return new HashSet<>(animalsIds).size();
    }

    public double requiredSpaceInSquareMeters() {
        int sum = 0;
        for (int animalsId : animalsIds) {
            sum += switch (animalsId) {
                case 1 -> 1000; // Elephant
                case 2 -> 100; // Crocodile
                case 3 -> 250; // Kangaroo
                case 4 -> 10; // Tortoise
                default -> 1; // Unknown
            };
        }
        return sum;
    }

    public boolean containsWaterAnimals() {
        var result = false;
        for (int animalsId : animalsIds) {
            result |= switch (animalsId) {
                case 1 -> false; // Elephant
                case 2 -> true; // Crocodile
                case 3 -> false; // Kangaroo
                case 4 -> true; // Tortoise
                default -> false; // Unknown
            };
        }
        return result;
    }

    public boolean containsLandAnimals() {
        var result = false;
        for (int animalsId : animalsIds) {
            result |= switch (animalsId) {
                case 1 -> true; // Elephant
                case 2 -> false; // Crocodile
                case 3 -> true; // Kangaroo
                case 4 -> false; // Tortoise
                default -> true; // Unknown
            };
        }
        return result;
    }
}