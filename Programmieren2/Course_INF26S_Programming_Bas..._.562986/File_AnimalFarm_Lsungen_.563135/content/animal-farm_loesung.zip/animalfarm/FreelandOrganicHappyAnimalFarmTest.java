package refactoring.animalfarm;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FreelandOrganicHappyAnimalFarmTest {

    private static final double TOLERANCE = 0.0000000001;

    private static final int ELEPHANT_ID = 1;
    private static final int CROCODILE_ID = 2;
    private static final int KANGAROO_ID = 3;
    private static final int TORTOISE_ID = 4;
    private static final int UNKNOWN_ANIMAL_ID = 5;

    private FreelandOrganicHappyAnimalFarm farm;

    @BeforeEach
    void setUp() {
        farm = new FreelandOrganicHappyAnimalFarm();
    }

    @Test
    void addValidAnimal() {
        // Arrange
        boolean added = farm.add(ELEPHANT_ID);

        // Act
        int numberOfAnimals = farm.numberOfDifferentAnimals();

        // Assert
        assertTrue(added);
        assertEquals(1, numberOfAnimals);
    }

    @Test
    void numberOfDifferentAnimals() {
        // Arrange
        farm.add(ELEPHANT_ID);
        farm.add(ELEPHANT_ID);
        farm.add(ELEPHANT_ID);
        farm.add(CROCODILE_ID);
        farm.add(CROCODILE_ID);
        farm.add(KANGAROO_ID);

        // Act
        int numberOfAnimals = farm.numberOfDifferentAnimals();

        // Assert
        assertEquals(3, numberOfAnimals);
    }

    @Test
    void requiredSpaceInSquareMeters() {
        // Arrange
        farm.add(ELEPHANT_ID);
        farm.add(CROCODILE_ID);
        farm.add(KANGAROO_ID);
        farm.add(TORTOISE_ID);

        // Act
        double requiredSpace = farm.requiredSpaceInSquareMeters();

        // Assert
        assertEquals(1360, requiredSpace);
    }

    @Test
    void requiredSpaceInSquareMetersWhenEmpty() {
        // Act
        double requiredSpace = farm.requiredSpaceInSquareMeters();

        // Assert
        assertEquals(0, requiredSpace, TOLERANCE);
    }


    @Test
    void containsAtLeastOneWaterAnimal() {
        // Arrange
        farm.add(ELEPHANT_ID);
        farm.add(CROCODILE_ID);
        farm.add(KANGAROO_ID);

        // Act
        boolean containsWaterAnimals = farm.containsWaterAnimals();

        // Assert
        assertTrue(containsWaterAnimals);
    }

    @Test
    void containsNoWaterAnimal() {
        // Arrange
        farm.add(ELEPHANT_ID);
        farm.add(KANGAROO_ID);

        // Act
        boolean containsWaterAnimals = farm.containsWaterAnimals();

        // Assert
        assertFalse(containsWaterAnimals);
    }

    @Test
    void containsAtLeastOneLandAnimals() {
        // Arrange
        farm.add(ELEPHANT_ID);
        farm.add(KANGAROO_ID);
        farm.add(TORTOISE_ID);

        // Act
        boolean containsLandAnimals = farm.containsLandAnimals();

        // Assert
        assertTrue(containsLandAnimals);
    }

    @Test
    void containsNoLandAnimals() {
        // Arrange
        farm.add(TORTOISE_ID);

        // Act
        boolean containsLandAnimals = farm.containsLandAnimals();

        // Assert
        assertFalse(containsLandAnimals);
    }

    @Test
    void unknownAnimalsCanBeAdded() {
        // Arrange
        boolean added = farm.add(UNKNOWN_ANIMAL_ID);

        // Act
        int numberOfAnimals = farm.numberOfDifferentAnimals();

        // Assert
        assertTrue(added);
        assertEquals(1, numberOfAnimals);
    }

    @Test
    void unknownAnimalsRequireDefaultSpace() {
        // Arrange
        boolean added = farm.add(UNKNOWN_ANIMAL_ID);

        // Act
        double actual = farm.requiredSpaceInSquareMeters();

        // Assert
        assertTrue(added);
        assertEquals(1, actual);
    }

    @Test
    void unknownAnimalsAreNoWaterAnimals() {
        // Arrange
        farm.add(UNKNOWN_ANIMAL_ID);

        // Act
        boolean containsWaterAnimals = farm.containsWaterAnimals();

        // Assert
        assertFalse(containsWaterAnimals);
    }

    @Test
    void unknownAnimalsAreLandAnimalsByDefault() {
        // Arrange
        farm.add(UNKNOWN_ANIMAL_ID);

        // Act
        boolean containsLandAnimals = farm.containsLandAnimals();

        // Assert
        assertTrue(containsLandAnimals);
    }

    @Test
    void unknownAnimalsAreNoWaterAnimalsByDefault() {
        // Arrange
        farm.add(UNKNOWN_ANIMAL_ID);

        // Act
        boolean containsWaterAnimals = farm.containsWaterAnimals();

        // Assert
        assertFalse(containsWaterAnimals);
    }
}