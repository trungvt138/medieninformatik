package org.example;

import java.util.*;

// Implementiert die Aufgabe "Finde Duplikate" aus dem Optional-Dokument.
class DuplicateFinder {

    // Eine statische Map zur Speicherung der Worthäufigkeit.
    // Diese wird von den statischen Hilfsmethoden 'numberOfOccurrences' und 'duplicateDetected' verwendet.
    private static Map<String, Integer> frequencyMap;

    /**
     * HINWEIS ZUM RÜCKGABETYP (im Vgl. zu anderen Optional-Aufgaben):
     * Der Rückgabetyp ist 'Collection<String>', NICHT 'Optional<Collection<String>>'.
     * Wie im Hinweis der Aufgabe erwähnt, ist es Konvention, eine *leere Collection*
     * zurückzugeben, wenn keine Duplikate gefunden werden. 'Optional' wird hier
     * nicht für Collections verwendet (anders als bei 'findByName', wo ein
     * einzelnes Objekt gesucht wurde).
     */
    static Collection<String> findDuplicates(Collection<String> words) {

        // Ein Set wird verwendet, damit jedes Duplikat nur einmal im Ergebnis erscheint
        // (z.B. wenn "apple" 3x vorkommt, soll es nur 1x im Ergebnis sein).
        Set<String> result = new HashSet<>();

        // Die Map wird bei jedem Aufruf neu initialisiert.
        frequencyMap = new HashMap<>();

        // HINWEIS ZUM VERGLEICH MIT DER EXCEPTION-AUFGABE:
        // Im Gegensatz zur "Average Exception"-Aufgabe wird hier KEINE Exception
        // für eine leere 'words'-Collection geworfen. Eine leere Collection
        // ist hier ein gültiger Anwendungsfall (sie enthält 0 Duplikate)
        // und führt korrekt zu einem leeren 'result'-Set.
        for (String word : words) {
            // Erhöht den Zähler für das aktuelle Wort in der Map.
            frequencyMap.put(word, numberOfOccurrences(word) + 1);

            // Prüft, ob das Wort ein Duplikat ist.
            if (duplicateDetected(word)) {
                result.add(word);
            }
        }
        // Gibt das Set mit den gefundenen Duplikaten zurück.
        return result;
    }

    // Private Hilfsmethode, um die aktuelle Anzahl eines Wortes abzurufen.
    private static Integer numberOfOccurrences(String word) {
        // 'getOrDefault' gibt 0 zurück, falls das Wort noch nicht in der Map ist.
        return frequencyMap.getOrDefault(word, 0);
    }

    // Private Hilfsmethode, die prüft, ob ein Wort *genau* zum zweiten Mal auftaucht.
    private static boolean duplicateDetected(String word) {
        // Fügt das Wort dem Set hinzu, exakt wenn der Zähler 2 erreicht.
        // Wenn ein Wort 3x vorkommt, wird es bei Zähler 3 nicht erneut hinzugefügt
        // (was dank des 'Set' auch nicht nötig wäre).
        return frequencyMap.get(word) == 2;
    }

    // Die 'main'-Methode, die beide Fälle (mit und ohne Duplikate) testet,
    // wie in der Aufgabe gefordert.
    static void main(String[] args) {
        // Fall 1: Aufruf mit Duplikaten.
        var withDuplicates = List.of("apple", "banana", "apple", "orange", "banana", "grape");
        System.out.println(findDuplicates(withDuplicates)); // Erwartete Ausgabe: [apple, banana] (Reihenfolge kann variieren)

        // Fall 2: Aufruf ohne Duplikate.
        var noDuplicates = List.of("apple", "banana", "orange", "grape");
        System.out.println(findDuplicates(noDuplicates)); // Erwartete Ausgabe: []
    }
}