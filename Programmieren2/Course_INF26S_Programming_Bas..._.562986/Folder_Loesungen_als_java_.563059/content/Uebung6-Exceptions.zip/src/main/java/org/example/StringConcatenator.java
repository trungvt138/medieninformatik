package org.example;

class StringConcatenator {
    // Definition einer statischen Methode, die zwei Strings als Parameter akzeptiert.
    static String concat(String str1, String str2) {
        // Prüfung, ob einer der Eingabestrings null ist.
        if (str1 == null || str2 == null) {
            // Werfen einer NullPointerException, falls einer der Parameter null ist.
            throw new NullPointerException("Parameter cannot be null");
        }
        // Rückgabe der verketteten Strings.
        return str1 + str2;
    }
}