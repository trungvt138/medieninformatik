package org.example;

// Erstellt die eigene 'Checked Exception', da sie von 'Exception' erbt
// (und nicht von 'RuntimeException').
class NotANumberException extends Exception {

    // Ein Konstruktor, der die Fehlermeldung (den fehlerhaften String) annimmt.
    public NotANumberException(String message) {
        // Leitet die Nachricht an die übergeordnete 'Exception'-Klasse weiter.
        super(message);
    }
}