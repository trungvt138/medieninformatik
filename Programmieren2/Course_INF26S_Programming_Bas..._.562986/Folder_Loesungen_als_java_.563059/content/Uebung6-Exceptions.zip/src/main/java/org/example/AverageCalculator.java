package org.example;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public class AverageCalculator {

    // Diese Methode 'calculateAverage' entspricht der Aufgabe "Average Exception" (aus dem Exceptions-Dokument).
    // Sie soll bei einer leeren Liste eine Exception werfen.
    public static double calculateAverage(Collection<Integer> numbers) {
        // Schritt 1: Precondition / Fail Fast
        // Prüfung, ob die Collection leer ist (oder null), wie in der Exception-Aufgabe gefordert.
        if (numbers == null || numbers.isEmpty()) {
            // Wirft die geforderte IllegalArgumentException, wenn die Bedingung zutrifft.
            throw new IllegalArgumentException("Collection darf nicht null oder leer sein.");
        }
        // Schritt 2: "Happy Path"
        return numbers.stream()
                .mapToInt(n -> n) // .mapToInt(n -> n) wandelt den Stream um Diese Methode konvertiert den Stream<Integer> (Objekte) in einen IntStream (primitive int-Werte).
                // Der Ausdruck n -> n führt dabei das sogenannte Unboxing durch (wandelt das Integer-Objekt in einen int-Wert um).
                .average() // nur auf primitiven Streams (gibt OptionalDouble zurück)
                .getAsDouble(); // Achtung: Wirft Exception, wenn leer!
        // Funktioniert hier nur sicher, da der 'isEmpty'-Check oben leere Listen abfängt.
        // .getAsDouble() holt den rohen double-Wert aus einem OptionalDouble-Container heraus. Stellt euch die .average()-Methode so vor: Sie versucht, einen Durchschnitt zu berechnen. Das Ergebnis verpackt sie in eine Box (ein OptionalDouble), die entweder den Wert enthält oder leer ist.
    }

    // Diese Methode 'calculateAverageOptional' entspricht der Aufgabe "Average Optional" (aus dem Optional-Dokument).
    // Sie soll bei einer leeren Liste ein Optional.empty zurückgeben.
    public static Optional<Double> calculateAverageOptional(Collection<Integer> numbers) {
        // Schritt 1: "Fehlerfall" ist jetzt ein "erwartbarer Fall"
        // Prüfung, ob die Collection leer ist, wie in der Optional-Aufgabe gefordert.
        if (numbers == null || numbers.isEmpty()) {
            // Gibt ein leeres Optional zurück, statt eine Exception zu werfen.
            return Optional.empty(); // Kein Fehler, nur "kein Ergebnis"
        }
        // Schritt 2: "Happy Path" - Ergebnis in Optional packen
        // Die Berechnung ist dieselbe wie oben.
        double avg = numbers.stream()
                .mapToInt(n -> n)
                .average()
                .getAsDouble(); // Sicher, da leere Listen oben behandelt wurden.
        // Das berechnete Ergebnis wird in ein Optional verpackt.
        return Optional.of(avg);
    }

    public static void main(String[] args) {

        // Ausgabe für Aufgabe 3: Exceptions - Average Exception:
        // Hier wird der Aufruf der 'calculateAverage'-Methode (Exception-Aufgabe) demonstriert.
        List<Integer> list1 = List.of(1, 2, 3, 4, 5);

        System.out.println("Berechne Durchschnitt von list1...");
        double avg1 = calculateAverage(list1); // Erfolgreicher Fall
        System.out.println("Ergebnis: " + avg1); // Ergibt 3.0

        List<Integer> list2 = List.of(); // Leere Liste für den Fehlerfall
        System.out.println("\nBerechne Durchschnitt von list2...");
        // Wir wissen schon, dass es einen Fehler werfen wird und anstatt das Programm abstürzen zu lassen verwenden wir try und catch
        try {
            // Dieser Aufruf wird die 'IllegalArgumentException' auslösen.
            double avg2 = calculateAverage(list2);
            System.out.println("Ergebnis: " + avg2);
        } catch (IllegalArgumentException e) { // Fangen wir die spezifische Exception
            // Das Programm stürzt nicht ab, sondern gibt die Fehlermeldung aus.
            System.err.println("Kontrollierter Fehler: " + e.getMessage());
        }

        // Ausgabe für Aufgabe 1: Optional - Average Optional:
        // Hier wird der Aufruf der 'calculateAverageOptional'-Methode (Optional-Aufgabe) demonstriert.

        // --- Neuer Aufruf mit Optional ---
        System.out.println("\n--- Mit Optional ---");
        List<Integer> list3 = List.of(10, 20, 30); // Ergibt 20.0
        List<Integer> list4 = List.of();           // Ergibt "empty"

        // Fall 1: Wert vorhanden (nicht-leere Liste)
        Optional<Double> avg3 = calculateAverageOptional(list3);
        System.out.println("Ergebnis 3 (Optional): " + avg3); // Gibt Optional[20.0] aus
        // Sicherer Zugriff mit .orElse() - entspricht der Ausgabe in der Lösung der Optional-Aufgabe.
        System.out.println("Ergebnis 3 (Default): " + avg3.orElse(0.0)); // Gibt 20.0 aus

        // Fall 2: Wert nicht vorhanden (leere Liste)
        Optional<Double> avg4 = calculateAverageOptional(list4);
        System.out.println("Ergebnis 4 (Optional): " + avg4); // Gibt Optional.empty aus
        // .orElse() liefert den Standardwert, wenn das Optional leer ist.
        System.out.println("Ergebnis 4 (Default): " + avg4.orElse(0.0)); // Gibt 0.0 aus

        // Eleganter Zugriff mit ifPresent
        // Führt die Aktion nur aus, WENN ein Wert im Optional vorhanden ist.
        avg3.ifPresent(val -> System.out.println("Durchschnitt ist " + val));
        // Hier ist das Optional (avg4) leer, daher wird der Code im Lambda nicht ausgeführt.
        avg4.ifPresent(val -> System.out.println("Das hier wird nicht gedruckt."));

    }
}