package org.example;

class NumberConverter {
    // Statische Methode 'toDouble'.
    // Sie deklariert, dass sie eine 'NotANumberException' werfen kann (eine Checked Exception).
    static double toDouble(String number) throws NotANumberException {
        try {
            // Versucht, den String mit der Standard-Java-Methode 'parseDouble' umzuwandeln.
            return Double.parseDouble(number);
        } catch (NumberFormatException e) {
            // Fängt die Standard-Java-Exception 'NumberFormatException' ab.
            // Wandelt die 'NumberFormatException' in die geforderte, eigene 'NotANumberException' um.
            throw new NotANumberException(number);
        }
    }

    // Hilfsmethode (nicht explizit gefordert, aber nützlich), um die Aufrufe in 'main' zu kapseln.
    private static void printNumber(String number) {
        try {
            // Ruft die 'toDouble'-Methode auf. Da 'NotANumberException' eine Checked Exception ist,
            // muss der Aufruf in einem try-Block erfolgen (oder die 'printNumber'-Methode
            // müsste selbst 'throws NotANumberException' deklarieren).
            System.out.println(toDouble(number));
        } catch (NotANumberException e) {
            // Fängt die eigene Exception ab und gibt das Ergebnis in der Konsole aus.
            System.err.println("Cannot convert number: " + e.getMessage());
        }
    }

    // Die 'main'-Methode, die die Methode für beide Fälle aufruft.
    static void main(String[] args) {
        // Aufruf für den "Exception-Fall".
        printNumber("a1");
        // Aufruf für den "ohne Exception-Fall".
        printNumber("5.5");
    }
}