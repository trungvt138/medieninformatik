package org.example;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

// Diese Klasse implementiert die "Find Student ID" Aufgabe.
class StudentFinder {

    /**
     * Die statische Methode, die laut Aufgabe implementiert werden soll.
     * Sie gibt ein Optional<Student> zurück, da der Student evtl. nicht gefunden wird.
     */
    static Optional<Student> findByName(Collection<Student> students, String studentName) {
        return students.stream()
                // Filtert die Studenten.
                // .equalsIgnoreCase erfüllt die Anforderung, Groß- und Kleinschreibung zu ignorieren.
                .filter(student -> student.name().equalsIgnoreCase(studentName))
                // Gibt den ersten Treffer zurück, wie von der Aufgabe gefordert.
                // Gibt Optional.empty() zurück, wenn der Filter keinen Studenten findet.
                .findFirst();
    }

    // Die main-Methode, die die 'findByName'-Methode aufruft.
    static void main(String[] args) {
        // Testdaten-Setup
        var students = List.of(
                new Student(1, "Grace"),
                new Student(2, "Bob")
        );

        // Aufruf der Methode.
        Optional<Student> student = findByName(students, "grace");

        // --- PROBLEM-BESCHREIBUNG (Bezugnehmend auf "Value of parameter 'studentName' is always '"grace"' ") ---
        //
        // Das Problem hier ist, dass der Parameter 'studentName' (im Code "grace")
        // immer denselben, hartkodierten Wert hat.
        //
        // Diese 'main'-Methode testet dadurch nur einen einzigen Fall: den "Happy Path",
        // bei dem ein Student erfolgreich gefunden wird (und die Groß-/Kleinschreibung ignoriert wird).
        //
        // Sie testet jedoch NIE den alternativen Fall, also was passiert,
        // wenn ein Student *nicht* gefunden wird.
        //
        // Dadurch wird die Logik im ".orElse("Student id not found.")"-Teil
        // von 'getIdOrDefault' nie ausgeführt oder demonstriert.
        // Für eine vollständige Demonstration sollte auch ein Fall wie
        // 'findByName(students, "Ada")' getestet werden.

        System.out.println(getIdOrDefault(student)); // Gibt "1" aus
    }

    /**
     * Private Hilfsmethode, um die Ausgabeanforderung umzusetzen:
     * "Gebe die id... aus, oder, falls nicht vorhanden 'Student id not found.'".
     */
    private static String getIdOrDefault(Optional<Student> student) {
        // .map wandelt das Optional<Student> in ein Optional<String> (mit der ID) um,
        // falls es nicht leer ist.
        return student.map(s -> String.valueOf(s.id()))
                // .orElse gibt den Standardtext zurück, falls das Optional leer war (Student nicht gefunden).
                .orElse("Student id not found.");
    }
}