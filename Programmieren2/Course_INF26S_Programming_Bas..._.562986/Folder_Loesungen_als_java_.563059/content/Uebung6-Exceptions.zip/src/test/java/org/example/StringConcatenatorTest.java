package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Unit-Tests für die StringConcatenator-Klasse, um 100% Abdeckung zu erreichen.
class StringConcatenatorTest {
    @Test // Testet den Fall, bei dem beide Strings gültig (nicht-null) sind.
    void testConcatWithNonNullStrings() {
        String result = StringConcatenator.concat("Hello", "World");
        assertEquals("HelloWorld", result);
    }
    @Test // Testet, ob eine NullPointerException geworfen wird, wenn der erste String null ist.
    void testConcatWithFirstStringNull() {
        // Prüft, ob der Lambda-Ausdruck (der den concat-Aufruf ausführt) wie erwartet eine NullPointerException wirft.
        assertThrows(NullPointerException.class, () -> StringConcatenator.concat(null, "World"));
    }
    @Test // Alternative Schreibweise
    void testConcatWithSecondStringNull() {
        try {
            // 1. Versuche, den Code auszuführen, der die Exception werfen SOLL.
            StringConcatenator.concat("Hello", null);

            // 2. Wenn der Code diese Zeile erreicht, wurde KEINE Exception geworfen.
            //    Das ist ein Fehler, also lassen wir den Test manuell fehlschlagen.
            fail("Die erwartete NullPointerException wurde nicht geworfen.");

        } catch (NullPointerException e) {
            // 3. Die erwartete Exception wurde gefangen.
            //    Das ist das korrekte Verhalten, also tun wir nichts.
            //    Der Test wird erfolgreich beendet.
        }
    }
    @Test // Testet, ob eine NullPointerException geworfen wird, wenn beide Strings null sind.
    void testConcatWithBothStringsNull() {
        assertThrows(NullPointerException.class, () -> StringConcatenator.concat(null, null));
    }
}