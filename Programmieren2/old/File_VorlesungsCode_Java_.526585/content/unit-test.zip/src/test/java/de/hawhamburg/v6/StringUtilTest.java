package de.hawhamburg.v6;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StringUtilTest {

    @Test // Testfall
    void countCharacters() {
        int actual = StringUtil.countCharacters("Andre");
        assertEquals(5, actual, 0.00000000001);
    }
}