package de.hawhamburg.v5;

import org.junit.jupiter.api.Test; //ju5

import static org.junit.jupiter.api.Assertions.assertEquals; //ju5

class CalculatorTest { // testklassen, testcode

    Calculator calculator = new Calculator(); // Attribute wird bei jedem Testfall neu zugewiesen

    @Test // testfall
    void addingTwoNumbersReturnTheCorrectResult() {
        // Arrange (given)
        Calculator calculator = new Calculator();

        // Act (when) (Aufruf der Methode, die man testen moechte)
        int actual = calculator.addition(1, 2);

        // Assert (then)
        assertEquals(3, actual);
    }

    @Test // testfall
    void addingTwoNumbersWithOneBeingNegativeReturnTheCorrectResult() {
        int result = calculator.addition(-3, 5);
        assertEquals(2, result);
    }

    @Test // testfall
    void addLastA() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }

    @Test // testfall
    void addLastC() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }

    @Test // testfall
    void addLastB() {
        int result = calculator.addLast(1);
        assertEquals(1, result);
    }

    @Test // testfall
    void addLastWithNegativeNumber() {
        int result = calculator.addLast(-1);
        assertEquals(0, result);
    }

    @Test
    void addDoubles() {
        double actual = calculator.addition(0.1, 0.2);
        assertEquals(0.3, actual, 0.0000001);
    }


}
