package de.hawhamburg.v6;

class StringUtil {

    static int countCharacters2(String string) {
        return string.length();
    }

    static int countCharacters(String string) {
        return string.getBytes().length;
    }
}