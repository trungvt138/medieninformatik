package de.hawhamburg.v5;

import static de.hawhamburg.v5.Calculator.printNumber;

class Student {

    String name;
    String matricelNumber;

    String name() {
        return name;
    }

    void setName(String name) {
        this.name = name;
    }

    String matricelNumber() {
        return matricelNumber;
    }

    void setMatricelNumber(String matricelNumber) {
        this.matricelNumber = matricelNumber;
    }

    Student(int age) {
        printNumber(age);
        sleep();
    }

    void sleep() {

    }
}
