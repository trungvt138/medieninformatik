package de.hawhamburg.v5;

class Calculator { // production code

    private int lastValue = 0;

    static void printNumber(int number) {
        IO.println(number);
    }

    int addition(int a, int b) {
        return a + b;
    }

    double addition(double a, double b) {
        //if(a+0.01 > b && a-0.01 < b) { // Nachkommastelle koennen minimal sich unterscheiden
        return a + b;
    }

    int addLast(int a) {
        if(a > 0) {
            lastValue += a;
        }
        return lastValue;
    }

    // Private Hilfsmethode (nicht testbar)
//    private static int addTwoInts(int a, int b) {
//        return a + b;
//    }

    static void main() {
        Calculator calculator = new Calculator();
        int result = calculator.addition(1, 2);
        IO.println(result);

        IO.println(calculator.addLast(1));
        IO.println(calculator.addLast(1));
        IO.println(calculator.addLast(1));
    }
}
