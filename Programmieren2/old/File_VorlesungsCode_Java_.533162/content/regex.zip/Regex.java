package de.hawhamburg.v15;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Regex {

    public static void main(String[] args) {
        Pattern pattern = Pattern.compile("(?:\\d+)-((abc)+)");
        String input = "123-abcabc";
        Matcher matcher = pattern.matcher(input);
        if (matcher.matches()) {
            IO.println(matcher.group(1)); // gibt abc aus. Ließe man das ?: weg, würde man stattdessen 123 erhalten.
        }

        //todo();
    }

    private static void todo() {
        Pattern pattern = Pattern.compile(".*A(\\w)*d.*", Pattern.CASE_INSENSITIVE);
        String input = "Android (Ad) Abenteuer bald Abend";
        Matcher matcher = pattern.matcher(input);
//        while (matcher.find()) {
        if(matcher.matches()) {
            IO.println(matcher.group(1));
        }
    }
}
