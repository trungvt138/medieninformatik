package de.hawhamburg.v9;

@FunctionalInterface
interface TranslationService {
    String translate(String string);
}
