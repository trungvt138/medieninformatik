package de.hawhamburg.v8;

class LegalChecker {

    static boolean isAllowedToDrive(Person person) {
        return person.age() >= 18;
    }
}