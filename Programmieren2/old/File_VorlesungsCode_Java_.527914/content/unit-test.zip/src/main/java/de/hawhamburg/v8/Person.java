package de.hawhamburg.v8;

record Person(int age) {
}