package de.hawhamburg.v9;

class Translator { // generischer Übersetzter, der alle Sprachen kann prinzipiell

    TranslationService translationService;

    Translator(TranslationService translationService) { // Depenceny Injection
        this.translationService = translationService;
    }

    String translate(String string) {
        return translationService.translate(string);
    }

    static void main() {
        TranslationService helloTranslationService = string -> "Hallo";
        TranslationService englishTranslationService = string -> switch(string) {
            case "Hello" -> "Hallo";
            case "Cat" -> "Katze";
            default -> "translation not available";
        };
        Translator translator = new Translator(helloTranslationService); // Dependency Injection
        IO.println(translator.translate("Hello"));
        IO.println(translator.translate("Cat"));
        IO.println(translator.translate("Andre"));
    }
}
