package de.hawhamburg.v8;

import org.junit.jupiter.api.Test;

import java.util.List;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class TruthTest {

    @Test
    void truth() {
        List<Integer> numbers1 = List.of(1, 2, 3);
        List<Integer> numbers2 = List.of(2, 3, 4);

        // assertEquals(numbers1, numbers2);
        assertThat(numbers1).isEqualTo(numbers2);
    }
}
