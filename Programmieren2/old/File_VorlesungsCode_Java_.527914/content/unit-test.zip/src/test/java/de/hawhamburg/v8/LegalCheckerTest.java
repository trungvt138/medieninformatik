package de.hawhamburg.v8;

import com.google.common.truth.Truth;
import org.junit.jupiter.api.Test;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.jupiter.api.Assertions.*;

class LegalCheckerTest {

    @Test
    void above18() {
        Person personAbove18 = new Person(18);

        boolean actual = LegalChecker.isAllowedToDrive(personAbove18);

        // assertEquals(true, actual);
        assertTrue(actual); // convenient method (JUnit v5)
        assertThat(actual).isTrue(); // Truth
    }

    @Test
    void below18() {
        Person personAbove18 = new Person(17);

        boolean actual = LegalChecker.isAllowedToDrive(personAbove18);

        assertFalse(actual);
    }
}