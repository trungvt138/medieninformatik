package de.hawhamburg.v15;

import java.util.stream.Stream;

class Demo {

    static void main() {
        String result = "6\\2 = 3".replaceAll("\\\\", ":-)");
        IO.println(result);
    }

    void pureLambda2() {
        var stream = getIntegerStream();
        stream.forEach(IO::println); // terminal operation, lazy evaluiert
    }

    private static Stream<Integer> getIntegerStream() {
        int factor = 2; // effectively final oder final
        var stream = Stream.of(1, 2, 3)
            .map(number -> number * factor); // noch nicht terminiert
        return stream;
    }


    void pureLamba1() {
        // var result = new ArrayList<Integer>();
        Stream<Integer> source = Stream.of(1, 2, 3);
        var streamResult = source
            .map(number -> number * 2)
//            {
//                var copy = new ArrayList(result);;
//                copy.add(number * 2);
//                return copy;
//            })
            .toList(); // Ergebnis - terminale operation: neues Ergebnis (niemals modiziertes Ergebnis, die Quelle wird nicht verändert)
        IO.println(streamResult);
    }
}
