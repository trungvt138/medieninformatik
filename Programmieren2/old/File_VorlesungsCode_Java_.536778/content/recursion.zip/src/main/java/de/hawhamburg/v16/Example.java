package de.hawhamburg.v16;

class Example {

    static void main() {
        Directory dir1 = new Directory("dir1");
        File file1 = new File("file1", 5);
        Directory dir2 = new Directory("dir2");
        dir1.add(file1);
        dir1.add(dir2);

        Directory dir3 = new Directory("dir3");
        Directory dir4 = new Directory("dir4");
        dir2.add(dir3);
        dir2.add(dir4);

        File file2 = new File("file2", 10);
        File file3 = new File("file3", 20);
        dir3.add(file2);
        dir3.add(file3);

        IO.println(dir2.contains(file1));
    }
}
