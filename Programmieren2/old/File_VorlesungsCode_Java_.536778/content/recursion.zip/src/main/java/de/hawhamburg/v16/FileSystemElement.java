package de.hawhamburg.v16;

abstract class FileSystemElement {

    protected String name; // Attribut

    FileSystemElement(String name) {
        this.name = name; // eventuell prüfen
    }

    abstract long fetchSize();

    abstract boolean contains(FileSystemElement element);
}