package de.hawhamburg.v16;

class File extends FileSystemElement {

    private final long size;

    File(String name, long size) {
        super(name);
        this.size = size;
    }

    @Override
    long fetchSize() {
        return size; // Abbruchbedingung weil File ein Blatt im Baum ist.
    }

    @Override
    boolean contains(FileSystemElement element) {
        return false;
    }
}