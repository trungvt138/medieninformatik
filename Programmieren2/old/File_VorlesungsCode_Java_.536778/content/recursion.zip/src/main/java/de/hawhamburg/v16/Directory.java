package de.hawhamburg.v16;

import java.util.LinkedList;
import java.util.List;

class Directory extends FileSystemElement {

    private List<FileSystemElement> elements = new LinkedList<>(); // Attribut

    public Directory(String name) {
        super(name);
        this.name = name;
    }

    boolean add(FileSystemElement element) {
        return elements.add(element);
    }

    boolean remove(FileSystemElement element) {
        return elements.remove(element);
    }

    @Override
    long fetchSize() {
        int result = 0;
        for (FileSystemElement child : elements) {
            result += child.fetchSize(); // rekursiver Aufruf bei directories
        }
        return result;
    }

    @Override
    boolean contains(FileSystemElement element) {
        for (FileSystemElement child : elements) {
            if(child.equals(element) || child.contains(element)) {
                return true;
            }
        }
        return false;
    }
}
