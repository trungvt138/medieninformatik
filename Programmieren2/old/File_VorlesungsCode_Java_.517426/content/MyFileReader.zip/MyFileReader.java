package de.hawhamburg.v2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

class MyFileReader {

    void main() { // nio
        Path path = Path.of("/home/jewo/IdeaProjects/PB2_WS2526/src/main/java/de/hawhamburg/v2/text.txt");

        try {
            List<String> lines = Files.readAllLines(path);
            IO.println(lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
