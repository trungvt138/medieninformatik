package de.hawhamburg.joke;

record Joke(int id, String type, String setup, String punchline) {}