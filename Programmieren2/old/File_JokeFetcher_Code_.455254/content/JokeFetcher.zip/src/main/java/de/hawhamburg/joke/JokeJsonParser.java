package de.hawhamburg.joke;

interface JokeJsonParser {

    Joke parse(String json);
}