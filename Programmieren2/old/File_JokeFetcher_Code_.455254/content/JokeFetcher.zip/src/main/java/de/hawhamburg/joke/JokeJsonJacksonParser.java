package de.hawhamburg.joke;

class JokeJsonJacksonParser implements JokeJsonParser {

    @Override
    public Joke parse(String json) {
        return null; // TODO
    }
}