package de.hawhamburg.v10;

import java.util.List;

class AlternativeWithoutMockitoConnection implements Connection {
    @Override
    public List<Student> query(String name) {
        return List.of(new Student("ANDRE"));
    }

    @Override
    public void insert(Student student) {
        // ignore
    }
}
