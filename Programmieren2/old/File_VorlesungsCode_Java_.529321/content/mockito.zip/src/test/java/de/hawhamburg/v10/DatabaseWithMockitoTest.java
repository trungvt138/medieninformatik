package de.hawhamburg.v10;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class DatabaseWithMockitoTest {

    @Test
    void findStudentByName() {
        Connection mockedConnection = mock();
        when(mockedConnection.query("Andre")).thenReturn(List.of(new Student("Andre")));
        Database database = new Database(mockedConnection); // DI

        // Act
        List<Student> actual = database.findStudentByName("Andre");

        // Assert
        assertEquals(List.of(new Student("ANDRE")), actual);
    }
}
