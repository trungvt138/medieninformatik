package de.hawhamburg.v10;

import java.util.List;

class Database {

    Connection connection;

    Database(Connection connection) { // Dependency Injection
        this.connection = connection; // Entweder RealConnection oder TestConnection sein
    }

    List<Student> findStudentByName(String name) {
        return connection.query(name).stream()
            .map(student -> new Student(student.name().toUpperCase()))
            .toList(); // Polymorphie
    }

    void add(Student student) {
        connection.insert(student); // Polymorphie
    }

    static void main() { // production code
        Connection realConnection = new RealConnection();
        Database database = new Database(realConnection);

        database.add(new Student("Anna"));

        IO.println(database.findStudentByName("Anna"));
    }
}