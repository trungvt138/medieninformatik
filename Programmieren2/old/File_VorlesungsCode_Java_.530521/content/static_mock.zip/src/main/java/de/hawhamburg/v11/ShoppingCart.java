package de.hawhamburg.v11;


import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    private static List<String> items = new ArrayList<>();

    public void addItem(String item) {
        items.add(item);
    }

    public List<String> getItems() {
        return items;
    }

    static void main() {
        ShoppingCart user1Cart = new ShoppingCart();
        ShoppingCart user2Cart = new ShoppingCart();

        user1Cart.addItem("Laptop");
        user2Cart.addItem("Smartphone");

        IO.println("User 1 Cart: " + user1Cart.getItems());
        IO.println("User 2 Cart: " + user2Cart.getItems());
    }
}
