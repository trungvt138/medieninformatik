package de.hawhamburg.v11;

import java.time.LocalDate;

@FunctionalInterface
interface DateProvider {

    LocalDate getDate();
}
