package de.hawhamburg.v11;

import java.time.LocalDate;

final class Christmas {

    static String getMessageOfTheDay() {
        LocalDate today = LocalDate.now(); // statische Methode

        boolean isChristmas = today.getMonthValue() == 12 &&
                              today.getDayOfMonth() == 25;
        if (isChristmas) {
            return "Ho Ho Ho!";
        } else {
            return "Christmas is coming...";
        }
    }
}