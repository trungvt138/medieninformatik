package de.hawhamburg.v11;

import java.time.LocalDate;

final class ChristmasWithDependencyInjection {

    private DateProvider dateProvider;

    ChristmasWithDependencyInjection(DateProvider dateProvider) { // Dependency Injection
        this.dateProvider = dateProvider;
    }

    String getMessageOfTheDay() {
        LocalDate today = dateProvider.getDate(); // LocalDate.now(); statische Methode

        boolean isChristmas = today.getMonthValue() == 12 &&
                              today.getDayOfMonth() == 25;
        if (isChristmas) {
            return "Ho Ho Ho!";
        } else {
            return "Christmas is coming...";
        }
    }

    static void main() { // Production Code -> Customer
        DateProvider dateProvider = () -> LocalDate.now();
        IO.println(new ChristmasWithDependencyInjection(dateProvider).getMessageOfTheDay());
    }
}