package de.hawhamburg.v11;

import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.mockito.invocation.InvocationOnMock;

import java.time.LocalDate;

import static com.google.common.truth.Truth.assertThat;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

class ChristmasTest {

    @Test
    void getMessageOfTheDayNotChristmas() {
        DateProvider dateProvider = () -> LocalDate.of(123, 1, 1);
        String actual = new ChristmasWithDependencyInjection(dateProvider).getMessageOfTheDay();
        assertThat(actual).isEqualTo("Christmas is coming...");
    }

    @Test
    void getMessageOfTheDayItIsChristmas() {
        DateProvider dateProvider = () -> LocalDate.of(123, 12, 25);
        String actual = new ChristmasWithDependencyInjection(dateProvider).getMessageOfTheDay();
        assertThat(actual).isEqualTo("Ho Ho Ho!");
    }

    @Test
    void isChristmas() {
        try (MockedStatic<LocalDate> staticMock = mockStatic(LocalDate.class, InvocationOnMock::callRealMethod)) {
            // Arrange
            LocalDate christmasDate = LocalDate.of(0, 12, 25); // LocalDate.now() soll dies im Unit Test zurückgeben.
            staticMock.when(LocalDate::now).thenReturn(christmasDate); // rewrite the static method now()

            // Act
            String message = Christmas.getMessageOfTheDay();

            // Assert
            assertThat(message).isEqualTo("Ho Ho Ho!");
        }
    }

    @Test
    void isNotChristmas() {
        try (MockedStatic<LocalDate> _ = mockStatic(LocalDate.class, InvocationOnMock::callRealMethod)) {
            // Arrange
            LocalDate localDate = LocalDate.of(0, 7, 30);
            // Die Variable staticMock wird hier nicht verwendet, muss aber trotzdem in try-with-resources zugewiesen werden.
            // Für Variablen bzw. Parameter, die nicht verwendet werden, hat sich etabliert ein _ als Name zu verwenden.
            when(LocalDate.now()).thenReturn(localDate); // rewrite the static method now()

            // Act
            String message = Christmas.getMessageOfTheDay();

            // Assert
            assertThat(message).isEqualTo("Christmas is coming...");
        }
    }
}