package de.hawhamburg.v11;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MockitoDemoTest {

    @Test
    void mockito() {
        List mockedList = mock();

        when(mockedList.add(anyString())).thenReturn(true);
//        when(mockedList.add(anyInt())).thenReturn(true);
        assertTrue(mockedList.add("Anna")); // "programmiertes" Verhalten mit when
        assertTrue(mockedList.add("Andre")); // default-Verhalten
        assertFalse(mockedList.add(123)); // default-Verhalten

        when(mockedList.getFirst()).thenReturn("Anna"); // zaehlt nicht mit für verify, weil hier kein Aufruf stattfindet, sondern nur eine Programmierung
        assertEquals("Anna", mockedList.getFirst());

        verify(mockedList).getFirst();
    }

    static void test1(String string) {
        IO.println(string);
    }

    static String test2() {
        return "Andre";
    }

    static void main() {
        test1(test2());
    }
}
