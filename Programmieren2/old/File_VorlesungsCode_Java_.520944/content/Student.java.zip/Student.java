package de.hawhamburg.v3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

record Student(String name) {
    // constructor
    // getter name
    // toString
    // equals verwendet name
    // hashCode verwendet name

    static void addFour(List<Integer> numbers) {
        try {
            numbers.add(numbers.get(1));
            IO.println("4 wurde hinzugefuegt");
        } catch (UnsupportedOperationException e) {
            IO.println("4 wurde nicht hinzugefuegt");
        }
    }

    static void main() {
        Student andre = new Student("Andre"); // read-only, immutable
        IO.println(andre);
        andre = new Student("Andrew");

        var numbers = Set.of(1, 2, 3); // immutable
//        numbers = List.of("fds1");
        addFour(new ArrayList<>(numbers));

        List<Integer> numbers2 = new ArrayList<>(List.of(1, 2, 3)); // mutable
        addFour(numbers2);
    }
}